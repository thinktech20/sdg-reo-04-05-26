from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Any

from .config import RunConfig
from .data import IssueContext, clean_scalar


_NAN_RE = re.compile(r":\s*nan\b", flags=re.IGNORECASE)

_IBAT_FIELDS = [
    ("equip_serial_number", "Serial Number"),
    ("equipment_name", "Plant"),
    ("equipment_model", "Equipment Model"),
    ("equipment_code", "Equipment Code"),
    ("cooling_system", "Cooling System"),
    ("excitation_system", "Excitation System"),
    ("equipment_status", "Status"),
    ("original_apparent_pwr_mva", "Capacity MVA"),
    ("present_voltage_v", "Voltage"),
    ("speed_rpm", "Speed RPM"),
    ("equipment_comm_date", "Commission Date"),
    ("contract_type", "Contract Type"),
    ("csa_contract_number", "CSA Contract"),
    ("er_support_level", "ER Support Level"),
    ("rotor_rewind", "Rotor Rewind"),
    ("stator_rewind", "Stator Rewind"),
]

_SEVERITY_FIELDS = [
    ("Not Mentioned", "severity_criteria_0_no_data", "No Data"),
    ("Light", "severity_criteria_1_light", "Light"),
    ("Med", "severity_criteria_2_medium", "Medium"),
    ("Heavy", "severity_criteria_3_heavy", "Heavy"),
    ("IMMEDIATE ACTION", "severity_criteria_4_immediate", "Immediate"),
]


@dataclass(slots=True)
class PromptBuildResult:
    user_prompt: str
    fsr_chunk_count: int
    er_chunk_count: int


def _truncate_text(value: Any, max_chars: int) -> str:
    text = clean_scalar(value)
    if not text:
        return "N/A"
    if len(text) <= max_chars:
        return text
    return text[:max_chars].rstrip() + " ... [truncated]"


def _dedupe_chunks(chunks: list[dict[str, Any]], key_fields: tuple[str, ...]) -> list[dict[str, Any]]:
    seen: set[tuple[str, ...]] = set()
    unique_chunks: list[dict[str, Any]] = []

    for chunk in chunks:
        dedupe_key = tuple(clean_scalar(chunk.get(field, "")) for field in key_fields)
        if dedupe_key in seen:
            continue
        seen.add(dedupe_key)
        unique_chunks.append(chunk)

    return unique_chunks


def _select_chunks(
    chunks: list[dict[str, Any]],
    max_items: int,
    key_fields: tuple[str, ...],
) -> list[dict[str, Any]]:
    deduped = _dedupe_chunks(chunks, key_fields)
    return deduped[:max_items]


def format_ibat_section(ibat_row: dict[str, str]) -> str:
    lines = ["IBAT DATA:"]
    for field_name, label in _IBAT_FIELDS:
        lines.append(f"{label}: {clean_scalar(ibat_row.get(field_name, '')) or 'N/A'}")
    return "\n".join(lines)


def format_heatmap_section(context: IssueContext) -> str:
    heatmap_row = context.heatmap_row
    severity = context.er_query.get("severity_criteria", {}) or {}

    lines = ["HEATMAP QUESTION:"]
    lines.append(f"Component: {clean_scalar(heatmap_row.get('component', context.component)) or 'N/A'}")
    lines.append(f"Issue Name: {clean_scalar(heatmap_row.get('issue_name', context.issue_name)) or 'N/A'}")
    lines.append(
        f"Issue Grouping: {clean_scalar(heatmap_row.get('issue_grouping', context.issue_grouping)) or 'N/A'}"
    )
    lines.append(
        f"Issue Question: {clean_scalar(heatmap_row.get('issue_prompt', context.issue_prompt)) or 'N/A'}"
    )
    lines.append("Severity Criteria:")

    for label, heatmap_field, query_field in _SEVERITY_FIELDS:
        value = clean_scalar(heatmap_row.get(heatmap_field, "")) or clean_scalar(
            severity.get(query_field, "")
        )
        if value:
            lines.append(f"  {label}: {value}")

    return "\n".join(lines)


def format_fsr_section(chunks: list[dict[str, Any]], max_chunk_chars: int) -> str:
    if not chunks:
        return "No FSR chunks available."

    lines: list[str] = []
    for index, chunk in enumerate(chunks, start=1):
        lines.append(f"--- FSR Chunk {index} ---")
        lines.append(f"Chunk ID: {clean_scalar(chunk.get('chunk_id', '')) or 'N/A'}")
        lines.append(f"Report Name: {clean_scalar(chunk.get('pdf_name', '')) or 'N/A'}")
        lines.append(f"Page Number: {clean_scalar(chunk.get('page_number', '')) or 'N/A'}")
        lines.append(f"Serial: {clean_scalar(chunk.get('generator_serial', '')) or 'N/A'}")
        lines.append(f"Score: {clean_scalar(chunk.get('score', '')) or 'N/A'}")
        lines.append(
            f"Context: {_truncate_text(chunk.get('chunk_text', ''), max_chunk_chars)}"
        )
        lines.append("")

    return "\n".join(lines).rstrip()


def format_er_section(chunks: list[dict[str, Any]], max_chunk_chars: int) -> str:
    if not chunks:
        return "No ER chunks available."

    lines: list[str] = []
    for index, chunk in enumerate(chunks, start=1):
        lines.append(f"--- ER Chunk {index} ---")
        lines.append(f"ER Number: {clean_scalar(chunk.get('er_number', '')) or 'N/A'}")
        lines.append(f"Opened At: {clean_scalar(chunk.get('opened_at', '')) or 'N/A'}")
        lines.append(f"Component: {clean_scalar(chunk.get('u_component', '')) or 'N/A'}")
        lines.append(f"Status: {clean_scalar(chunk.get('status', '')) or 'N/A'}")
        lines.append(f"Field Action Taken: {clean_scalar(chunk.get('u_field_action_taken', '')) or 'N/A'}")
        lines.append(f"Score: {clean_scalar(chunk.get('score', '')) or 'N/A'}")
        lines.append(
            f"Context: {_truncate_text(chunk.get('chunk_text', chunk.get('Text', '')), max_chunk_chars)}"
        )
        lines.append("")

    return "\n".join(lines).rstrip()


def build_user_prompt(context: IssueContext, config: RunConfig) -> PromptBuildResult:
    selected_fsr_chunks = _select_chunks(
        context.fsr_chunks,
        max_items=max(config.max_fsr_chunks, 0),
        key_fields=("chunk_id", "pdf_name", "page_number"),
    )
    selected_er_chunks = _select_chunks(
        context.er_chunks,
        max_items=max(config.max_er_chunks, 0),
        key_fields=("er_number", "chunk_index", "opened_at"),
    )

    parts = [
        "=== HEATMAP_QUESTION ===",
        format_heatmap_section(context),
        "",
        "=== IBAT ===",
        format_ibat_section(context.ibat_row),
        "",
        "=== FSR_CHUNKS ===",
        format_fsr_section(selected_fsr_chunks, config.max_chunk_chars),
        "",
        "=== ER_CHUNKS ===",
        format_er_section(selected_er_chunks, config.max_chunk_chars),
    ]

    prompt = "\n".join(parts)
    prompt = _NAN_RE.sub(": N/A", prompt)

    return PromptBuildResult(
        user_prompt=prompt,
        fsr_chunk_count=len(selected_fsr_chunks),
        er_chunk_count=len(selected_er_chunks),
    )