from __future__ import annotations

import csv
import hashlib
import json
import os
import tempfile
import time
from collections import Counter
from concurrent.futures import ThreadPoolExecutor
from dataclasses import asdict
from datetime import datetime, timedelta, timezone
from functools import lru_cache
from itertools import repeat
from pathlib import Path
from typing import Any, Iterable, Optional

try:
    from tqdm.auto import tqdm
except Exception:  # pragma: no cover - optional dependency in some runtimes
    tqdm = None

from .condense import write_condensed_csv
from .config import RunConfig, get_dbutils, is_databricks, split_csv_arg
from .data import IssueContext, iter_issue_contexts, load_text, normalize_issue_name
from .evaluation import (
    DIFF_CSV_NAME,
    GROUND_TRUTH_CSV_NAME,
    ensure_ground_truth_csv,
    evaluate_condensed_against_ground_truth,
)
from .llm import ContentFilteredLiteLLMError, LiteLLMClient, parse_llm_response
from .prompting import PromptBuildResult, build_user_prompt


TERMINAL_NON_SUCCESS_STATUSES = {"content_skip"}


CSV_COLUMNS = [
    "completed_at_utc",
    "status",
    "error",
    "serial_number",
    "issue_name",
    "normalized_issue_name",
    "component",
    "issue_grouping",
    "issue_prompt",
    "heatmap_matched",
    "fsr_source_key",
    "fsr_chunk_count",
    "er_chunk_count",
    "prompt_chars",
    "model_name",
    "latency_sec",
    "row_latency_sec",
    "summary",
    "finding_count",
    "risk",
    "condition",
    "threshold",
    "actual_value",
    "evidence",
    "citation",
    "justification",
    "ambiguity_handling",
    "output_json",
    "raw_response",
]


def _timestamp_utc() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


def _jsonify(value: Any) -> Any:
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, list):
        return [_jsonify(item) for item in value]
    if isinstance(value, dict):
        return {str(key): _jsonify(item) for key, item in value.items()}
    return value


def _coerce_list(value: Optional[str | Iterable[str]]) -> Optional[list[str]]:
    if value is None:
        return None
    if isinstance(value, str):
        return split_csv_arg(value)
    return [str(item).strip() for item in value if str(item).strip()]


def _is_dbfs_path(value: Optional[str | Path]) -> bool:
    if value is None:
        return False

    raw = str(value).strip()
    return raw == "dbfs:" or raw.startswith("dbfs:/") or raw == "/dbfs" or raw.startswith("/dbfs/")


def _normalize_dbfs_uri(value: str | Path) -> str:
    raw = str(value).strip()
    if raw == "dbfs:":
        return "dbfs:/"
    if raw.startswith("dbfs:/"):
        return raw if raw == "dbfs:/" else raw.rstrip("/")
    if raw == "/dbfs":
        return "dbfs:/"
    if raw.startswith("/dbfs/"):
        return f"dbfs:/{raw[len('/dbfs/'):].rstrip('/')}"
    raise ValueError(f"Not a DBFS path: {value}")


def _dbfs_uri_join(parent_uri: str, leaf_name: str) -> str:
    return f"{parent_uri.rstrip('/')}/{leaf_name}"


@lru_cache(maxsize=1)
def _resolve_local_stage_root() -> Path:
    candidate_roots: list[Path] = []
    env_override = os.getenv("RE_CHAIN_STAGE_ROOT", "").strip()
    if env_override:
        candidate_roots.append(Path(env_override).expanduser())

    if is_databricks():
        candidate_roots.extend(
            [
                Path("/databricks/driver"),
                Path.cwd(),
                Path.home(),
            ]
        )

    candidate_roots.extend(
        [
            Path(tempfile.gettempdir()),
            Path.cwd(),
            Path.home() / ".risk_evaluation_script_gt",
        ]
    )

    attempted: list[str] = []
    seen: set[str] = set()
    for candidate_root in candidate_roots:
        candidate_key = str(candidate_root)
        if candidate_key in seen:
            continue
        seen.add(candidate_key)

        try:
            stage_root = candidate_root / "risk_evaluation_script_gt_artifacts"
            stage_root.mkdir(parents=True, exist_ok=True)
            probe_path = stage_root / ".write_probe"
            probe_path.write_text("ok", encoding="utf-8")
            probe_path.unlink(missing_ok=True)
            print(f"[OK] Local artifact staging root: {stage_root}")
            return stage_root
        except Exception as exc:
            attempted.append(f"{candidate_root}: {exc}")

    attempted_text = " | ".join(attempted) if attempted else "[no candidates tried]"
    raise RuntimeError(f"No writable local staging root available. Tried: {attempted_text}")


def _local_stage_path_for_dbfs_uri(dbfs_uri: str) -> Path:
    relative_path = dbfs_uri[len("dbfs:/"):].lstrip("/")
    return _resolve_local_stage_root() / relative_path


def _sync_file_to_dbfs(local_path: Path, target_uri: str) -> None:
    dbutils = get_dbutils()
    if dbutils is None:
        raise RuntimeError("dbutils is unavailable; cannot sync artifacts to DBFS from this runtime.")

    normalized_target = _normalize_dbfs_uri(target_uri)
    target_parent = normalized_target.rsplit("/", 1)[0]
    dbutils.fs.mkdirs(target_parent)
    dbutils.fs.cp(f"file:{local_path.as_posix()}", normalized_target, True)


def _safe_sync_file(local_path: Path, target_uri: Optional[str]) -> Optional[str]:
    if target_uri is None or not local_path.exists():
        return None

    try:
        _sync_file_to_dbfs(local_path, target_uri)
    except Exception as exc:
        message = f"{local_path} -> {target_uri}: {exc}"
        print(f"[WARN] Artifact sync failed: {message}")
        return message
    return None


def _log_result_row(row: dict[str, Any]) -> None:
    payload = dict(row)
    raw_response = str(payload.pop("raw_response", "") or "")
    if raw_response:
        payload["raw_response_chars"] = len(raw_response)
    print(f"RESULT_ROW {json.dumps(payload, ensure_ascii=False)}")


def _next_run_dir(outputs_root: Path) -> Path:
    outputs_root.mkdir(parents=True, exist_ok=True)
    existing = [
        int(path.name)
        for path in outputs_root.iterdir()
        if path.is_dir() and path.name.isdigit()
    ]
    next_index = max(existing) + 1 if existing else 0
    run_dir = outputs_root / str(next_index)
    run_dir.mkdir(parents=True, exist_ok=False)
    return run_dir


def _prepare_run_paths(
    default_output_root: Path,
    output_csv: Optional[str | Path],
) -> tuple[Path, Path, Path, Path, Optional[str], Optional[str]]:
    persist_run_dir_uri: Optional[str] = None
    persist_output_csv_uri: Optional[str] = None

    if output_csv:
        requested_output_csv = str(output_csv).strip()
        if is_databricks() and _is_dbfs_path(requested_output_csv):
            persist_output_csv_uri = _normalize_dbfs_uri(requested_output_csv)
            full_output_csv = _local_stage_path_for_dbfs_uri(persist_output_csv_uri)
            run_dir = full_output_csv.parent
            run_dir.mkdir(parents=True, exist_ok=True)
            persist_run_dir_uri = persist_output_csv_uri.rsplit("/", 1)[0]
        else:
            full_output_csv = Path(requested_output_csv)
            run_dir = full_output_csv.parent
            run_dir.mkdir(parents=True, exist_ok=True)
    else:
        run_dir = _next_run_dir(default_output_root)
        full_output_csv = run_dir / "re_chain_full.csv"

    condensed_output_csv = run_dir / "re_chain_condensed.csv"
    config_json_path = run_dir / "run_config.json"
    return (
        run_dir,
        full_output_csv,
        condensed_output_csv,
        config_json_path,
        persist_run_dir_uri,
        persist_output_csv_uri,
    )


def _write_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")


def _summarize_execution_timing(output_csv: Path) -> Optional[dict[str, Any]]:
    if not output_csv.exists():
        return None

    earliest_started_at: Optional[datetime] = None
    latest_completed_at: Optional[datetime] = None
    timed_row_count = 0

    with output_csv.open("r", newline="", encoding="utf-8") as handle:
        reader = csv.DictReader(handle)
        for row in reader:
            completed_raw = str(row.get("completed_at_utc") or "").strip()
            row_latency_raw = str(row.get("row_latency_sec") or "").strip()
            if not completed_raw or not row_latency_raw:
                continue

            try:
                completed_at = datetime.fromisoformat(completed_raw)
                row_latency_sec = float(row_latency_raw)
            except ValueError:
                continue

            started_at = completed_at - timedelta(seconds=row_latency_sec)
            earliest_started_at = (
                started_at
                if earliest_started_at is None or started_at < earliest_started_at
                else earliest_started_at
            )
            latest_completed_at = (
                completed_at
                if latest_completed_at is None or completed_at > latest_completed_at
                else latest_completed_at
            )
            timed_row_count += 1

    if earliest_started_at is None or latest_completed_at is None:
        return None

    return {
        "execution_started_at_utc": earliest_started_at.astimezone(timezone.utc).isoformat(
            timespec="milliseconds"
        ),
        "execution_completed_at_utc": latest_completed_at.astimezone(timezone.utc).isoformat(
            timespec="seconds"
        ),
        "execution_latency_sec": round(
            (latest_completed_at - earliest_started_at).total_seconds(), 3
        ),
        "timed_row_count": timed_row_count,
    }


def _hash_source_tree(src_root: Path) -> dict[str, Any]:
    hasher = hashlib.sha256()
    file_count = 0

    for path in sorted(src_root.rglob("*")):
        if not path.is_file():
            continue
        if "__pycache__" in path.parts:
            continue
        if path.suffix in {".pyc", ".pyo"}:
            continue

        relative_path = path.relative_to(src_root).as_posix()
        hasher.update(relative_path.encode("utf-8"))
        hasher.update(b"\0")
        hasher.update(path.read_bytes())
        hasher.update(b"\0")
        file_count += 1

    return {
        "algorithm": "sha256",
        "root": str(src_root),
        "file_count": file_count,
        "value": hasher.hexdigest(),
    }


def _build_run_config_payload(
    config: RunConfig,
    run_dir: Path,
    condensed_output_csv: Path,
    config_json_path: Path,
    started_at_utc: str,
    source_hash: dict[str, Any],
    completed_at_utc: Optional[str] = None,
    run_latency_sec: Optional[float] = None,
    execution_timing: Optional[dict[str, Any]] = None,
    evaluation: Optional[dict[str, Any]] = None,
    summary: Optional[dict[str, Any]] = None,
    notes: Optional[list[str]] = None,
) -> dict[str, Any]:
    payload = _jsonify(asdict(config))
    persisted_run_dir = config.persist_run_dir_uri or str(run_dir)
    persisted_output_csv = config.persist_output_csv_uri or str(config.output_csv)
    persisted_condensed_output_csv = (
        _dbfs_uri_join(config.persist_run_dir_uri, condensed_output_csv.name)
        if config.persist_run_dir_uri
        else str(condensed_output_csv)
    )
    persisted_config_json_path = (
        _dbfs_uri_join(config.persist_run_dir_uri, config_json_path.name)
        if config.persist_run_dir_uri
        else str(config_json_path)
    )
    payload.update(
        {
            "run_dir": persisted_run_dir,
            "output_csv": persisted_output_csv,
            "condensed_output_csv": persisted_condensed_output_csv,
            "config_json_path": persisted_config_json_path,
            "local_run_dir": str(run_dir),
            "local_output_csv": str(config.output_csv),
            "local_condensed_output_csv": str(condensed_output_csv),
            "local_config_json_path": str(config_json_path),
            "started_at_utc": started_at_utc,
            "source_hash": _jsonify(source_hash),
        }
    )
    if completed_at_utc is not None:
        payload["completed_at_utc"] = completed_at_utc
    if run_latency_sec is not None:
        payload["run_latency_sec"] = run_latency_sec
    if execution_timing is not None:
        payload.update(_jsonify(execution_timing))
    if evaluation is not None:
        payload["evaluation"] = _jsonify(evaluation)
    if summary is not None:
        payload["summary"] = _jsonify(summary)
    if notes:
        payload["notes"] = notes
    return payload


def _join_finding_values(findings: list[dict[str, Any]], key: str) -> str:
    values = []
    for finding in findings:
        value = finding.get(key, "")
        text = str(value).strip() if value is not None else ""
        if text:
            values.append(text)
    return " || ".join(values)


def _build_base_row(
    context: IssueContext,
    prompt_result: Optional[PromptBuildResult],
    config: RunConfig,
) -> dict[str, Any]:
    return {
        "completed_at_utc": "",
        "status": "",
        "error": "",
        "serial_number": context.serial_number,
        "issue_name": context.issue_name,
        "normalized_issue_name": context.normalized_issue_name,
        "component": context.component,
        "issue_grouping": context.issue_grouping,
        "issue_prompt": context.issue_prompt,
        "heatmap_matched": str(context.heatmap_matched),
        "fsr_source_key": context.fsr_source_key,
        "fsr_chunk_count": prompt_result.fsr_chunk_count if prompt_result else 0,
        "er_chunk_count": prompt_result.er_chunk_count if prompt_result else 0,
        "prompt_chars": len(prompt_result.user_prompt) if prompt_result else 0,
        "model_name": config.model_name,
        "latency_sec": "",
        "row_latency_sec": "",
        "summary": "",
        "finding_count": 0,
        "risk": "",
        "condition": "",
        "threshold": "",
        "actual_value": "",
        "evidence": "",
        "citation": "",
        "justification": "",
        "ambiguity_handling": "",
        "output_json": "",
        "raw_response": "",
    }


def _finalize_row(row: dict[str, Any], row_started_at: float) -> None:
    row["completed_at_utc"] = _timestamp_utc()
    row["row_latency_sec"] = round(time.perf_counter() - row_started_at, 3)


def _append_row(output_csv: Path, row: dict[str, Any]) -> None:
    output_csv.parent.mkdir(parents=True, exist_ok=True)
    file_exists = output_csv.exists()
    with output_csv.open("a", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=CSV_COLUMNS)
        if not file_exists:
            writer.writeheader()
        writer.writerow({column: row.get(column, "") for column in CSV_COLUMNS})


def _row_pair(row: dict[str, Any]) -> tuple[str, str]:
    serial_number = str(row.get("serial_number") or "").strip()
    normalized_issue = normalize_issue_name(
        row.get("normalized_issue_name") or row.get("issue_name") or ""
    )
    return serial_number, normalized_issue


def _prune_resolved_rows(output_csv: Path) -> int:
    if not output_csv.exists():
        return 0

    with output_csv.open("r", newline="", encoding="utf-8") as handle:
        reader = csv.DictReader(handle)
        rows = list(reader)

    success_pairs: set[tuple[str, str]] = set()
    latest_success_index_by_pair: dict[tuple[str, str], int] = {}
    latest_index_by_pair: dict[tuple[str, str], int] = {}
    for index, row in enumerate(rows):
        pair = _row_pair(row)
        latest_index_by_pair[pair] = index
        if str(row.get("status") or "").strip() != "success":
            continue
        success_pairs.add(pair)
        latest_success_index_by_pair[pair] = index

    if not rows:
        return 0

    kept_rows: list[dict[str, Any]] = []
    removed = 0
    for index, row in enumerate(rows):
        pair = _row_pair(row)
        target_index = latest_success_index_by_pair.get(pair, latest_index_by_pair[pair])
        if index != target_index:
            removed += 1
            continue
        kept_rows.append(row)

    if removed == 0:
        return 0

    with output_csv.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=CSV_COLUMNS)
        writer.writeheader()
        for row in kept_rows:
            writer.writerow({column: row.get(column, "") for column in CSV_COLUMNS})

    return removed


def _load_completed_pairs(output_csv: Path) -> set[tuple[str, str]]:
    if not output_csv.exists():
        return set()

    completed: set[tuple[str, str]] = set()
    with output_csv.open("r", newline="", encoding="utf-8") as handle:
        reader = csv.DictReader(handle)
        for row in reader:
            if row.get("status") not in {"success", *TERMINAL_NON_SUCCESS_STATUSES}:
                continue
            serial_number = (row.get("serial_number") or "").strip()
            issue_name = normalize_issue_name(row.get("issue_name") or "")
            if serial_number and issue_name:
                completed.add((serial_number, issue_name))
    return completed


def _summarize_output_csv(output_csv: Path, total_items: int) -> dict[str, Any]:
    if not output_csv.exists():
        return {
            "written_rows": 0,
            "success": 0,
            "content_skip": 0,
            "parse_error": 0,
            "llm_error": 0,
            "dry_run": 0,
            "skipped": total_items,
            "remaining": total_items,
        }

    with output_csv.open("r", newline="", encoding="utf-8") as handle:
        reader = csv.DictReader(handle)
        rows = list(reader)

    counts = Counter(str(row.get("status") or "").strip() for row in rows)
    written_rows = len(rows)
    remaining = max(total_items - written_rows, 0)
    return {
        "written_rows": written_rows,
        "success": counts.get("success", 0),
        "content_skip": counts.get("content_skip", 0),
        "parse_error": counts.get("parse_error", 0),
        "llm_error": counts.get("llm_error", 0),
        "dry_run": counts.get("dry_run", 0),
        "skipped": remaining,
        "remaining": remaining,
    }


def _apply_success_payload(
    row: dict[str, Any],
    parsed_output: dict[str, Any],
    raw_response: str,
    latency_sec: float,
) -> None:
    findings = parsed_output.get("findings", []) or []
    row.update(
        {
            "status": "success",
            "latency_sec": latency_sec,
            "summary": str(parsed_output.get("summary", "")).strip(),
            "finding_count": len(findings),
            "risk": _join_finding_values(findings, "Risk"),
            "condition": _join_finding_values(findings, "Condition"),
            "threshold": _join_finding_values(findings, "Threshold"),
            "actual_value": _join_finding_values(findings, "Actual Value"),
            "evidence": _join_finding_values(findings, "Evidence"),
            "citation": _join_finding_values(findings, "Citation"),
            "justification": _join_finding_values(findings, "justification"),
            "ambiguity_handling": _join_finding_values(findings, "Ambiguity handling"),
            "output_json": json.dumps(parsed_output, ensure_ascii=False),
            "raw_response": raw_response,
        }
    )


def _update_summary(summary: dict[str, Any], status: str) -> None:
    if status in summary:
        summary[status] += 1


def _create_progress_bar(total_items: int) -> Any:
    if tqdm is None:
        return None

    return tqdm(
        total=total_items,
        desc="RE Chain",
        unit="issue",
        dynamic_ncols=True,
        leave=True,
    )


def _progress_message(
    index: int,
    total_items: int,
    context: IssueContext,
    status: str,
) -> str:
    return f"[{index}/{total_items}] {context.serial_number} | {context.issue_name} -> {status}"


def _report_progress(
    progress: Any,
    index: int,
    total_items: int,
    context: IssueContext,
    status: str,
) -> None:
    message = _progress_message(index, total_items, context, status)
    if progress is None:
        print(message)
        return

    progress.update(1)
    progress.set_postfix_str(f"{context.serial_number} | {status}", refresh=False)
    progress.write(message)


def _process_context_result(
    item: tuple[int, IssueContext],
    config: RunConfig,
    system_prompt: str,
) -> dict[str, Any]:
    index, context = item
    row_started_at = time.perf_counter()
    row = _build_base_row(context, None, config)
    llm_result: Optional[dict[str, Any]] = None

    try:
        prompt_result = build_user_prompt(context, config)
        row.update(
            {
                "fsr_chunk_count": prompt_result.fsr_chunk_count,
                "er_chunk_count": prompt_result.er_chunk_count,
                "prompt_chars": len(prompt_result.user_prompt),
            }
        )
        if config.dry_run:
            row.update(
                {
                    "status": "dry_run",
                    "summary": "Prompt built successfully",
                }
            )
        else:
            client = LiteLLMClient(config)
            llm_result = client.chat(system_prompt, prompt_result.user_prompt)
            parsed_output = parse_llm_response(llm_result["raw_response"])
            _apply_success_payload(
                row,
                parsed_output,
                raw_response=llm_result["raw_response"],
                latency_sec=llm_result["latency_sec"],
            )
    except ValueError as exc:
        row.update(
            {
                "status": "parse_error",
                "error": str(exc),
                "raw_response": (llm_result or {}).get("raw_response", ""),
            }
        )
    except ContentFilteredLiteLLMError as exc:
        row.update(
            {
                "status": "content_skip",
                "error": str(exc),
                "summary": "Model returned a content warning; skipped without retry.",
            }
        )
    except Exception as exc:
        row.update({"status": "llm_error", "error": str(exc)})
    finally:
        _finalize_row(row, row_started_at)

    return {
        "index": index,
        "context": context,
        "row": row,
    }


def run_batch(config: RunConfig) -> dict[str, Any]:
    config.ensure_output_dir()
    contexts = list(iter_issue_contexts(config))
    total_items = len(contexts)
    completed_pairs = set()
    if not config.force_rerun:
        completed_pairs = _load_completed_pairs(config.output_csv)

    system_prompt = load_text(config.system_prompt_path)

    summary: dict[str, Any] = {
        "total_items": total_items,
        "skipped": 0,
        "success": 0,
        "content_skip": 0,
        "parse_error": 0,
        "llm_error": 0,
        "dry_run": 0,
        "output_csv": config.persist_output_csv_uri or str(config.output_csv),
        "local_output_csv": str(config.output_csv),
    }

    work_items: list[tuple[int, IssueContext]] = []
    progress = _create_progress_bar(total_items)
    sync_output_csv = bool(config.persist_output_csv_uri)

    try:
        for index, context in enumerate(contexts, start=1):
            pair = (context.serial_number, context.normalized_issue_name)
            if pair in completed_pairs:
                summary["skipped"] += 1
                _report_progress(progress, index, total_items, context, "skipped")
                continue

            work_items.append((index, context))

        if config.max_workers <= 1 or len(work_items) <= 1:
            results_iter = (
                _process_context_result(item, config, system_prompt) for item in work_items
            )
            for result in results_iter:
                row = result["row"]
                context = result["context"]
                _append_row(config.output_csv, row)
                if config.log_results:
                    _log_result_row(row)
                if sync_output_csv:
                    sync_error = _safe_sync_file(config.output_csv, config.persist_output_csv_uri)
                    if sync_error is not None:
                        summary.setdefault("artifact_sync_errors", []).append(sync_error)
                        sync_output_csv = False
                _update_summary(summary, row["status"])
                _report_progress(
                    progress,
                    result["index"],
                    total_items,
                    context,
                    row["status"],
                )
            return summary

        with ThreadPoolExecutor(max_workers=config.max_workers) as executor:
            results_iter = executor.map(
                _process_context_result,
                work_items,
                repeat(config),
                repeat(system_prompt),
            )

            for result in results_iter:
                row = result["row"]
                context = result["context"]
                _append_row(config.output_csv, row)
                if config.log_results:
                    _log_result_row(row)
                if sync_output_csv:
                    sync_error = _safe_sync_file(config.output_csv, config.persist_output_csv_uri)
                    if sync_error is not None:
                        summary.setdefault("artifact_sync_errors", []).append(sync_error)
                        sync_output_csv = False
                _update_summary(summary, row["status"])
                _report_progress(
                    progress,
                    result["index"],
                    total_items,
                    context,
                    row["status"],
                )
    finally:
        if progress is not None:
            progress.close()

    return summary


def main(
    force_rerun: bool = False,
    serials: Optional[str | Iterable[str]] = None,
    issues: Optional[str | Iterable[str]] = None,
    max_serials: Optional[int] = None,
    max_issues: Optional[int] = None,
    output_csv: Optional[str | Path] = None,
    model_name: Optional[str] = None,
    secret_scope: Optional[str] = None,
    dry_run: bool = False,
    max_fsr_chunks: Optional[int] = None,
    max_er_chunks: Optional[int] = None,
    max_chunk_chars: Optional[int] = None,
    max_workers: Optional[int] = None,
    input_data_dir: Optional[str | Path] = None,
) -> dict[str, Any]:
    defaults = RunConfig()
    run_dir, full_output_csv, condensed_output_csv, config_json_path, persist_run_dir_uri, persist_output_csv_uri = _prepare_run_paths(
        defaults.output_csv.parent,
        output_csv,
    )
    src_root = Path(__file__).resolve().parents[1]
    project_dir = src_root.parent
    source_hash = _hash_source_tree(src_root)
    config = RunConfig(
        input_data_dir=Path(input_data_dir) if input_data_dir else defaults.input_data_dir,
        output_csv=full_output_csv,
        model_name=model_name or defaults.model_name,
        secret_scope=secret_scope or defaults.secret_scope,
        force_rerun=force_rerun,
        serials=_coerce_list(serials),
        issues=_coerce_list(issues),
        max_serials=max_serials,
        max_issues=max_issues,
        dry_run=dry_run,
        max_fsr_chunks=max_fsr_chunks or defaults.max_fsr_chunks,
        max_er_chunks=max_er_chunks or defaults.max_er_chunks,
        max_chunk_chars=max_chunk_chars or defaults.max_chunk_chars,
        max_workers=max_workers if max_workers is not None else defaults.max_workers,
        persist_output_csv_uri=persist_output_csv_uri,
        persist_run_dir_uri=persist_run_dir_uri,
        log_results=defaults.log_results,
    )
    persisted_run_dir = config.persist_run_dir_uri or str(run_dir)
    persisted_output_csv = config.persist_output_csv_uri or str(config.output_csv)
    persisted_config_json_path = (
        _dbfs_uri_join(config.persist_run_dir_uri, config_json_path.name)
        if config.persist_run_dir_uri
        else str(config_json_path)
    )
    persisted_condensed_output_csv = (
        _dbfs_uri_join(config.persist_run_dir_uri, condensed_output_csv.name)
        if config.persist_run_dir_uri
        else str(condensed_output_csv)
    )
    persisted_ground_truth_csv = (
        _dbfs_uri_join(config.persist_run_dir_uri, GROUND_TRUTH_CSV_NAME)
        if config.persist_run_dir_uri
        else None
    )
    persisted_diff_csv = (
        _dbfs_uri_join(config.persist_run_dir_uri, DIFF_CSV_NAME)
        if config.persist_run_dir_uri
        else None
    )
    artifact_sync_errors: list[str] = []

    started_at_utc = _timestamp_utc()
    run_started_at = time.perf_counter()
    _write_json(
        config_json_path,
        _build_run_config_payload(
            config,
            run_dir,
            condensed_output_csv,
            config_json_path,
            started_at_utc=started_at_utc,
            source_hash=source_hash,
        ),
    )
    config_sync_error = _safe_sync_file(config_json_path, config.persist_run_dir_uri and persisted_config_json_path)
    if config_sync_error is not None:
        artifact_sync_errors.append(config_sync_error)

    summary = run_batch(config)
    attempt_summary = {
        "skipped": summary.get("skipped", 0),
        "success": summary.get("success", 0),
        "content_skip": summary.get("content_skip", 0),
        "parse_error": summary.get("parse_error", 0),
        "llm_error": summary.get("llm_error", 0),
        "dry_run": summary.get("dry_run", 0),
    }
    pruned_rows = _prune_resolved_rows(config.output_csv)
    if pruned_rows:
        summary["pruned_rows"] = pruned_rows
    summary["attempt"] = attempt_summary
    summary.update(_summarize_output_csv(config.output_csv, summary["total_items"]))
    summary["run_dir"] = persisted_run_dir
    summary["local_run_dir"] = str(run_dir)
    summary["output_csv"] = persisted_output_csv
    summary["local_output_csv"] = str(config.output_csv)
    summary["config_json_path"] = persisted_config_json_path
    summary["local_config_json_path"] = str(config_json_path)
    evaluation: Optional[dict[str, Any]] = None
    ground_truth_csv: Optional[Path] = None
    diff_csv_path: Optional[Path] = None

    if not config.dry_run and summary["parse_error"] == 0 and summary["llm_error"] == 0:
        matrix = write_condensed_csv(config.output_csv, condensed_output_csv)
        summary["condensed_output_csv"] = persisted_condensed_output_csv
        summary["local_condensed_output_csv"] = str(condensed_output_csv)
        summary["condensed_shape"] = [matrix.shape[0], matrix.shape[1]]

        ground_truth_csv = ensure_ground_truth_csv(
            project_dir,
            serials=config.serials or config.default_serials,
            issues=config.issues,
            output_path=run_dir / GROUND_TRUTH_CSV_NAME,
        )
        if ground_truth_csv is not None:
            diff_csv_path = run_dir / DIFF_CSV_NAME
            evaluation = evaluate_condensed_against_ground_truth(
                condensed_output_csv,
                ground_truth_csv,
                diff_csv_path,
            )
            stats = evaluation["stats"]
            summary["ground_truth_rows_compared"] = stats["rows_compared"]
            summary["ground_truth_correct"] = stats["correct"]
            summary["ground_truth_false_positive"] = stats["false_positive"]
            summary["ground_truth_false_negative"] = stats["false_negative"]
            summary["ground_truth_missing_actual"] = stats["missing_actual"]
            summary["ground_truth_csv"] = persisted_ground_truth_csv or str(ground_truth_csv)
            summary["local_ground_truth_csv"] = str(ground_truth_csv)
            summary["ground_truth_diff_csv"] = persisted_diff_csv or str(diff_csv_path)
            summary["local_ground_truth_diff_csv"] = str(diff_csv_path)
    else:
        summary["condensed_output_csv"] = None

    completed_at_utc = _timestamp_utc()
    run_latency_sec = round(time.perf_counter() - run_started_at, 3)
    summary["run_latency_sec"] = run_latency_sec
    execution_timing = _summarize_execution_timing(config.output_csv)
    if execution_timing is not None:
        summary.update(execution_timing)

    if summary.get("artifact_sync_errors"):
        artifact_sync_errors.extend(summary["artifact_sync_errors"])

    final_artifacts: list[tuple[Path, Optional[str]]] = [
        (config.output_csv, config.persist_output_csv_uri),
        (config_json_path, persisted_config_json_path if config.persist_run_dir_uri else None),
    ]
    if condensed_output_csv.exists():
        final_artifacts.append((condensed_output_csv, persisted_condensed_output_csv if config.persist_run_dir_uri else None))
    if ground_truth_csv is not None and ground_truth_csv.exists():
        final_artifacts.append((ground_truth_csv, persisted_ground_truth_csv))
    if diff_csv_path is not None and diff_csv_path.exists():
        final_artifacts.append((diff_csv_path, persisted_diff_csv))

    for local_path, target_uri in final_artifacts:
        sync_error = _safe_sync_file(local_path, target_uri)
        if sync_error is not None:
            artifact_sync_errors.append(sync_error)

    if artifact_sync_errors:
        summary["artifact_sync_errors"] = artifact_sync_errors

    _write_json(
        config_json_path,
        _build_run_config_payload(
            config,
            run_dir,
            condensed_output_csv,
            config_json_path,
            started_at_utc=started_at_utc,
            source_hash=source_hash,
            completed_at_utc=completed_at_utc,
            run_latency_sec=run_latency_sec,
            execution_timing=execution_timing,
            evaluation=evaluation,
            summary=summary,
        ),
    )
    final_config_sync_error = _safe_sync_file(
        config_json_path,
        persisted_config_json_path if config.persist_run_dir_uri else None,
    )
    if final_config_sync_error is not None:
        summary.setdefault("artifact_sync_errors", []).append(final_config_sync_error)

    print("\nRun summary")
    for key, value in summary.items():
        print(f"  {key}: {value}")
    print(f"RESULT_SUMMARY {json.dumps(_jsonify(summary), ensure_ascii=False)}")
    return summary