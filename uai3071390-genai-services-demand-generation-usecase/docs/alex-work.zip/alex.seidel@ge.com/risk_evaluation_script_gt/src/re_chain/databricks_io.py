from __future__ import annotations

import json
import os
import time
from pathlib import Path
from typing import Any

import pandas as pd
import requests

from .config import RunConfig, WORKSPACE_DIR, get_dbutils, is_databricks


DEFAULT_HOST = os.getenv(
    "DATABRICKS_HOST",
    "https://gevernova-ai-dev-dbr.cloud.databricks.com",
).rstrip("/")


def sql_escape(value: str) -> str:
    return str(value).replace("'", "''")


def get_workspace_host() -> str:
    dbutils = get_dbutils()
    if dbutils is not None:
        try:
            ctx = dbutils.notebook.entry_point.getDbutils().notebook().getContext()
            return str(ctx.apiUrl().get()).rstrip("/")
        except Exception:
            pass
    return DEFAULT_HOST


def get_workspace_token() -> str:
    dbutils = get_dbutils()
    if dbutils is not None:
        try:
            ctx = dbutils.notebook.entry_point.getDbutils().notebook().getContext()
            token = str(ctx.apiToken().get()).strip().strip("'\"")
            if token:
                return token
        except Exception:
            pass

    env_token = os.getenv("DATABRICKS_TOKEN", "").strip().strip("'\"")
    if env_token:
        return env_token

    token_file = WORKSPACE_DIR / "dbr_token.txt"
    if token_file.exists():
        return token_file.read_text(encoding="utf-8").strip().strip("'\"")

    return ""


def _headers(token: str, *, json_content: bool = False) -> dict[str, str]:
    headers = {"Authorization": f"Bearer {token}"}
    if json_content:
        headers["Content-Type"] = "application/json"
    return headers


def _api_json(method: str, path: str, token: str, **kwargs: Any) -> dict[str, Any]:
    host = get_workspace_host()
    response = requests.request(
        method,
        f"{host}/api/2.0/{path}",
        headers=_headers(token, json_content="json" in kwargs),
        timeout=kwargs.pop("timeout", 60),
        **kwargs,
    )
    if response.status_code not in (200, 201):
        raise RuntimeError(
            f"API {method.upper()} /{path} -> HTTP {response.status_code}\n{response.text[:1000]}"
        )
    return response.json() if response.text.strip() else {}


def run_sql_query(query: str, config: RunConfig) -> pd.DataFrame:
    if is_databricks():
        from pyspark.sql import SparkSession

        spark = SparkSession.builder.getOrCreate()
        return spark.sql(query).toPandas()

    token = get_workspace_token()
    if not token:
        raise RuntimeError("Databricks token not found for SQL query execution.")

    body = _api_json(
        "POST",
        "sql/statements",
        token,
        json={
            "statement": query,
            "warehouse_id": config.sql_warehouse_id,
            "wait_timeout": "50s",
        },
        timeout=120,
    )
    state = body.get("status", {}).get("state", "")
    statement_id = body.get("statement_id", "")

    poll_count = 0
    while state in {"PENDING", "RUNNING"} and statement_id and poll_count < 30:
        time.sleep(5)
        poll_count += 1
        body = _api_json("GET", f"sql/statements/{statement_id}", token)
        state = body.get("status", {}).get("state", "")

    if state == "FAILED":
        error = body.get("status", {}).get("error", {}).get("message", "Unknown SQL failure")
        raise RuntimeError(f"SQL failed: {error}\nStatement: {query[:400]}")

    manifest = body.get("manifest", {}) or {}
    schema = (manifest.get("schema", {}) or {}).get("columns", [])
    columns = [column.get("name") for column in schema]
    rows = ((body.get("result", {}) or {}).get("data_array") or [])
    if not columns:
        return pd.DataFrame()
    return pd.DataFrame(rows, columns=columns)


def query_vector_search(
    query_text: str,
    serial_number: str,
    config: RunConfig,
    *,
    num_results: int,
    columns: list[str],
    query_type: str = "HYBRID",
) -> list[dict[str, Any]]:
    token = get_workspace_token()
    if not token:
        raise RuntimeError("Databricks token not found for Vector Search query execution.")

    url = f"{get_workspace_host()}/api/2.0/vector-search/indexes/{config.fsr_vs_index_name}/query"
    response = requests.post(
        url,
        headers=_headers(token, json_content=True),
        json={
            "query_text": query_text,
            "columns": columns,
            "num_results": num_results,
            "query_type": query_type.upper(),
            "filters_json": json.dumps({"generator_serial": serial_number}),
        },
        timeout=60,
        verify=config.verify_ssl,
    )
    if not response.ok:
        raise RuntimeError(
            f"Vector Search query failed HTTP {response.status_code}: {response.text[:500]}"
        )

    data = response.json()
    manifest_columns = [column["name"] for column in data.get("manifest", {}).get("columns", [])]
    rows = data.get("result", {}).get("data_array", [])

    results: list[dict[str, Any]] = []
    for row in rows:
        row_dict = {column: row[index] for index, column in enumerate(manifest_columns)}
        results.append(row_dict)
    return results