# Databricks notebook source
# Risk Evaluation Batch Pipeline

# COMMAND ----------

import importlib.util
import subprocess
import sys


_REQUIRED_PACKAGES = [
    ("pandas", "pandas"),
    ("requests", "requests"),
    ("python-dotenv", "dotenv"),
    ("openpyxl", "openpyxl"),
    ("tqdm", "tqdm"),
    ("rank-bm25", "rank_bm25"),
]

_missing_packages = [
    package_name
    for package_name, module_name in _REQUIRED_PACKAGES
    if importlib.util.find_spec(module_name) is None
]

if _missing_packages:
    print(f"Installing missing packages: {', '.join(_missing_packages)}")
    subprocess.check_call([sys.executable, "-m", "pip", "install", "--quiet", *_missing_packages])

# COMMAND ----------

import os
import sys
import json
from pathlib import Path


def _parse_bool(raw_value: str, default: bool = False) -> bool:
    if raw_value is None or str(raw_value).strip() == "":
        return default
    return str(raw_value).strip().lower() in {"1", "true", "t", "yes", "y", "on"}


def _parse_int(raw_value: str):
    if raw_value is None or str(raw_value).strip() == "":
        return None
    return int(str(raw_value).strip())


try:
    _ctx = dbutils.notebook.entry_point.getDbutils().notebook().getContext()
    _nb_path = _ctx.notebookPath().get()
    _ws_dir = "/Workspace" + str(Path(_nb_path).parent)
    _src_dir = _ws_dir + "/src"
except Exception:
    _ws_dir = str(Path(__file__).parent)
    _src_dir = str(Path(__file__).parent / "src")

if _src_dir not in sys.path:
    sys.path.insert(0, _src_dir)

from re_chain.config import RunConfig

print(f"[OK] project dir: {_ws_dir}")
print(f"[OK] src path:    {_src_dir}")

# COMMAND ----------

defaults = RunConfig()

FORCE_RERUN = defaults.force_rerun
DRY_RUN = defaults.dry_run
MAX_SERIALS = defaults.max_serials
MAX_ISSUES = defaults.max_issues
SERIALS_OVERRIDE = ""
ISSUES_OVERRIDE = ""
OUTPUT_CSV_OVERRIDE = ""
MODEL_NAME_OVERRIDE = ""
SECRET_SCOPE_OVERRIDE = ""
MAX_FSR_CHUNKS_OVERRIDE = None
MAX_ER_CHUNKS_OVERRIDE = None
MAX_CHUNK_CHARS_OVERRIDE = None
MAX_WORKERS_OVERRIDE = None

try:
    FORCE_RERUN = _parse_bool(dbutils.widgets.get("FORCE_RERUN"), FORCE_RERUN)
except Exception:
    pass

try:
    DRY_RUN = _parse_bool(dbutils.widgets.get("DRY_RUN"), DRY_RUN)
except Exception:
    pass

try:
    MAX_SERIALS = _parse_int(dbutils.widgets.get("MAX_SERIALS"))
except Exception:
    pass

try:
    MAX_ISSUES = _parse_int(dbutils.widgets.get("MAX_ISSUES"))
except Exception:
    pass

try:
    _value = dbutils.widgets.get("SERIALS_OVERRIDE")
    if str(_value).strip():
        SERIALS_OVERRIDE = str(_value).strip()
except Exception:
    pass

try:
    _value = dbutils.widgets.get("ISSUES_OVERRIDE")
    if str(_value).strip():
        ISSUES_OVERRIDE = str(_value).strip()
except Exception:
    pass

try:
    _value = dbutils.widgets.get("OUTPUT_CSV_OVERRIDE")
    if str(_value).strip():
        OUTPUT_CSV_OVERRIDE = str(_value).strip()
except Exception:
    pass

try:
    _value = dbutils.widgets.get("MODEL_NAME_OVERRIDE")
    if str(_value).strip():
        MODEL_NAME_OVERRIDE = str(_value).strip()
except Exception:
    pass

try:
    _value = dbutils.widgets.get("SECRET_SCOPE_OVERRIDE")
    if str(_value).strip():
        SECRET_SCOPE_OVERRIDE = str(_value).strip()
except Exception:
    pass

try:
    _value = _parse_int(dbutils.widgets.get("MAX_FSR_CHUNKS_OVERRIDE"))
    if _value is not None:
        MAX_FSR_CHUNKS_OVERRIDE = _value
except Exception:
    pass

try:
    _value = _parse_int(dbutils.widgets.get("MAX_ER_CHUNKS_OVERRIDE"))
    if _value is not None:
        MAX_ER_CHUNKS_OVERRIDE = _value
except Exception:
    pass

try:
    _value = _parse_int(dbutils.widgets.get("MAX_CHUNK_CHARS_OVERRIDE"))
    if _value is not None:
        MAX_CHUNK_CHARS_OVERRIDE = _value
except Exception:
    pass

try:
    _value = _parse_int(dbutils.widgets.get("MAX_WORKERS_OVERRIDE"))
    if _value is not None:
        MAX_WORKERS_OVERRIDE = _value
except Exception:
    pass

print(f"FORCE_RERUN: {FORCE_RERUN}")
print(f"DRY_RUN: {DRY_RUN}")
print(f"MAX_SERIALS: {MAX_SERIALS}")
print(f"MAX_ISSUES: {MAX_ISSUES}")
print(f"SERIALS_OVERRIDE: {SERIALS_OVERRIDE or '[all]'}")
print(f"ISSUES_OVERRIDE: {ISSUES_OVERRIDE or '[all]'}")
print(f"SECRET_SCOPE_OVERRIDE: {SECRET_SCOPE_OVERRIDE or '[config default]'}")
print(f"MAX_FSR_CHUNKS_OVERRIDE: {MAX_FSR_CHUNKS_OVERRIDE if MAX_FSR_CHUNKS_OVERRIDE is not None else '[config default]'}")
print(f"MAX_ER_CHUNKS_OVERRIDE: {MAX_ER_CHUNKS_OVERRIDE if MAX_ER_CHUNKS_OVERRIDE is not None else '[config default]'}")
print(f"MAX_CHUNK_CHARS_OVERRIDE: {MAX_CHUNK_CHARS_OVERRIDE if MAX_CHUNK_CHARS_OVERRIDE is not None else '[config default]'}")
print(f"MAX_WORKERS_OVERRIDE: {MAX_WORKERS_OVERRIDE if MAX_WORKERS_OVERRIDE is not None else '[config default]'}")

# COMMAND ----------

from re_chain.pipeline import main


output_csv = OUTPUT_CSV_OVERRIDE or None

summary = main(
    force_rerun=FORCE_RERUN,
    serials=SERIALS_OVERRIDE or None,
    issues=ISSUES_OVERRIDE or None,
    max_serials=MAX_SERIALS,
    max_issues=MAX_ISSUES,
    output_csv=output_csv,
    model_name=MODEL_NAME_OVERRIDE or None,
    secret_scope=SECRET_SCOPE_OVERRIDE or None,
    dry_run=DRY_RUN,
    max_fsr_chunks=MAX_FSR_CHUNKS_OVERRIDE,
    max_er_chunks=MAX_ER_CHUNKS_OVERRIDE,
    max_chunk_chars=MAX_CHUNK_CHARS_OVERRIDE,
    max_workers=MAX_WORKERS_OVERRIDE,
)

print(f"\nRun dir: {summary.get('run_dir', '[unknown]')}")
print(f"Local run dir: {summary.get('local_run_dir', '[unknown]')}")
print(f"\nOutput CSV: {summary['output_csv']}")
print(f"Local output CSV: {summary.get('local_output_csv', summary['output_csv'])}")
print(f"Condensed CSV: {summary.get('condensed_output_csv') or '[not written]'}")
print(f"Config JSON: {summary.get('config_json_path') or '[not written]'}")
print("\nRun summary JSON:")
print(json.dumps(summary, indent=2, ensure_ascii=False))

# COMMAND ----------

try:
    import pandas as pd

    preview_path = summary.get("local_output_csv") or summary["output_csv"]
    preview_df = pd.read_csv(preview_path).tail(20)
    print("\nResult preview:")
    print(preview_df.to_csv(index=False))
    display(preview_df)
except Exception as exc:
    print(f"Preview skipped: {exc}")