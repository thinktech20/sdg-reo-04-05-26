# Databricks notebook source
# REChain extracted runtime notebook wrapper

# COMMAND ----------

import importlib.util
import subprocess
import sys


_REQUIRED_PACKAGES = [
    ("pandas", "pandas"),
    ("requests", "requests"),
    ("python-dotenv", "dotenv"),
    ("openpyxl", "openpyxl"),
    ("tqdm", "tqdm"),
    ("rank-bm25", "rank_bm25"),
    ("databricks-sql-connector", "databricks.sql"),
]

_missing_packages = [
    package_name
    for package_name, module_name in _REQUIRED_PACKAGES
    if importlib.util.find_spec(module_name) is None
]

if _missing_packages:
    print(f"Installing missing packages: {', '.join(_missing_packages)}")
    subprocess.check_call([sys.executable, "-m", "pip", "install", "--quiet", *_missing_packages])

# COMMAND ----------

if "dbutils" in globals():
    dbutils.library.restartPython()

# COMMAND ----------

import os
import sys
from pathlib import Path


def _parse_bool(raw_value: str, default: bool = False) -> bool:
    if raw_value is None or str(raw_value).strip() == "":
        return default
    return str(raw_value).strip().lower() in {"1", "true", "t", "yes", "y", "on"}


def _widget(name: str, default: str = "") -> str:
    try:
        value = dbutils.widgets.get(name)
        return str(value).strip()
    except Exception:
        return default


try:
    _ctx = dbutils.notebook.entry_point.getDbutils().notebook().getContext()
    _nb_path = _ctx.notebookPath().get()
    _project_dir = "/Workspace" + str(Path(_nb_path).parent)
except Exception:
    _project_dir = str(Path(__file__).parent)

if _project_dir not in sys.path:
    sys.path.insert(0, _project_dir)

_secret_scope = _widget("SECRET_SCOPE_OVERRIDE") or os.getenv("DBR_SECRET_SCOPE", "")
if _secret_scope:
    os.environ["DBR_SECRET_SCOPE"] = _secret_scope

_model_name = _widget("MODEL_NAME_OVERRIDE")
if _model_name:
    os.environ["RE_CHAIN_MODEL"] = _model_name

_max_workers = _widget("MAX_WORKERS_OVERRIDE")
if _max_workers:
    os.environ["RE_CHAIN_MAX_WORKERS"] = _max_workers

_serials_override = _widget("SERIALS_OVERRIDE")
if _serials_override:
    os.environ["RE_CHAIN_SERIALS_OVERRIDE"] = _serials_override

_run_name = _widget("RUN_NAME_OVERRIDE")
if _run_name:
    os.environ["RE_CHAIN_RUN_NAME"] = _run_name

_output_csv = _widget("OUTPUT_CSV_OVERRIDE")
if _output_csv:
    os.environ["RE_CHAIN_OUTPUT_CSV_OVERRIDE"] = _output_csv

_er_k = _widget("ER_K_OVERRIDE")
if _er_k:
    os.environ["RE_CHAIN_ER_K"] = _er_k

_fsr_k = _widget("FSR_K_OVERRIDE")
if _fsr_k:
    os.environ["RE_CHAIN_FSR_K"] = _fsr_k

_force_rerun = _widget("FORCE_RERUN")
if _force_rerun:
    os.environ["RE_CHAIN_FORCE_RERUN"] = str(_parse_bool(_force_rerun)).lower()

_dry_run = _widget("DRY_RUN")
if _dry_run:
    os.environ["RE_CHAIN_DRY_RUN"] = str(_parse_bool(_dry_run)).lower()

_run_mode = (_widget("RUN_MODE", "26_esns") or "26_esns").strip().lower()

print(f"[OK] project dir: {_project_dir}")
print(f"[OK] run mode:    {_run_mode}")
print(f"[OK] serials:     {_serials_override or '[default]'}")
print(f"[OK] output csv:  {_output_csv or '[default]'}")
print(f"[OK] run name:    {_run_name or '[default]'}")

# COMMAND ----------

if _run_mode == "general":
    import launcher_general as _runner
elif _run_mode == "26_esns":
    import launcher_26_esns as _runner
else:
    raise ValueError(f"Unsupported RUN_MODE '{_run_mode}'. Use '26_esns' or 'general'.")

_runner.main()