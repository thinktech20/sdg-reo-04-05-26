# Databricks Deployment Notes

This folder is a Databricks-ready copy of the extracted REChain runtime.

Files added for Databricks execution:

- `run_pipeline_dbr.py`
  - Workspace notebook wrapper.
  - Installs required packages, reads widget overrides, sets environment variables, and runs either the 26-ESN launcher or the general launcher.
- `deploy.py`
  - Uploads this folder into the Databricks workspace.
- `_submit_run.py`
  - Submits the uploaded notebook as a Databricks job run on an existing cluster.

Key DBR behavior:

- Databricks SQL / Vector Search token resolution falls back to the notebook context API token.
- LiteLLM API key resolution falls back to Databricks secret scope `DBR_SECRET_SCOPE`.
- Local IBAT fallback includes `30_serial_IBAT.csv` packaged under `REChainExperiment/`.

Suggested flow:

1. Deploy:
   `python deploy.py --workspace-path /Users/<you>/REChain_new_extracted_20260318_dbr`
2. Open the uploaded notebook `run_pipeline` in Databricks and run it interactively, or submit a job with:
   `python _submit_run.py --workspace-root /Users/<you>/REChain_new_extracted_20260318_dbr --wait`