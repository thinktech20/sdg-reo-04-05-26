"""Step 3: Query IBAT equipment metadata from Databricks for a given serial number."""

from __future__ import annotations

import csv
import os
from pathlib import Path
from typing import Dict, List

from .config import (
    get_db_connection,
    IBAT_EQUIPMENT_VIEW,
    IBAT_PLANT_VIEW,
    IBAT_TRAIN_VIEW,
    PROJECT_DIR,
)


IBAT_EQUIPMENT_COLUMNS = (
    "equipment_type", "equipment_name", "sales_channel", "equipment_sys_id",
    "contract_type", "equipment_code", "equipment_class", "block_sys_id_fk",
    "plant_sys_id_fk", "train_sys_id_fk", "actualized_flag", "duty_cycle",
    "equip_serial_number", "rotor_rewind", "stator_rewind", "cooling_system",
)
IBAT_PLANT_COLUMNS = (
    "site_customer_name", "plant_name", "site_country", "site_state",
    "hyp_sub_region", "ps_pole", "cust_gegul_name", "industry",
)
IBAT_TRAIN_COLUMNS = ("fuel_type",)

_IBAT_FALLBACK_RELATIVE_PATHS = (
    Path("REChainExperiment") / "30_serial_IBAT.csv",
    Path("risk_evaluation_script_gt_20260318_copy") / "input data" / "30_serial_IBAT.csv",
    Path("risk_evaluation_script_gt_20260318_copy") / "input data" / "7_serial_IBAT.csv",
    Path("risk_evaluation_script_gt") / "input data" / "7_serial_IBAT.csv",
    Path("risk_evaluation_script") / "input data" / "7_serial_IBAT.csv",
)


def query_ibat(serial_number: str) -> List[Dict]:
    """
    Query IBAT equipment + plant + train tables joined by serial number.

    Args:
        serial_number: e.g. "290T658"

    Returns:
        List of dicts with equipment, plant, and train metadata
    """
    try:
        rows = _query_ibat_live(serial_number)
    except Exception as exc:
        print(f"[IBAT] Live query failed for serial='{serial_number}': {exc}")
        rows = _query_ibat_fallback(serial_number)
        if rows:
            return rows
        raise RuntimeError(
            f"IBAT lookup failed for serial '{serial_number}' from Databricks and no local fallback row was found."
        ) from exc

    if rows:
        print(f"[IBAT] Found {len(rows)} live row(s) for serial_number='{serial_number}'")
        return rows

    rows = _query_ibat_fallback(serial_number)
    if rows:
        return rows

    raise LookupError(
        f"IBAT lookup returned no rows for serial '{serial_number}' and no local fallback row was found."
    )


def _query_ibat_live(serial_number: str) -> List[Dict]:
    e_cols = ", ".join(f"e.{c}" for c in IBAT_EQUIPMENT_COLUMNS)
    p_cols = ", ".join(f"p.{c}" for c in IBAT_PLANT_COLUMNS)
    t_cols = ", ".join(f"t.{c}" for c in IBAT_TRAIN_COLUMNS)

    query = f"""
        SELECT DISTINCT {e_cols}, {p_cols}, {t_cols}
        FROM {IBAT_EQUIPMENT_VIEW} e
        LEFT JOIN {IBAT_PLANT_VIEW} p ON e.plant_sys_id_fk = p.plant_sys_id
        LEFT JOIN {IBAT_TRAIN_VIEW} t ON e.train_sys_id_fk = t.train_sys_id
        WHERE e.equip_serial_number = '{_escape(serial_number)}'
        LIMIT 50
    """

    with get_db_connection() as conn:
        with conn.cursor() as cursor:
            cursor.execute(query)
            columns = [desc[0] for desc in cursor.description]
            return [dict(zip(columns, row)) for row in cursor.fetchall()]


def _query_ibat_fallback(serial_number: str) -> List[Dict]:
    normalized_serial = str(serial_number).strip()
    for csv_path in _iter_fallback_csv_paths():
        try:
            with csv_path.open("r", encoding="utf-8-sig", newline="") as handle:
                reader = csv.DictReader(handle)
                matches = []
                for row in reader:
                    if str(row.get("equip_serial_number", "")).strip() != normalized_serial:
                        continue
                    matches.append(_normalize_ibat_fallback_row(row, csv_path))
                if matches:
                    print(
                        f"[IBAT] Using {len(matches)} fallback row(s) from '{csv_path}' for serial_number='{normalized_serial}'"
                    )
                    return matches
        except OSError as exc:
            print(f"[IBAT] Could not read fallback CSV '{csv_path}': {exc}")
    return []


def _iter_fallback_csv_paths() -> List[Path]:
    seen: set[Path] = set()

    env_path = os.getenv("RE_CHAIN_IBAT_FALLBACK_CSV", "").strip()
    if env_path:
        candidate = Path(env_path).expanduser().resolve()
        if candidate.exists() and candidate not in seen:
            seen.add(candidate)
            yield candidate

    roots = [PROJECT_DIR, *list(PROJECT_DIR.parents[:2])]
    for root in roots:
        for relative_path in _IBAT_FALLBACK_RELATIVE_PATHS:
            candidate = (root / relative_path).resolve()
            if candidate.exists() and candidate not in seen:
                seen.add(candidate)
                yield candidate


def _normalize_ibat_fallback_row(row: Dict[str, str], source_path: Path) -> Dict[str, str]:
    normalized = {key: _clean_csv_value(value) for key, value in row.items()}
    if normalized.get("equipment_name") and not normalized.get("plant_name"):
        normalized["plant_name"] = normalized["equipment_name"]
    normalized["ibat_source"] = str(source_path)
    return normalized


def _clean_csv_value(value: str) -> str:
    text = str(value or "").strip()
    return "" if text.lower() == "null" else text


def _escape(val: str) -> str:
    return str(val).replace("'", "''")
