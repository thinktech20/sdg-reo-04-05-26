"""Step 4: Retrieve FSR (Field Service Report) chunks from Databricks Vector Search."""

import json
import requests
from typing import Dict, List

from .config import VS_WORKSPACE_URL, VS_TOKEN, VS_INDEX_NAME, require_setting
from .retry import RETRIABLE_STATUS_CODES, retry_request
from .vector_embeddings import get_query_vector

RETURN_COLUMNS = [
    "chunk_id", "pdf_name", "page_number", "chunk_text", "generator_serial",
]


def query_fsr(
    serial_number: str,
    query: str,
    k: int = 10,
    query_type: str = "HYBRID",
) -> List[Dict]:
    """
    Query Databricks Vector Search for FSR chunks matching a serial + query.

    Args:
        serial_number: Equipment serial (e.g. "290T658") — filters on generator_serial
        query: Search query text (e.g. issue_prompt + severity criteria)
        k: Number of results to return
        query_type: "HYBRID" (vector + keyword) or "ANN" (vector only)

    Returns:
        List of dicts with chunk_id, pdf_name, page_number, chunk_text,
        generator_serial, score
    """
    token = require_setting(
        VS_TOKEN,
        name="Databricks Vector Search token",
        env_names=("VS_TOKEN", "DATABRICKS_TOKEN", "DB_TOKEN"),
        file_names=("dbr_token.txt",),
    )
    url = f"{VS_WORKSPACE_URL}/api/2.0/vector-search/indexes/{VS_INDEX_NAME}/query"
    headers = {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json",
    }
    query_vector = get_query_vector(query)
    body = {
        "query_text": query,
        "query_vector": query_vector,
        "columns": RETURN_COLUMNS,
        "num_results": k,
        "query_type": query_type.upper(),
        "filters_json": json.dumps({"generator_serial": serial_number}),
    }

    resp = retry_request(
        lambda: requests.post(url, headers=headers, json=body, timeout=60),
        label=f"FSR/{serial_number}",
        retriable_status_codes=RETRIABLE_STATUS_CODES,
    )
    if not resp.ok:
        message = f"FSR query failed HTTP {resp.status_code}: {resp.text[:200]}"
        print(f"[FSR] {message}")
        raise RuntimeError(message)

    data = resp.json()
    col_names = [c["name"] for c in data.get("manifest", {}).get("columns", [])]
    rows = data.get("result", {}).get("data_array", [])

    results = []
    for row in rows:
        row_dict = {col: row[i] for i, col in enumerate(col_names)}
        results.append({
            "chunk_id": row_dict.get("chunk_id", ""),
            "pdf_name": row_dict.get("pdf_name", ""),
            "page_number": row_dict.get("page_number"),
            "chunk_text": row_dict.get("chunk_text", ""),
            "generator_serial": row_dict.get("generator_serial", ""),
            "score": float(row_dict.get("score", 0.0)),
        })

    print(f"[FSR] Found {len(results)} chunks for serial='{serial_number}' ({query_type}, k={k})")
    return results
