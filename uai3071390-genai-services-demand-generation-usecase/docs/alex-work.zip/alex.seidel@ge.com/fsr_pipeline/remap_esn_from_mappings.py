# Databricks notebook source
# ─────────────────────────────────────────────────────────────────────────────
# Remap ESN assignments in field_service_report
#
# 1. Build a unified PDF → ESN mapping from:
#    - fsr_pdf_ref        (s3_filename → esn)
#    - fsr_scraped_file_mapping_ref (pdf_name → esn)
# 2. Collapse existing rows to canonical chunks (one per pdf_name + base_chunk_id),
#    preferring rows that already have embeddings.
# 3. Re-expand: cross-join canonical chunks × mapped ESNs.
#    PDFs with no mapping keep a single NULL-serial row.
# 4. Overwrite the table (after creating a timestamped backup).
# ─────────────────────────────────────────────────────────────────────────────

# COMMAND ----------

import os, sys, json
from datetime import datetime
from pathlib import Path

# ── Resolve src/ directory ──────────────────────────────────────────────────
try:
    _ctx     = dbutils.notebook.entry_point.getDbutils().notebook().getContext()
    _nb_path = _ctx.notebookPath().get()
    _ws_dir  = "/Workspace" + str(Path(_nb_path).parent)
    _src_dir = _ws_dir + "/src"
except Exception:
    _src_dir = str(Path(__file__).parent / "src") if "__file__" in dir() else "./src"

if _src_dir not in sys.path:
    sys.path.insert(0, _src_dir)

print(f"[OK] src path: {_src_dir}")

# COMMAND ----------

from pyspark.sql import SparkSession, Window
from pyspark.sql import functions as F

spark = SparkSession.builder.getOrCreate()

# ── Parameters ──────────────────────────────────────────────────────────────

try:
    _emb_table = dbutils.widgets.get("EMBEDDINGS_TABLE_OVERRIDE")
    if _emb_table.strip():
        os.environ["EMBEDDINGS_TABLE"] = _emb_table.strip()
        print(f"EMBEDDINGS_TABLE overridden → {_emb_table.strip()}")
except Exception:
    pass

try:
    _dry_run_param = dbutils.widgets.get("DRY_RUN")
    DRY_RUN = str(_dry_run_param).strip().lower() in {"1", "true", "yes"}
except Exception:
    DRY_RUN = os.getenv("DRY_RUN", "false").strip().lower() in {"1", "true", "yes"}

try:
    _skip_backup_param = dbutils.widgets.get("SKIP_BACKUP")
    SKIP_BACKUP = str(_skip_backup_param).strip().lower() in {"1", "true", "yes"}
except Exception:
    SKIP_BACKUP = os.getenv("SKIP_BACKUP", "false").strip().lower() in {"1", "true", "yes"}

from config import EMBEDDINGS_TABLE

FSR_REF_VIEW     = "vgpd.fsr_std_views.fsr_pdf_ref"
SCRAPED_TABLE    = "main.gp_services_sdg_poc.fsr_scraped_file_mapping_ref"
EMBEDDING_COL    = "embeddings"

print(f"EMBEDDINGS_TABLE = {EMBEDDINGS_TABLE}")
print(f"FSR_REF_VIEW     = {FSR_REF_VIEW}")
print(f"SCRAPED_TABLE    = {SCRAPED_TABLE}")
print(f"DRY_RUN          = {DRY_RUN}")
print(f"SKIP_BACKUP      = {SKIP_BACKUP}")

# COMMAND ----------

# ── STEP 1: Build unified PDF → ESN mapping ────────────────────────────────

print("=" * 80)
print("STEP 1: Build unified PDF → ESN mapping from two sources")
print("=" * 80)

# Source A: fsr_pdf_ref  (s3_filename is a UUID; strip .pdf → pdf_name)
ref_mapping = spark.sql(f"""
    SELECT DISTINCT
        regexp_replace(lower(s3_filename), '\\.pdf$', '') AS pdf_name,
        UPPER(TRIM(esn)) AS esn
    FROM {FSR_REF_VIEW}
    WHERE s3_filename IS NOT NULL
      AND esn IS NOT NULL
      AND TRIM(esn) != ''
""")
ref_count = ref_mapping.count()
print(f"  fsr_pdf_ref pairs     : {ref_count}")

# Source B: scraped table (pdf_name → esn)
scraped_mapping = spark.sql(f"""
    SELECT DISTINCT
        pdf_name,
        UPPER(TRIM(esn)) AS esn
    FROM {SCRAPED_TABLE}
    WHERE pdf_name IS NOT NULL
      AND esn IS NOT NULL
      AND TRIM(esn) != ''
""")
scraped_count = scraped_mapping.count()
print(f"  scraped_table pairs   : {scraped_count}")

# Union & deduplicate
unified = ref_mapping.union(scraped_mapping).distinct().cache()
unified_count = unified.count()
unified_pdf_count = unified.select("pdf_name").distinct().count()
unified_esn_count = unified.select("esn").distinct().count()

print(f"  Unified (PDF, ESN) pairs : {unified_count}")
print(f"  Unique PDFs mapped       : {unified_pdf_count}")
print(f"  Unique ESNs mapped       : {unified_esn_count}")

# COMMAND ----------

# ── STEP 2: Read current table and compute canonical chunks ─────────────────

print("=" * 80)
print("STEP 2: Read table & compute canonical chunks (prefer embedded)")
print("=" * 80)

fsr = spark.table(EMBEDDINGS_TABLE).cache()
total_before = fsr.count()
pdf_count_before = fsr.select("pdf_name").distinct().count()
print(f"  Total rows before    : {total_before}")
print(f"  Distinct PDFs before : {pdf_count_before}")

# Compute base_chunk_id: strip __ESN suffix
fsr_with_base = fsr.withColumn(
    "base_chunk_id",
    F.when(
        F.col("chunk_id").contains("__"),
        F.expr("substring(chunk_id, 1, locate('__', chunk_id) - 1)")
    ).otherwise(F.col("chunk_id"))
)

# Rank within (pdf_name, base_chunk_id): prefer rows WITH embeddings,
# then most-recently created
has_emb = F.when(
    (F.col(EMBEDDING_COL).isNotNull()) & (F.size(F.col(EMBEDDING_COL)) > 0),
    F.lit(0)   # sort first
).otherwise(F.lit(1))

w = Window.partitionBy("pdf_name", "base_chunk_id").orderBy(
    has_emb,
    F.col("created_at").desc_nulls_last()
)

canonicals = (
    fsr_with_base
    .withColumn("_rn", F.row_number().over(w))
    .filter("_rn = 1")
    .drop("_rn")
)

canonical_count = canonicals.count()
canonical_with_emb = canonicals.filter(
    (F.col(EMBEDDING_COL).isNotNull()) & (F.size(F.col(EMBEDDING_COL)) > 0)
).count()
print(f"  Canonical chunks     : {canonical_count}")
print(f"    with embedding     : {canonical_with_emb}")
print(f"    without embedding  : {canonical_count - canonical_with_emb}")

# COMMAND ----------

# ── STEP 3: Split into mapped / unmapped PDFs ──────────────────────────────

print("=" * 80)
print("STEP 3: Split canonical chunks into mapped vs unmapped PDFs")
print("=" * 80)

mapped_pdf_df = unified.select("pdf_name").distinct()

# Canonical chunks whose PDF has at least one ESN mapping
canonicals_mapped   = canonicals.join(F.broadcast(mapped_pdf_df), "pdf_name", "inner")
# Canonical chunks whose PDF has NO ESN mapping anywhere
canonicals_unmapped = canonicals.join(F.broadcast(mapped_pdf_df), "pdf_name", "left_anti")

n_mapped   = canonicals_mapped.count()
n_unmapped = canonicals_unmapped.count()
print(f"  Canonical chunks with ESN mapping   : {n_mapped}")
print(f"  Canonical chunks with no ESN mapping : {n_unmapped}")

# COMMAND ----------

# ── STEP 4: Expand mapped chunks × ESNs ────────────────────────────────────

print("=" * 80)
print("STEP 4: Expand mapped canonical chunks × ESN mapping")
print("=" * 80)

# Join canonicals_mapped with unified mapping to expand
expanded = (
    canonicals_mapped
    .join(unified, "pdf_name", "inner")
    # Build new chunk_id: base_chunk_id__ESN
    .withColumn("chunk_id", F.concat(F.col("base_chunk_id"), F.lit("__"), F.col("esn")))
    .withColumn("generator_serial", F.col("esn"))
    .drop("esn")
)

expanded_count = expanded.count()
print(f"  Expanded rows (mapped)  : {expanded_count}")

# For unmapped PDFs: keep the canonical row as-is
# Reset generator_serial to NULL since we have no mapping
unmapped = (
    canonicals_unmapped
    .withColumn("generator_serial", F.lit(None).cast("string"))
    # Keep chunk_id as base_chunk_id (already the canonical value)
    .withColumn("chunk_id", F.col("base_chunk_id"))
)

unmapped_count = unmapped.count()
print(f"  Unmapped rows (kept)    : {unmapped_count}")

# COMMAND ----------

# ── STEP 5: Combine and prepare final DataFrame ────────────────────────────

print("=" * 80)
print("STEP 5: Combine → final table")
print("=" * 80)

# Drop the helper column before union
expanded_clean = expanded.drop("base_chunk_id")
unmapped_clean = unmapped.drop("base_chunk_id")

# Align columns to the original schema (same column order)
original_cols = [f.name for f in fsr.schema.fields]
result = expanded_clean.select(*original_cols).unionByName(
    unmapped_clean.select(*original_cols)
)

result_count = result.count()
result_pdfs  = result.select("pdf_name").distinct().count()
result_esns  = result.filter(
    (F.col("generator_serial").isNotNull()) & (F.col("generator_serial") != "")
).select("generator_serial").distinct().count()
result_with_emb = result.filter(
    (F.col(EMBEDDING_COL).isNotNull()) & (F.size(F.col(EMBEDDING_COL)) > 0)
).count()

print(f"  BEFORE: {total_before} rows, {pdf_count_before} PDFs")
print(f"  AFTER:  {result_count} rows, {result_pdfs} PDFs, {result_esns} ESNs")
print(f"  Rows with embedding: {result_with_emb}")
print(f"  Rows without embedding: {result_count - result_with_emb}")

# COMMAND ----------

# ── STEP 6: Backup and overwrite ───────────────────────────────────────────

print("=" * 80)
print("STEP 6: Backup current table and overwrite")
print("=" * 80)

ts = datetime.utcnow().strftime("%Y%m%d_%H%M%S")
backup_table = f"{EMBEDDINGS_TABLE}_backup_esn_remap_{ts}"

if DRY_RUN:
    print(f"  [DRY RUN] Would back up to: {backup_table}")
    print(f"  [DRY RUN] Would overwrite {EMBEDDINGS_TABLE} with {result_count} rows")
    print("  Skipping write.")
else:
    if SKIP_BACKUP:
        print("  SKIP_BACKUP=true — skipping backup (Delta time travel available)")
    else:
        print(f"  Creating backup: {backup_table}")
        spark.sql(f"CREATE TABLE {backup_table} AS SELECT * FROM {EMBEDDINGS_TABLE}")
        backup_count = spark.table(backup_table).count()
        print(f"  Backup created: {backup_count} rows")

    # Overwrite the target table
    print(f"  Overwriting {EMBEDDINGS_TABLE} ...")
    (
        result
        .write
        .format("delta")
        .mode("overwrite")
        .option("overwriteSchema", "true")
        .saveAsTable(EMBEDDINGS_TABLE)
    )
    final_count = spark.table(EMBEDDINGS_TABLE).count()
    print(f"  Done. Final row count: {final_count}")

# COMMAND ----------

# ── STEP 7: Post-write verification ────────────────────────────────────────

print("=" * 80)
print("STEP 7: Verification")
print("=" * 80)

verify = spark.sql(f"""
    SELECT
        COUNT(*)                                                              AS total_rows,
        COUNT(DISTINCT pdf_name)                                              AS distinct_pdfs,
        COUNT(DISTINCT generator_serial)                                      AS distinct_esns,
        SUM(CASE WHEN generator_serial IS NULL OR generator_serial = ''
                 THEN 1 ELSE 0 END)                                          AS null_serial_rows,
        SUM(CASE WHEN {EMBEDDING_COL} IS NOT NULL AND size({EMBEDDING_COL}) > 0
                 THEN 1 ELSE 0 END)                                          AS rows_with_embedding,
        SUM(CASE WHEN {EMBEDDING_COL} IS NULL OR size({EMBEDDING_COL}) = 0
                 THEN 1 ELSE 0 END)                                          AS rows_without_embedding
    FROM {EMBEDDINGS_TABLE}
""").collect()[0]

print(f"  Total rows           : {verify['total_rows']}")
print(f"  Distinct PDFs        : {verify['distinct_pdfs']}")
print(f"  Distinct ESNs        : {verify['distinct_esns']}")
print(f"  NULL serial rows     : {verify['null_serial_rows']}")
print(f"  With embedding       : {verify['rows_with_embedding']}")
print(f"  Without embedding    : {verify['rows_without_embedding']}")

# Show a sample of the largest ESN expansions
print("\n  Top 15 ESNs by chunk count (post-remap):")
top = spark.sql(f"""
    SELECT generator_serial AS esn,
           COUNT(DISTINCT pdf_name) AS pdf_count,
           COUNT(*) AS chunk_count
    FROM {EMBEDDINGS_TABLE}
    WHERE generator_serial IS NOT NULL AND generator_serial != ''
    GROUP BY generator_serial
    ORDER BY chunk_count DESC
    LIMIT 15
""").collect()
for row in top:
    print(f"    {row['esn']}: {row['pdf_count']} PDFs, {row['chunk_count']} chunks")

print("\n  Top 10 PDFs by ESN count (post-remap):")
top_pdfs = spark.sql(f"""
    SELECT pdf_name,
           COUNT(DISTINCT generator_serial) AS esn_count,
           COUNT(*) AS total_rows
    FROM {EMBEDDINGS_TABLE}
    WHERE generator_serial IS NOT NULL AND generator_serial != ''
    GROUP BY pdf_name
    ORDER BY esn_count DESC
    LIMIT 10
""").collect()
for row in top_pdfs:
    print(f"    {row['pdf_name'][:60]}: {row['esn_count']} ESNs, {row['total_rows']} rows")
