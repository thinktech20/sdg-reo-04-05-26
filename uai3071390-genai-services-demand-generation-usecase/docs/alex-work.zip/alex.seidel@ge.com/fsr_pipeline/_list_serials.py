# Databricks notebook source
# Quick check: all distinct generator_serial values in the Delta table

# COMMAND ----------

from pyspark.sql import SparkSession
from pyspark.sql import functions as F

spark = SparkSession.builder.getOrCreate()
TABLE = "main.gp_services_sdg_poc.field_service_report"

df = spark.table(TABLE)
total = df.count()
null_count = df.filter(F.col("generator_serial").isNull()).count()
serials = sorted([
    r["generator_serial"]
    for r in df.filter(F.col("generator_serial").isNotNull())
               .select("generator_serial").distinct().collect()
])

print(f"Total chunks : {total}")
print(f"NULL serial  : {null_count}")
print(f"Distinct serials ({len(serials)}):")
for s in serials:
    print(f"  {s}")

# Also show chunk counts per serial so we can see which are GT serials
print("\n=== Chunk count per serial ===")
df.groupBy("generator_serial").count().orderBy("generator_serial").show(300, truncate=False)
