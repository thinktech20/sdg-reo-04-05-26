# Databricks notebook source
# ─────────────────────────────────────────────────────────────────────────────
# FSR Embedding Backfill — Watchdog / Auto-Restart Wrapper
#
# Calls backfill_table_embeddings as a child notebook in a retry loop.
# If the child crashes (disk full, Spark error, gateway timeout), this notebook
# catches the exception, waits RESTART_DELAY_S seconds, and re-runs.
# Because the child runs in a separate process via dbutils.notebook.run(),
# its failures are isolated — this wrapper stays alive.
#
# Stops when:
#   - Child exits cleanly (returns a result not containing "error")
#   - Child returns "Nothing to backfill" (all rows done)
#   - MAX_ATTEMPTS is reached
#
# PARAMETERS (same as backfill_table_embeddings, plus):
#   MAX_ATTEMPTS       — max restart attempts before giving up  (default: 50)
#   RESTART_DELAY_S    — seconds to wait between restarts       (default: 60)
#   CHILD_TIMEOUT_S    — per-child timeout in seconds, 0=none   (default: 0)
# ─────────────────────────────────────────────────────────────────────────────

# COMMAND ----------

import time
from pathlib import Path

def _w(name: str, default: str = "") -> str:
    try:
        v = dbutils.widgets.get(name)
        return str(v).strip() if v is not None else default
    except Exception:
        return default

def _to_int(raw: str, default: int, minimum: int = 1) -> int:
    try:
        return max(minimum, int(raw.strip()))
    except Exception:
        return default

# ── Watchdog parameters ──────────────────────────────────────────────────────
MAX_ATTEMPTS      = _to_int(_w("MAX_ATTEMPTS",    "50"), 50,  minimum=1)
RESTART_DELAY_S   = _to_int(_w("RESTART_DELAY_S", "60"), 60,  minimum=10)
CHILD_TIMEOUT_S   = _to_int(_w("CHILD_TIMEOUT_S", "0"),  0,   minimum=0)

# ── VS sync parameters ───────────────────────────────────────────────────────
VS_INDEX_NAME    = _w("VS_INDEX_NAME",    "main.gp_services_sdg_poc.vs_field_service_report")
VS_ENDPOINT_NAME = _w("VS_ENDPOINT_NAME", "pw-ser-sdg-vector-search")
DBR_HOST         = _w("DATABRICKS_HOST",  "https://gevernova-ai-dev-dbr.cloud.databricks.com")
SECRET_SCOPE     = _w("SECRET_SCOPE_OVERRIDE", "fsr-pipeline")

# ── Passthrough parameters for the child notebook ────────────────────────────
child_args = {
    k: _w(k, d) for k, d in [
        ("EMBEDDINGS_TABLE_OVERRIDE", ""),
        ("EMBEDDING_VECTOR_COLUMN",   ""),
        ("EMBEDDING_BATCH_SIZE",      "64"),
        ("N_EMBED_WORKERS",           "8"),
        ("MERGE_BATCH_SIZE",          "2000"),
        ("EMBEDDING_MAX_RETRIES",     "4"),
        ("EMBEDDING_TIMEOUT_SEC",     "180"),
        ("EMBEDDING_TEXT_MAX_CHARS",  "12000"),
        ("EMBEDDING_LIMIT_ROWS",      ""),
        ("DRY_RUN",                   "false"),
        ("SECRET_SCOPE_OVERRIDE",     "fsr-pipeline"),
        ("ESN_FILTER",                ""),
    ]
}
# Remove blank passthrough args to keep the call clean
child_args = {k: v for k, v in child_args.items() if v}

# ── Locate the child notebook (same folder as this one) ──────────────────────
try:
    _ctx     = dbutils.notebook.entry_point.getDbutils().notebook().getContext()
    _nb_path = _ctx.notebookPath().get()
    child_nb = str(Path(_nb_path).parent / "backfill_table_embeddings")
except Exception:
    child_nb = "./backfill_table_embeddings"

print("=" * 72)
print("FSR EMBEDDING BACKFILL — WATCHDOG WRAPPER")
print("=" * 72)
print(f"  Child notebook  : {child_nb}")
print(f"  Max attempts    : {MAX_ATTEMPTS}")
print(f"  Restart delay   : {RESTART_DELAY_S}s")
print(f"  Child timeout   : {CHILD_TIMEOUT_S}s  (0 = no limit)")
print(f"  VS index        : {VS_INDEX_NAME}")
print(f"  Child args      : {child_args}")

# COMMAND ----------

success_phrases = {"nothing to backfill", "dry_run=true"}

for attempt in range(1, MAX_ATTEMPTS + 1):
    print(f"\n{'─'*72}")
    print(f"[Watchdog] Attempt {attempt}/{MAX_ATTEMPTS}  —  {time.strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"{'─'*72}")
    try:
        result = dbutils.notebook.run(
            child_nb,
            timeout_seconds=CHILD_TIMEOUT_S,
            arguments=child_args,
        )
        print(f"[Watchdog] Child exited cleanly. Result: {result!r}")
        # Done — child either finished all rows or was a dry-run
        if any(p in result.lower() for p in success_phrases):
            print("[Watchdog] All rows processed (or dry-run). Done.")
            break
        # Child returned something unexpected — stop to avoid infinite loop
        print("[Watchdog] Unexpected result — stopping.")
        dbutils.notebook.exit(f"STOPPED (unexpected result): {result}")
    except Exception as exc:
        msg = str(exc)[:300]
        print(f"[Watchdog] Child FAILED on attempt {attempt}: {msg}")
        if attempt >= MAX_ATTEMPTS:
            print(f"[Watchdog] Reached MAX_ATTEMPTS={MAX_ATTEMPTS}. Giving up.")
            raise RuntimeError(f"Backfill failed after {MAX_ATTEMPTS} attempts. Last error: {msg}")
        print(f"[Watchdog] Restarting in {RESTART_DELAY_S}s …")
        time.sleep(RESTART_DELAY_S)

# COMMAND ----------

# ── Trigger VS index sync on completion ──────────────────────────────────────

import requests

print(f"\nTriggering VS index sync: {VS_INDEX_NAME} …")

def _get_token():
    try:
        return dbutils.secrets.get(scope=SECRET_SCOPE, key="DATABRICKS_TOKEN")
    except Exception:
        pass
    try:
        ctx = dbutils.notebook.entry_point.getDbutils().notebook().getContext()
        return ctx.apiToken().get()
    except Exception:
        return ""

token   = _get_token()
headers = {"Authorization": f"Bearer {token}", "Content-Type": "application/json"}

# Wait for endpoint ONLINE
for _ep_try in range(12):
    ep_resp = requests.get(
        f"{DBR_HOST}/api/2.0/vector-search/endpoints/{VS_ENDPOINT_NAME}",
        headers=headers, timeout=30, verify=False,
    )
    if ep_resp.ok and ep_resp.json().get("endpoint_status", {}).get("state") == "ONLINE":
        print(f"  [OK] Endpoint {VS_ENDPOINT_NAME} is ONLINE")
        break
    print(f"  Endpoint not ONLINE yet — waiting 20s …")
    time.sleep(20)
else:
    print(f"  [WARN] Endpoint never became ONLINE — skipping sync")
    dbutils.notebook.exit("DONE (sync skipped — endpoint offline)")

for _sync_try in range(1, 7):
    sync_resp = requests.post(
        f"{DBR_HOST}/api/2.0/vector-search/indexes/{VS_INDEX_NAME}/sync",
        headers=headers, json={}, timeout=30, verify=False,
    )
    if sync_resp.ok:
        print(f"  [OK] VS index sync triggered: {VS_INDEX_NAME}")
        break
    if sync_resp.status_code == 400 and "not ready" in sync_resp.text.lower():
        print(f"  Index not ready (attempt {_sync_try}/6) — retrying in 20s …")
        time.sleep(20)
    else:
        print(f"  [WARN] Sync HTTP {sync_resp.status_code}: {sync_resp.text[:200]}")
        break

print("\n[Watchdog] Complete.")
dbutils.notebook.exit("DONE+SYNCED")
    except Exception as exc:
        msg = str(exc)[:300]
        print(f"[Watchdog] Child FAILED on attempt {attempt}: {msg}")
        if attempt >= MAX_ATTEMPTS:
            print(f"[Watchdog] Reached MAX_ATTEMPTS={MAX_ATTEMPTS}. Giving up.")
            raise RuntimeError(f"Backfill failed after {MAX_ATTEMPTS} attempts. Last error: {msg}")
        print(f"[Watchdog] Restarting in {RESTART_DELAY_S}s …")
        time.sleep(RESTART_DELAY_S)

# COMMAND ----------
