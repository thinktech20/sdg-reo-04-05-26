# Databricks notebook source
# -------------------------------------------------------------------------
# ESN Identifier Probe – run the exact esn_identifier path on target PDFs
# that have None / wrong generator_serial in the base table.
# Uses the fast Files-API volume scanner, not FUSE Path.iterdir().
# -------------------------------------------------------------------------

# COMMAND ----------

# MAGIC %pip install --quiet \
# MAGIC   typing_extensions>=4.12.0 \
# MAGIC   langchain-core>=0.1.24 \
# MAGIC   langchain-text-splitters>=0.0.1 \
# MAGIC   PyMuPDF>=1.23.0 \
# MAGIC   httpx \
# MAGIC   python-dotenv

# COMMAND ----------

dbutils.library.restartPython()

# COMMAND ----------

import sys, os, json, time
from pathlib import Path

# Resolve src/ from the deployed pipeline workspace path
try:
    _ctx     = dbutils.notebook.entry_point.getDbutils().notebook().getContext()
    _nb_path = _ctx.notebookPath().get()
    _ws_dir  = "/Workspace" + str(Path(_nb_path).parent)
    _src_dir = _ws_dir + "/src"
except Exception:
    _src_dir = "./src"

if _src_dir not in sys.path:
    sys.path.insert(0, _src_dir)

print(f"[OK] src path: {_src_dir}")
print(f"[OK] Files:    {sorted(os.listdir(_src_dir))}")

# COMMAND ----------

SECRET_SCOPE_OVERRIDE = "fsr-pipeline"
try:
    _p = dbutils.widgets.get("SECRET_SCOPE_OVERRIDE")
    if _p.strip():
        SECRET_SCOPE_OVERRIDE = _p.strip()
except Exception:
    pass
os.environ["DBR_SECRET_SCOPE"] = SECRET_SCOPE_OVERRIDE

from config import LITELLM_API_KEY, LITELLM_BASE_URL
from esn_identifier import (
    MIN_ESN_COUNT,
    MIN_ESN_FRACTION,
    load_document_text_for_esn,
    prepare_document_text_for_esn,
    analyze_prepared_document_text_for_esn_counts,
    identify_esns,
)

print(f"LITELLM_BASE_URL  = {LITELLM_BASE_URL}")
print(f"LITELLM_API_KEY   = {'SET (' + LITELLM_API_KEY[:8] + '...)' if LITELLM_API_KEY else 'MISSING'}")
print(f"MIN_ESN_COUNT     = {MIN_ESN_COUNT}")
print(f"MIN_ESN_FRACTION  = {MIN_ESN_FRACTION}")

# Inline the qualification logic (mirrors _qualify_esn_counts in esn_identifier)
def _qualify(counts: dict, min_count: int = MIN_ESN_COUNT, min_frac: float = MIN_ESN_FRACTION) -> list:
    total = sum(counts.values())
    if total <= 0:
        return []
    return [
        esn for esn, cnt in sorted(counts.items(), key=lambda x: (-x[1], x[0]))
        if cnt >= min_count and (cnt / total) >= min_frac
    ]

# Fast volume listing using dbutils.fs.ls() — avoids FUSE slowness and
# the SSL self-signed cert issue that blocks the Files REST API from inside DBR.
def _dbutils_ls_stems(volume_path: str) -> dict:
    """Return {stem: full_path} for all top-level files in a volume via dbutils."""
    result = {}
    try:
        entries = dbutils.fs.ls(volume_path)
        for entry in entries:
            if not entry.isDir():
                p = entry.path
                # dbutils paths start with dbfs: or file: — normalise to /Volumes/...
                if p.startswith("dbfs:"):
                    p = p[5:]
                stem = Path(p).stem
                result[stem] = p
    except Exception as e:
        print(f"  [WARN] dbutils.fs.ls({volume_path}): {e}")
    return result

# COMMAND ----------

# Target PDFs: (stem, gt_esn_from_GT_table, esn_in_base_table)
TARGET_PDFS = [
    # None ESN in base table
    ("090dbba1800ef3cb",  "290T503", None),
    ("090dbba180068b39",  "290T532", None),
    ("090dbba180076e59",  "290T532", None),
    ("090dbba180085001",  "290T532", None),
    ("090dbba1800fc8fb",  "290T762", None),
    ("090dbba1800fdff4",  "290T762", None),
    ("090dbba1800f0a21",  "337X045", None),
    ("090dbba1800f37d6",  "337X045", None),
    ("090dbba1800f6faa",  "337X045", None),
    ("090dbba1800f4f5b",  "337X305", None),
    ("090dbba18003a23c",  "337X330", None),
    ("090dbba180100488",  "337X330", None),
    ("090dbba18008c4b1",  "337X336", None),
    ("090dbba18008eb7c",  "337X336", None),
    ("090dbba1800ffe6f",  "337X336", None),
    ("090dbba1801238ab",  "337X369", None),
    ("090dbba1800bad72",  "337X708", None),
    ("090dbba1800f7e67",  "337X708", None),
    ("090dbba1800f4d97",  "337X709", None),
    ("090dbba18008c1f4",  "338X408", None),
    ("090dbba1800f09da",  "338X408", None),
    ("090dbba1801021b6",  "338X408", None),
    ("090dbba1800ff693",  "338X425", None),
    ("090dbba1800b5e28",  "338X713", None),
    ("090dbba180086b3e",  "338X722", None),
    ("090dbba180086f05",  "338X722", None),
    ("090dbba180086f0b",  "338X722", None),
    ("090dbba18008a24f",  "338X722", None),
    # Wrong ESN in base table
    ("08ef2ef4-fc25-4bc8-af2e-f4fc253bc86d",  "290T503", "270T503"),
    ("7523f0ed-4f65-4738-a3f0-ed4f65273858",  "290T762", "270T762"),
    ("Field_Service_Report_ProjectID_A-1813284_EV-147582_EVP-534570", "290T658", "270T658"),
    ("Field_Service_Report_ProjectID_A-1561864_EV-118524_C-10357248", "337X233", "297905"),
    ("337X305 2022-11-18 Robotic",             "337X305", "298126"),
    ("bc4ffb5d-7d8d-4993-8ffb-5d7d8df99367",  "337X709", "297256"),
    ("a2e95baf-9f0d-4ab0-a95b-af9f0dcab0be",  "338X424", "297842"),
    ("a9843356-c0fb-4574-8433-56c0fb3574b3",  "338X426", "297749"),
    ("050114d8-0354-4161-8114-d8035421611b",  "290T530", "297467+337X737"),
    ("52229_03_30_2022_16_11_58_BJWECBD9FV17J394", "761X004", "52229"),
    ("53321_03_30_2022_15_52_25_CCI0K97ZL2VIYWXJ", "761X004", "53321"),
    ("Field_Service_Report_ProjectID_A-1632720_EV-118196_C-10357780", "761X004", "298374"),
]

target_stems = {stem for stem, _, _ in TARGET_PDFS}

# Use dbutils.fs.ls() — fast, no SSL issues, no FUSE slowness
VOLUME_PATHS = [
    "/Volumes/vgpd/fsr_std_views/fsr_std_vol/FSR_After_2016/FSR_Databricks/",
    "/Volumes/viud/ing_ud_fsr_manual/manual_field_service_report/ecrt_reports",
    "/Volumes/viud/ing_ud_fieldvision/fv_field_service_report",
]

print(f"Scanning {len(VOLUME_PATHS)} volumes via dbutils.fs.ls for {len(target_stems)} target stems...")
stem_to_path = {}
for vol in VOLUME_PATHS:
    t0 = time.time()
    vol_stems = _dbutils_ls_stems(vol)
    elapsed = time.time() - t0
    matched = {s: p for s, p in vol_stems.items() if s in target_stems}
    print(f"  {vol}: {len(vol_stems)} files  matched={len(matched)}  {elapsed:.1f}s")
    stem_to_path.update(matched)

found   = set(stem_to_path)
missing = target_stems - found
print(f"\nFound: {len(found)}/{len(target_stems)}  Missing: {len(missing)}")
if missing:
    print(f"  Not found in any volume: {sorted(missing)}")

# COMMAND ----------

# Run the ESN identifier on every found PDF
results = []

for pdf_stem, gt_esn, base_esn in TARGET_PDFS:
    pdf_path = stem_to_path.get(pdf_stem)
    if not pdf_path:
        results.append({
            "pdf_name": pdf_stem, "gt_esn": gt_esn, "base_esn": str(base_esn),
            "status": "NOT_FOUND_IN_VOLUMES",
        })
        continue

    rec = {
        "pdf_name":  pdf_stem,
        "gt_esn":    gt_esn,
        "base_esn":  str(base_esn),
        "pdf_path":  pdf_path,
    }

    try:
        # Exact same steps as process_single_pdf_with_background_doc_analysis
        doc_text  = load_document_text_for_esn(pdf_path)
        prepared  = prepare_document_text_for_esn(doc_text)
        rec["doc_text_chars"]      = len(doc_text)
        rec["prepared_text_chars"] = len(prepared)
        # Heads/tail so we can see what the LLM actually receives
        rec["prepared_head"] = prepared[:300]
        rec["prepared_tail"] = prepared[-200:]

        llm_counts = analyze_prepared_document_text_for_esn_counts(prepared)
        rec["llm_raw_counts"] = llm_counts

        qualified = _qualify(llm_counts)
        rec["llm_qualified_esns"]      = qualified
        rec["llm_identifies_gt_esn"]   = gt_esn in qualified
        rec["llm_identifies_base_esn"] = (base_esn in qualified) if base_esn else None

        # For below-threshold cases, show how close each ESN was
        if not qualified and llm_counts:
            total = sum(llm_counts.values())
            rec["unqualified_detail"] = {
                esn: {"count": cnt, "fraction": round(cnt / total, 3)}
                for esn, cnt in sorted(llm_counts.items(), key=lambda x: -x[1])[:8]
            }

        if qualified:
            rec["status"] = "LLM_QUALIFIED"
        elif llm_counts:
            rec["status"] = "LLM_COUNTS_BELOW_THRESHOLD"
        else:
            rec["status"] = "LLM_RETURNED_EMPTY"

        print(
            f"  [{rec['status']}]  {pdf_stem[:42]}"
            f"  gt={gt_esn}  base={base_esn}"
            f"  counts={llm_counts}  qualified={qualified}"
        )

    except Exception as e:
        rec["status"] = "ERROR"
        rec["error"]  = str(e)
        print(f"  [ERROR] {pdf_stem}: {e}")

    results.append(rec)
    time.sleep(0.2)

# COMMAND ----------

from collections import Counter

status_counts = Counter(r["status"] for r in results)
print("=== STATUS SUMMARY ===")
for s, n in sorted(status_counts.items()):
    print(f"  {s}: {n}")

would_gt = [r for r in results if r.get("llm_identifies_gt_esn")]
print(f"\nLLM would have correctly identified GT ESN: {len(would_gt)}/{len(results)}")

print("\n--- GT ESN NOT in qualified set ---")
for r in results:
    if r.get("status") in ("LLM_QUALIFIED", "LLM_COUNTS_BELOW_THRESHOLD", "LLM_RETURNED_EMPTY") \
            and not r.get("llm_identifies_gt_esn"):
        print(
            f"  {r['pdf_name'][:45]}  gt={r['gt_esn']}  base={r['base_esn']}"
            f"  qualified={r.get('llm_qualified_esns')}  raw={r.get('llm_raw_counts')}"
        )

# COMMAND ----------

out = json.dumps(results, indent=2, default=str)
print(out[:4000])
dbutils.notebook.exit(out)


# COMMAND ----------

# ── Secret scope override ──────────────────────────────────────────────────
SECRET_SCOPE_OVERRIDE = "fsr-pipeline"
try:
    _p = dbutils.widgets.get("SECRET_SCOPE_OVERRIDE")
    if _p.strip():
        SECRET_SCOPE_OVERRIDE = _p.strip()
except Exception:
    pass

os.environ["DBR_SECRET_SCOPE"] = SECRET_SCOPE_OVERRIDE
print(f"SECRET_SCOPE: {SECRET_SCOPE_OVERRIDE}")

# COMMAND ----------

from config import LITELLM_API_KEY, LITELLM_BASE_URL
from esn_identifier import (
    MIN_ESN_COUNT,
    MIN_ESN_FRACTION,
    analyze_prepared_document_text_for_esn_counts,
    load_document_text_for_esn,
    prepare_document_text_for_esn,
    _qualify_esn_counts,
)
# Cover-page regex + filename extraction live in pdf_processor in the deployed version
from pdf_processor import (
    _extract_esn_from_pdf,
    _extract_esn_from_filename,
)

print(f"LITELLM_BASE_URL = {LITELLM_BASE_URL}")
print(f"LITELLM_API_KEY  = {'SET (' + LITELLM_API_KEY[:8] + '...)' if LITELLM_API_KEY else 'MISSING'}")
print(f"MIN_ESN_COUNT    = {MIN_ESN_COUNT}")
print(f"MIN_ESN_FRACTION = {MIN_ESN_FRACTION}")

# COMMAND ----------

# ── Target PDFs – the None-ESN and wrong-ESN cases from the comparison ────
# Format: (pdf_name_stem, expected_gt_esn, base_table_esn)
TARGET_PDFS = [
    # None ESN in base table
    ("090dbba1800ef3cb",  "290T503", None),
    ("090dbba180068b39",  "290T532", None),
    ("090dbba180076e59",  "290T532", None),
    ("090dbba180085001",  "290T532", None),
    ("090dbba1800fc8fb",  "290T762", None),
    ("090dbba1800fdff4",  "290T762", None),
    ("090dbba1800f0a21",  "337X045", None),
    ("090dbba1800f37d6",  "337X045", None),
    ("090dbba1800f6faa",  "337X045", None),
    ("090dbba1800f4f5b",  "337X305", None),
    ("090dbba18003a23c",  "337X330", None),
    ("090dbba180100488",  "337X330", None),
    ("090dbba18008c4b1",  "337X336", None),
    ("090dbba18008eb7c",  "337X336", None),
    ("090dbba1800ffe6f",  "337X336", None),
    ("090dbba1801238ab",  "337X369", None),
    ("090dbba1800bad72",  "337X708", None),
    ("090dbba1800f7e67",  "337X708", None),   # also 337X709
    ("090dbba1800f4d97",  "337X709", None),
    ("090dbba18008c1f4",  "338X408", None),
    ("090dbba1800f09da",  "338X408", None),
    ("090dbba1801021b6",  "338X408", None),
    ("090dbba1800ff693",  "338X425", None),
    ("090dbba1800b5e28",  "338X713", None),
    ("090dbba180086b3e",  "338X722", None),
    ("090dbba180086f05",  "338X722", None),
    ("090dbba180086f0b",  "338X722", None),
    ("090dbba18008a24f",  "338X722", None),
    # Wrong ESN in base table (prefix mismatch: 270T vs 290T, numeric IDs, etc.)
    ("08ef2ef4-fc25-4bc8-af2e-f4fc253bc86d",  "290T503", "270T503"),
    ("7523f0ed-4f65-4738-a3f0-ed4f65273858",   "290T762", "270T762"),
    ("Field_Service_Report_ProjectID_A-1813284_EV-147582_EVP-534570", "290T658", "270T658"),
    ("Field_Service_Report_ProjectID_A-1561864_EV-118524_C-10357248", "337X233", "297905"),
    ("337X305 2022-11-18 Robotic",              "337X305", "298126"),
    ("bc4ffb5d-7d8d-4993-8ffb-5d7d8df99367",   "337X709", "297256"),
    ("a2e95baf-9f0d-4ab0-a95b-af9f0dcab0be",   "338X424", "297842"),
    ("a9843356-c0fb-4574-8433-56c0fb3574b3",   "338X426", "297749"),
    ("050114d8-0354-4161-8114-d8035421611b",   "290T530", "297467+337X737"),
    ("52229_03_30_2022_16_11_58_BJWECBD9FV17J394", "761X004", "52229"),
    ("53321_03_30_2022_15_52_25_CCI0K97ZL2VIYWXJ", "761X004", "53321"),
    ("Field_Service_Report_ProjectID_A-1632720_EV-118196_C-10357780", "761X004", "298374"),
]

# ── Volume paths to search ─────────────────────────────────────────────────
VOLUME_PATHS = [
    "/Volumes/vgpd/fsr_std_views/fsr_std_vol/FSR_After_2016/FSR_Databricks/",
    "/Volumes/viud/ing_ud_fsr_manual/manual_field_service_report/ecrt_reports",
    "/Volumes/viud/ing_ud_fieldvision/fv_field_service_report",
]

# Build lookup: stem -> full path
print("\nScanning volumes for target PDFs...")
stem_to_path = {}
for vol in VOLUME_PATHS:
    vpath = Path(vol)
    try:
        for f in vpath.iterdir():
            if f.is_file():
                stem_to_path[f.stem] = str(f)
    except Exception as e:
        print(f"  [WARN] Could not list {vol}: {e}")

target_stems = {pdf_stem for pdf_stem, _, _ in TARGET_PDFS}
found_stems  = target_stems & set(stem_to_path)
missing_stems = target_stems - found_stems
print(f"Target PDFs : {len(TARGET_PDFS)}")
print(f"Found in volumes : {len(found_stems)}")
print(f"Not found   : {len(missing_stems)}")
if missing_stems:
    print(f"  Missing: {sorted(missing_stems)[:10]}{'...' if len(missing_stems) > 10 else ''}")

# COMMAND ----------

# ── Run the probe ──────────────────────────────────────────────────────────
results = []

for pdf_stem, gt_esn, base_esn in TARGET_PDFS:
    pdf_path = stem_to_path.get(pdf_stem)
    if not pdf_path:
        results.append({
            "pdf_name": pdf_stem,
            "gt_esn": gt_esn,
            "base_esn": base_esn,
            "status": "NOT_FOUND_IN_VOLUMES",
        })
        print(f"  [SKIP] {pdf_stem}: not found in volumes")
        continue

    rec = {
        "pdf_name": pdf_stem,
        "gt_esn": gt_esn,
        "base_esn": base_esn,
        "pdf_path": pdf_path,
    }

    # 1. Cover-page regex extraction (same as pdf_processor._extract_esn_from_pdf)
    try:
        cover_esn = _extract_esn_from_pdf(pdf_path)
        rec["cover_page_esn"] = cover_esn
    except Exception as e:
        rec["cover_page_esn"] = None
        rec["cover_page_error"] = str(e)

    # 2. Filename extraction
    rec["filename_esn"] = _extract_esn_from_filename(pdf_path)

    # 3. Full doc-level LLM call (same as what the pipeline runs)
    try:
        doc_text    = load_document_text_for_esn(pdf_path)
        prepared    = prepare_document_text_for_esn(doc_text)
        rec["doc_text_chars"]     = len(doc_text)
        rec["prepared_text_chars"] = len(prepared)
        rec["prepared_text_head"] = prepared[:300]   # first 300 chars for inspection

        llm_counts = analyze_prepared_document_text_for_esn_counts(prepared)
        rec["llm_raw_counts"] = llm_counts

        qualified = _qualify_esn_counts(llm_counts, MIN_ESN_COUNT, MIN_ESN_FRACTION)
        rec["llm_qualified_esns"] = qualified
        rec["llm_would_identify_gt"]  = gt_esn in qualified
        rec["llm_would_identify_base"] = base_esn in qualified if base_esn else None

        if qualified:
            rec["status"] = "LLM_QUALIFIED"
        elif llm_counts:
            rec["status"] = "LLM_RETURNED_COUNTS_BUT_NONE_QUALIFIED"
        else:
            rec["status"] = "LLM_RETURNED_EMPTY"

        print(f"  [{rec['status']}] {pdf_stem}")
        print(f"    cover={cover_esn}  filename={rec['filename_esn']}")
        print(f"    llm_counts={llm_counts}")
        print(f"    qualified={qualified}  gt={gt_esn}  base={base_esn}")

    except Exception as e:
        rec["status"] = "LLM_ERROR"
        rec["llm_error"] = str(e)
        print(f"  [LLM_ERROR] {pdf_stem}: {e}")

    results.append(rec)
    time.sleep(0.3)   # gentle rate-limiting

# COMMAND ----------

# ── Summary ────────────────────────────────────────────────────────────────
from collections import Counter
status_counts = Counter(r["status"] for r in results)
print("\n=== SUMMARY ===")
for status, count in sorted(status_counts.items()):
    print(f"  {status}: {count}")

# Would-have-identified-GT breakdown
would_id_gt = [r for r in results if r.get("llm_would_identify_gt")]
print(f"\nLLM would have correctly identified GT ESN: {len(would_id_gt)}/{len(results)}")

# Cases where LLM returned something but not the GT ESN
wrong_esn = [r for r in results
             if r.get("llm_qualified_esns") and not r.get("llm_would_identify_gt")]
print(f"LLM qualified non-GT ESN: {len(wrong_esn)}")
for r in wrong_esn:
    print(f"  {r['pdf_name']}: qualified={r['llm_qualified_esns']}  gt={r['gt_esn']}")

# Cases where nothing qualified
empty_or_error = [r for r in results
                  if r.get("status") in ("LLM_RETURNED_EMPTY", "LLM_RETURNED_COUNTS_BUT_NONE_QUALIFIED", "LLM_ERROR", "NOT_FOUND_IN_VOLUMES")]
print(f"No ESN identified: {len(empty_or_error)}")
for r in empty_or_error:
    print(f"  {r['pdf_name']}: {r['status']}  raw={r.get('llm_raw_counts', r.get('llm_error', ''))}")

# COMMAND ----------

output_json = json.dumps(results, indent=2, default=str)
print(output_json[:3000])  # print first 3k chars to notebook output
dbutils.notebook.exit(output_json)
