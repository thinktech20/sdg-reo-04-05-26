# Databricks notebook source
"""
Re-enrich generator_serial in the existing Delta table WITHOUT re-processing PDFs.

Steps:
  1. ref_view MERGE (always overwrites — authoritative)
  2. Regex fallback over chunk text for remaining NULLs
  3. LLM fallback for any still-NULL
  4. Show serial counts before/after
  5. Trigger VS sync

NOTE: fully self-contained — does NOT import from embeddings.py to avoid
      langchain dependency issues on the cluster.
"""

# COMMAND ----------

import re
import sys
import os
sys.path.insert(0, "/Workspace/Users/alex.seidel@ge.com/fsr_pipeline/src")

from pyspark.sql import SparkSession
spark = SparkSession.builder.getOrCreate()

from config import EMBEDDINGS_TABLE, FSR_REF_VIEW, VS_ENDPOINT_NAME, VS_INDEX_NAME, \
    LITELLM_BASE_URL, LITELLM_API_KEY, LLM_MODEL, CERT_PATH, CORP_PROXY

GT_SERIALS = ['290T658', '337X233', '337X244', '337X305', '337X380', '337X704', '761X004']

def _show_counts(label):
    print(f"\n=== {label} ===")
    spark.sql(f"""
        SELECT COUNT(*) AS total_chunks,
               COUNT(generator_serial) AS non_null_serials,
               COUNT(DISTINCT generator_serial) AS distinct_serials,
               SUM(CASE WHEN generator_serial IS NULL THEN 1 ELSE 0 END) AS null_serials
        FROM {EMBEDDINGS_TABLE}
    """).show()
    print("GT serial chunk counts:")
    spark.sql(f"""
        SELECT generator_serial, COUNT(*) AS chunks
        FROM {EMBEDDINGS_TABLE}
        WHERE generator_serial IN ({','.join(f"'{s}'" for s in GT_SERIALS)})
        GROUP BY generator_serial ORDER BY generator_serial
    """).show()

# COMMAND ----------

_show_counts("BEFORE enrichment")

# COMMAND ----------

# ── Step 1: ref_view MERGE (always overwrites — ref_view is authoritative) ───
print("\n=== STEP 1: ref_view MERGE (always overwrites) ===")
try:
    spark.sql(f"""
        MERGE INTO {EMBEDDINGS_TABLE} AS t
        USING (
            SELECT s3_filename,
                   FIRST(esn)                AS esn,
                   FIRST(report_issued_date) AS report_issued_date
            FROM {FSR_REF_VIEW}
            WHERE s3_filename IS NOT NULL
              AND esn IS NOT NULL
            GROUP BY s3_filename
        ) AS ref
        ON t.pdf_name = ref.s3_filename
        WHEN MATCHED THEN UPDATE SET
            t.generator_serial = ref.esn,
            t.report_date      = CAST(ref.report_issued_date AS DATE)
    """)
    print("[OK] ref_view MERGE complete")
except Exception as e:
    print(f"[WARN] ref_view MERGE failed: {e}")

# COMMAND ----------

# ── After snapshot ───────────────────────────────────────────────────────────
# COMMAND ----------

# ── Step 2: Regex fallback for remaining NULLs ───────────────────────────────
print("\n=== STEP 2: Regex fallback for remaining NULLs ===")
try:
    null_pdfs = spark.sql(f"""
        SELECT DISTINCT pdf_name FROM {EMBEDDINGS_TABLE} WHERE generator_serial IS NULL
    """).collect()

    if not null_pdfs:
        print("[OK] No NULL serials remaining — regex fallback not needed")
    else:
        pdf_names = [r["pdf_name"] for r in null_pdfs]
        print(f"  {len(pdf_names)} PDFs still NULL — scanning first 3 chunks per PDF...")
        pdf_list_sql = ",".join(f"'{p}'" for p in pdf_names)
        early_chunks = spark.sql(f"""
            SELECT pdf_name, page_number, chunk_text
            FROM {EMBEDDINGS_TABLE}
            WHERE pdf_name IN ({pdf_list_sql}) AND page_number <= 2
            ORDER BY pdf_name, page_number
        """).collect()

        ESN_PATTERNS = [
            re.compile(r'\bESN\s*[:=]\s*([A-Z0-9]{4,12})\b', re.IGNORECASE),
            re.compile(r'Equipment\s+Serial\s+(?:Number|No\.?)\s*[:=]\s*([A-Z0-9]{4,12})\b', re.IGNORECASE),
            re.compile(r'Serial\s+(?:Number|No\.?)\s*[:=]\s*([A-Z0-9]{4,12})\b', re.IGNORECASE),
            re.compile(r'Generator\s+Serial\s*[:=]\s*([A-Z0-9]{4,12})\b', re.IGNORECASE),
            re.compile(r'Unit\s+Serial\s+(?:Number|No\.?)\s*[:=]\s*([A-Z0-9]{4,12})\b', re.IGNORECASE),
        ]

        pdf_texts = {}
        for row in early_chunks:
            pdf_texts.setdefault(row["pdf_name"], []).append(row["chunk_text"] or "")

        extracted = {}
        for pdf_name, texts in pdf_texts.items():
            combined = "\n".join(texts)
            for pat in ESN_PATTERNS:
                m = pat.search(combined)
                if m:
                    extracted[pdf_name] = m.group(1).strip().upper()
                    break

        print(f"  Extracted ESN via regex for {len(extracted)}/{len(pdf_texts)} PDFs")

        if extracted:
            esn_df = spark.createDataFrame([{"pdf_name": k, "regex_esn": v} for k, v in extracted.items()])
            esn_df.createOrReplaceTempView("_esn_regex_fallback")
            spark.sql(f"""
                MERGE INTO {EMBEDDINGS_TABLE} AS t
                USING _esn_regex_fallback AS fb ON t.pdf_name = fb.pdf_name
                WHEN MATCHED AND t.generator_serial IS NULL THEN UPDATE SET
                    t.generator_serial = fb.regex_esn
            """)
            print(f"[OK] Regex fallback MERGE complete — {len(extracted)} PDFs updated")
except Exception as e:
    print(f"[WARN] Regex fallback failed: {e}")

# COMMAND ----------

# ── Step 3: LLM fallback for any still-NULL ───────────────────────────────────
print("\n=== STEP 3: LLM fallback for remaining NULLs ===")
try:
    import httpx
    from pathlib import Path as _Path
    from urllib.parse import urlparse

    null_pdfs2 = spark.sql(f"""
        SELECT DISTINCT pdf_name FROM {EMBEDDINGS_TABLE} WHERE generator_serial IS NULL
    """).collect()

    if not null_pdfs2:
        print("[OK] No NULL serials — LLM fallback not needed")
    else:
        pdf_names2 = [r["pdf_name"] for r in null_pdfs2]
        print(f"  {len(pdf_names2)} PDFs still NULL — querying LLM...")
        pdf_list_sql2 = ",".join(f"'{p}'" for p in pdf_names2)
        early2 = spark.sql(f"""
            SELECT pdf_name, chunk_text FROM {EMBEDDINGS_TABLE}
            WHERE pdf_name IN ({pdf_list_sql2}) AND page_number <= 2
            ORDER BY pdf_name, page_number
        """).collect()

        pdf_texts2 = {}
        for row in early2:
            pdf_texts2.setdefault(row["pdf_name"], []).append(row["chunk_text"] or "")

        verify = str(CERT_PATH) if CERT_PATH and _Path(str(CERT_PATH)).exists() else True
        base_host = (urlparse(LITELLM_BASE_URL).hostname or "").lower()
        bypass_proxy = base_host.endswith("research.gevernova.net")
        client_kwargs = {"verify": verify, "timeout": 30.0, "trust_env": False}
        if CORP_PROXY and not bypass_proxy:
            try:
                http_client = httpx.Client(proxy=CORP_PROXY, **client_kwargs)
            except TypeError:
                http_client = httpx.Client(proxies=CORP_PROXY, **client_kwargs)
        else:
            http_client = httpx.Client(**client_kwargs)

        llm_url = LITELLM_BASE_URL.rstrip("/") + "/chat/completions"
        llm_hdrs = {"Authorization": f"Bearer {LITELLM_API_KEY}", "Content-Type": "application/json"}
        _ESN_RE = re.compile(r'^[A-Z0-9]{4,12}$')

        llm_extracted = {}
        for pdf_name, texts in pdf_texts2.items():
            combined = "\n".join(texts)[:3000]
            payload = {
                "model": LLM_MODEL,
                "messages": [
                    {"role": "system", "content": (
                        "You extract equipment serial numbers from field service reports. "
                        "Respond with ONLY the serial number (e.g. 337X380, 290T658). "
                        "If you cannot find one, respond: UNKNOWN"
                    )},
                    {"role": "user", "content": f"Extract the generator or equipment serial number:\n\n{combined}"},
                ],
                "max_tokens": 20, "temperature": 0,
            }
            try:
                resp = http_client.post(llm_url, headers=llm_hdrs, json=payload)
                if resp.status_code == 200:
                    answer = resp.json()["choices"][0]["message"]["content"].strip().upper()
                    if _ESN_RE.match(answer) and answer != "UNKNOWN":
                        llm_extracted[pdf_name] = answer
                        print(f"  [ESN-LLM] {pdf_name}: '{answer}'")
                    else:
                        print(f"  [ESN-LLM] {pdf_name}: no valid ESN (got '{answer}')")
                else:
                    print(f"  [ESN-LLM] {pdf_name}: HTTP {resp.status_code}")
            except Exception as e_llm:
                print(f"  [ESN-LLM] {pdf_name}: {e_llm}")

        http_client.close()

        if llm_extracted:
            llm_df = spark.createDataFrame([{"pdf_name": k, "llm_esn": v} for k, v in llm_extracted.items()])
            llm_df.createOrReplaceTempView("_esn_llm_fallback")
            spark.sql(f"""
                MERGE INTO {EMBEDDINGS_TABLE} AS t
                USING _esn_llm_fallback AS fb ON t.pdf_name = fb.pdf_name
                WHEN MATCHED AND t.generator_serial IS NULL THEN UPDATE SET
                    t.generator_serial = fb.llm_esn
            """)
            print(f"[OK] LLM fallback MERGE complete — {len(llm_extracted)} PDFs updated")
        else:
            print("  LLM could not extract ESN for any remaining PDFs")
except Exception as e:
    print(f"[WARN] LLM fallback failed: {e}")

# COMMAND ----------

_show_counts("AFTER enrichment")

# COMMAND ----------

# ── Step 4: Trigger VS sync ───────────────────────────────────────────────────
print("\n=== STEP 4: Triggering VS sync ===")
try:
    import certifi, shutil, tempfile
    from pathlib import Path as _Path2
    from databricks.vector_search.client import VectorSearchClient

    ge_cert = str(CERT_PATH) if CERT_PATH and _Path2(str(CERT_PATH)).exists() else ""
    if ge_cert:
        combined_ca = _Path2(tempfile.gettempdir()) / "fsr_reenrich_ca.pem"
        if not combined_ca.exists():
            shutil.copy2(certifi.where(), combined_ca)
            with open(combined_ca, "a") as f:
                f.write("\n"); f.write(_Path2(ge_cert).read_text())
        os.environ["REQUESTS_CA_BUNDLE"] = str(combined_ca)

    _token = dbutils.notebook.entry_point.getDbutils().notebook().getContext().apiToken().get()
    _ws_url = "https://" + spark.conf.get("spark.databricks.workspaceUrl", "")
    vsc = VectorSearchClient(workspace_url=_ws_url, personal_access_token=_token, disable_notice=True)
    idx = vsc.get_index(endpoint_name=VS_ENDPOINT_NAME, index_name=VS_INDEX_NAME)
    idx.sync()
    print(f"[OK] VS sync triggered for {VS_INDEX_NAME}")
except Exception as e:
    print(f"[WARN] VS sync trigger failed (non-fatal): {e}")

# COMMAND ----------

print("\n=== Re-enrichment complete ===")
dbutils.notebook.exit("re-enrichment OK")
