# Databricks notebook source
# ─────────────────────────────────────────────────────────────────────────────
# ESN Label Patch – Re-detect ESNs with MIN_COUNT=1
#
# Iterates over PDFs already ingested into the embeddings table, re-runs
# document-level ESN detection with a lower threshold (MIN_COUNT=1), then:
#   1. Rewrites Delta rows with the updated ESN fanout (one row per ESN per chunk)
#   2. Populates the fsr_pdf_esn_mapping table with PDF → detected ESN mappings
# ─────────────────────────────────────────────────────────────────────────────

# COMMAND ----------

# MAGIC %pip install --quiet \
# MAGIC   typing_extensions>=4.12.0 \
# MAGIC   langchain-core>=0.1.24 \
# MAGIC   langchain-text-splitters>=0.0.1 \
# MAGIC   PyMuPDF>=1.23.0 \
# MAGIC   pandas \
# MAGIC   httpx \
# MAGIC   python-dotenv \
# MAGIC   requests

# COMMAND ----------

dbutils.library.restartPython()

# COMMAND ----------

import json
import os
import sys
import time
import warnings
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime
from pathlib import Path

warnings.filterwarnings(
    "ignore",
    message="Core Pydantic V1 functionality isn't compatible with Python 3.14 or greater.",
    category=UserWarning,
)

# ── Resolve src/ directory ──────────────────────────────────────────────────
try:
    _ctx     = dbutils.notebook.entry_point.getDbutils().notebook().getContext()
    _nb_path = _ctx.notebookPath().get()
    _ws_dir  = "/Workspace" + str(Path(_nb_path).parent)
    _src_dir = _ws_dir + "/src"
except Exception:
    _src_dir = str(Path(__file__).parent / "src") if "__file__" in dir() else "./src"

if _src_dir not in sys.path:
    sys.path.insert(0, _src_dir)

print(f"[OK] src path: {_src_dir}")
print(f"[OK] Files:    {sorted(os.listdir(_src_dir))}")

# COMMAND ----------

# ── Parameters ──────────────────────────────────────────────────────────────

PATCH_MIN_ESN_COUNT = 1
PATCH_MIN_ESN_FRACTION = 0.10
PATCH_WORKERS = 8            # concurrent LLM threads
PATCH_BATCH_SIZE = 50        # PDFs per durable batch

# Allow job-parameter overrides
try:
    _emb_table = dbutils.widgets.get("EMBEDDINGS_TABLE_OVERRIDE")
    if _emb_table.strip():
        os.environ["EMBEDDINGS_TABLE"] = _emb_table.strip()
        print(f"EMBEDDINGS_TABLE overridden → {_emb_table.strip()}")
except Exception:
    pass

try:
    _scope = dbutils.widgets.get("SECRET_SCOPE_OVERRIDE")
    if _scope.strip():
        os.environ["DBR_SECRET_SCOPE"] = _scope.strip()
        print(f"DBR_SECRET_SCOPE overridden → {_scope.strip()}")
except Exception:
    pass

try:
    _esn_model = dbutils.widgets.get("ESN_LLM_MODEL_OVERRIDE")
    if _esn_model.strip():
        os.environ["ESN_LLM_MODEL"] = _esn_model.strip()
        print(f"ESN_LLM_MODEL overridden → {_esn_model.strip()}")
except Exception:
    pass

try:
    _mapping_table = dbutils.widgets.get("ESN_MAPPING_TABLE")
    if _mapping_table.strip():
        ESN_MAPPING_TABLE = _mapping_table.strip()
    else:
        ESN_MAPPING_TABLE = ""
except Exception:
    ESN_MAPPING_TABLE = ""

try:
    _checkpoint_table = dbutils.widgets.get("ESN_CHECKPOINT_TABLE")
    if _checkpoint_table.strip():
        ESN_CHECKPOINT_TABLE = _checkpoint_table.strip()
    else:
        ESN_CHECKPOINT_TABLE = ""
except Exception:
    ESN_CHECKPOINT_TABLE = ""

try:
    _fallback_mapping_table = dbutils.widgets.get("ESN_MAPPING_FALLBACK_TABLE")
    if _fallback_mapping_table.strip():
        ESN_MAPPING_FALLBACK_TABLE = _fallback_mapping_table.strip()
    else:
        ESN_MAPPING_FALLBACK_TABLE = ""
except Exception:
    ESN_MAPPING_FALLBACK_TABLE = ""

try:
    _batch_size = dbutils.widgets.get("PATCH_BATCH_SIZE")
    if _batch_size.strip():
        PATCH_BATCH_SIZE = max(1, int(_batch_size.strip()))
        print(f"PATCH_BATCH_SIZE overridden → {PATCH_BATCH_SIZE}")
except Exception:
    pass

# COMMAND ----------

from pyspark.sql import SparkSession
from pyspark.sql.types import StringType, StructField, StructType, TimestampType

from config import EMBEDDINGS_TABLE, PDF_VOLUME_PATHS
from esn_identifier import (
    prepare_document_text_for_esn,
    analyze_prepared_document_text_for_esn_counts,
)
from utils import collect_pdfs_from_volumes

spark = SparkSession.builder.getOrCreate()

# Resolve mapping table/checkpoint table
if not ESN_MAPPING_TABLE:
    ESN_MAPPING_TABLE = "vgpd.fsr_std_views.fsr_scraped_file_mapping_ref"

if not ESN_MAPPING_FALLBACK_TABLE:
    ESN_MAPPING_FALLBACK_TABLE = "main.gp_services_sdg_poc.fsr_pdf_esn_mapping"

if not ESN_CHECKPOINT_TABLE:
    parts = EMBEDDINGS_TABLE.rsplit(".", 1)
    ESN_CHECKPOINT_TABLE = (
        parts[0] + ".fsr_pdf_esn_patch_checkpoint"
        if len(parts) >= 2
        else "main.gp_services_sdg_poc.fsr_pdf_esn_patch_checkpoint"
    )

EMBEDDINGS_SCHEMA = spark.table(EMBEDDINGS_TABLE).schema

print(f"EMBEDDINGS_TABLE  = {EMBEDDINGS_TABLE}")
print(f"ESN_MAPPING_TABLE = {ESN_MAPPING_TABLE}")
print(f"ESN_MAPPING_FALLBACK_TABLE = {ESN_MAPPING_FALLBACK_TABLE}")
print(f"ESN_CHECKPOINT_TABLE = {ESN_CHECKPOINT_TABLE}")

# COMMAND ----------

# ── Set SSL cert bundle ─────────────────────────────────────────────────────
import shutil, tempfile

_cert_path = Path(_ws_dir) / "GE_Enterprise_Root_CA_2_1.crt" if "_ws_dir" in dir() else None
if _cert_path and _cert_path.exists():
    combined = Path(tempfile.gettempdir()) / f"fsr_combined_ca_{os.getpid()}.pem"
    if not combined.exists():
        try:
            import certifi
            shutil.copy2(certifi.where(), combined)
        except ImportError:
            combined.write_bytes(b"")
        with open(combined, "a") as f:
            f.write("\n")
            f.write(_cert_path.read_text())
    os.environ["REQUESTS_CA_BUNDLE"] = str(combined)
    os.environ["SSL_CERT_FILE"]      = str(combined)
    os.environ["CURL_CA_BUNDLE"]     = str(combined)
    print(f"[OK] SSL cert bundle: {combined}")

# COMMAND ----------

# ── STEP 1: Discover existing PDFs + pending work ───────────────────────────

print("=" * 80)
print("STEP 1: Discover PDFs in volumes + existing rows in Delta")
print("=" * 80)

all_pdf_files, active_volumes, _ = collect_pdfs_from_volumes(PDF_VOLUME_PATHS)
pdf_by_stem = {p.stem: p for p in all_pdf_files}
print(f"Volume PDFs found: {len(pdf_by_stem)}")

existing_doc_ids = set(
    row["pdf_name"]
    for row in spark.sql(
        f"SELECT DISTINCT pdf_name FROM {EMBEDDINGS_TABLE}"
    ).collect()
    if row["pdf_name"]
)
print(f"Existing doc_ids in {EMBEDDINGS_TABLE}: {len(existing_doc_ids)}")

# Only patch PDFs that are both in volumes and in the table
patchable = sorted(existing_doc_ids & set(pdf_by_stem.keys()))
print(f"Patchable PDFs (in volumes + table): {len(patchable)}")


def _table_exists(table_name: str) -> bool:
    try:
        parts = table_name.split(".")
        if len(parts) == 3:
            db_name = f"{parts[0]}.{parts[1]}"
            obj_name = parts[2]
        elif len(parts) == 2:
            db_name = parts[0]
            obj_name = parts[1]
        else:
            return False

        rows = spark.sql(f"SHOW TABLES IN {db_name} LIKE '{obj_name}'").collect()
        return len(rows) > 0
    except Exception:
        return False


if _table_exists(ESN_CHECKPOINT_TABLE):
    completed_doc_ids = {
        row["pdf_name"]
        for row in spark.sql(
            f"SELECT DISTINCT pdf_name FROM {ESN_CHECKPOINT_TABLE}"
        ).collect()
        if row["pdf_name"]
    }
else:
    completed_doc_ids = set()

pending_doc_ids = sorted(set(patchable) - completed_doc_ids)
print(f"Already completed (mapping checkpoint): {len(completed_doc_ids)}")
print(f"Pending PDFs to process                : {len(pending_doc_ids)}")
print(f"Batch size                            : {PATCH_BATCH_SIZE}")

# COMMAND ----------

# ── STEP 2-5: Process in durable batches ────────────────────────────────────

print("=" * 80)
print(
    f"STEP 2-5: Re-detect ESNs in durable batches "
    f"(MIN_COUNT={PATCH_MIN_ESN_COUNT}, workers={PATCH_WORKERS}, batch={PATCH_BATCH_SIZE})"
)
print("=" * 80)

def _detect_esns_for_pdf(doc_id: str) -> dict:
    """Open PDF, run LLM ESN detection, return raw counts."""
    pdf_path = pdf_by_stem[doc_id]
    try:
        from esn_identifier import load_document_text_for_esn as _load
        doc_text = _load(str(pdf_path))
        if not doc_text or not doc_text.strip():
            return {"doc_id": doc_id, "counts": {}, "error": None, "status": "empty_text"}
        prepared = prepare_document_text_for_esn(doc_text)
        counts = analyze_prepared_document_text_for_esn_counts(prepared)
        return {"doc_id": doc_id, "counts": counts, "error": None, "status": "ok"}
    except Exception as exc:
        return {"doc_id": doc_id, "counts": {}, "error": str(exc), "status": "failed"}


def _sql_in_list(values: list[str]) -> str:
    return ", ".join("'" + v.replace("'", "''") + "'" for v in values)


MAPPING_SCHEMA = StructType([
    StructField("esn", StringType(), nullable=True),
    StructField("equipment_sys_id", StringType(), nullable=True),
    StructField("equipment_type", StringType(), nullable=True),
    StructField("equipment_code", StringType(), nullable=True),
    StructField("event_type", StringType(), nullable=True),
    StructField("ev_project_id", StringType(), nullable=True),
    StructField("ev_equipment_event_id", StringType(), nullable=True),
    StructField("ofs_event_id", StringType(), nullable=True),
    StructField("fsp_project_id", StringType(), nullable=True),
    StructField("xxx_project_id", StringType(), nullable=True),
    StructField("fsr_number", StringType(), nullable=True),
    StructField("report_issued_date", StringType(), nullable=True),
    StructField("outage_start_date", StringType(), nullable=True),
    StructField("outage_end_date", StringType(), nullable=True),
    StructField("pdf_name", StringType(), nullable=True),
])

FALLBACK_MAPPING_SCHEMA = StructType([
    StructField("pdf_name", StringType(), nullable=False),
    StructField("esn", StringType(), nullable=False),
    StructField("mention_count", StringType(), nullable=True),
    StructField("total_mentions", StringType(), nullable=True),
    StructField("mention_fraction", StringType(), nullable=True),
    StructField("detection_method", StringType(), nullable=True),
    StructField("detected_at", TimestampType(), nullable=True),
])

CHECKPOINT_SCHEMA = StructType([
    StructField("pdf_name", StringType(), nullable=False),
    StructField("processed_at", TimestampType(), nullable=True),
    StructField("status", StringType(), nullable=True),
])

if not _table_exists(ESN_CHECKPOINT_TABLE):
    spark.sql(
        f"""
        CREATE TABLE IF NOT EXISTS {ESN_CHECKPOINT_TABLE} (
            pdf_name STRING,
            processed_at TIMESTAMP,
            status STRING
        ) USING DELTA
        """
    )
    print(f"[OK] Created checkpoint table: {ESN_CHECKPOINT_TABLE}")

def _qualify(counts, min_count, min_fraction):
    total = sum(counts.values())
    if total <= 0:
        return []
    ranked = sorted(counts.items(), key=lambda item: (-item[1], item[0]))
    return [
        esn for esn, count in ranked
        if count >= min_count and (count / total) >= min_fraction
    ]


total_done = 0
total_failed = 0
total_changes = 0
total_newly_tagged = 0
total_mapping_rows = 0

if not pending_doc_ids:
    print("All patchable PDFs are already checkpointed in mapping table. Nothing to do.")
else:
    total_batches = (len(pending_doc_ids) + PATCH_BATCH_SIZE - 1) // PATCH_BATCH_SIZE

    for batch_idx, batch_start in enumerate(range(0, len(pending_doc_ids), PATCH_BATCH_SIZE), start=1):
        batch_doc_ids = pending_doc_ids[batch_start:batch_start + PATCH_BATCH_SIZE]
        print("\n" + "-" * 80)
        print(f"BATCH {batch_idx}/{total_batches}: {len(batch_doc_ids)} PDFs")
        print("-" * 80)

        # Step 2: detect ESNs for this batch
        t_detect = time.time()
        detection_results = {}
        done = 0
        failed = 0

        with ThreadPoolExecutor(max_workers=PATCH_WORKERS) as pool:
            futures = {pool.submit(_detect_esns_for_pdf, doc_id): doc_id for doc_id in batch_doc_ids}
            for future in as_completed(futures):
                doc_id = futures[future]
                result = future.result()
                detection_results[doc_id] = result
                done += 1
                if result["status"] == "failed":
                    failed += 1
                if done % 10 == 0 or done == len(batch_doc_ids):
                    elapsed = time.time() - t_detect
                    rate = done / elapsed if elapsed > 0 else 0
                    print(f"  Batch progress: {done}/{len(batch_doc_ids)} ({rate:.2f}/s, {failed} failed)")

        detect_elapsed = time.time() - t_detect
        print(f"  Detection done in {detect_elapsed:.1f}s")

        # Step 3: compare new ESNs to current table labels for this batch
        ids_sql = _sql_in_list(batch_doc_ids)
        current_esns_rows = spark.sql(f"""
            SELECT pdf_name, collect_set(generator_serial) AS current_esns
            FROM {EMBEDDINGS_TABLE}
            WHERE pdf_name IN ({ids_sql})
              AND generator_serial IS NOT NULL AND generator_serial != ''
            GROUP BY pdf_name
        """).collect()
        current_esn_map = {
            row["pdf_name"]: sorted(set(str(e).strip().upper() for e in row["current_esns"] if e))
            for row in current_esns_rows
        }

        changes = []
        no_change = 0
        newly_tagged = 0

        for doc_id in batch_doc_ids:
            result = detection_results.get(doc_id, {})
            if result.get("status") not in {"ok", "empty_text"}:
                continue

            counts = result.get("counts", {})
            new_esns = _qualify(counts, PATCH_MIN_ESN_COUNT, PATCH_MIN_ESN_FRACTION)
            new_esns_upper = sorted(set(e.upper() for e in new_esns))
            old_esns = current_esn_map.get(doc_id, [])

            # Compute LLM ESNs that are NOT already in the table for this doc
            missing_esns = sorted(set(new_esns_upper) - set(old_esns))
            if missing_esns:
                changes.append({
                    "doc_id": doc_id,
                    "old_esns": old_esns,
                    "new_esns": missing_esns,       # only the additive ones
                    "all_esns": new_esns_upper,
                    "counts": counts,
                })
                if not old_esns and new_esns_upper:
                    newly_tagged += 1
            else:
                no_change += 1

        print(f"  No change needed   : {no_change}")
        print(f"  ESN labels changed : {len(changes)} ({newly_tagged} newly tagged)")

        # Step 4: ADDITIVE insert — only add rows for LLM-detected ESNs not
        #         already present.  Existing rows are never deleted.
        inserted_rows = 0

        if changes:
            changed_doc_ids = [c["doc_id"] for c in changes]
            changed_ids_sql = _sql_in_list(changed_doc_ids)

            existing_rows = spark.sql(f"""
                SELECT * FROM {EMBEDDINGS_TABLE}
                WHERE pdf_name IN ({changed_ids_sql})
            """).collect()

            from collections import defaultdict
            canonical = {}
            for row in existing_rows:
                pdf_name = row["pdf_name"]
                chunk_id = row["chunk_id"]
                base_id = chunk_id.split("__")[0] if "__" in chunk_id else chunk_id
                key = (pdf_name, base_id)
                if key not in canonical:
                    canonical[key] = row

            esn_lookup = {c["doc_id"]: c["new_esns"] for c in changes}
            all_esn_lookup = {c["doc_id"]: c["all_esns"] for c in changes}

            new_rows = []
            for (pdf_name, base_chunk_id), row in canonical.items():
                esns_to_add = esn_lookup.get(pdf_name, [])
                if not esns_to_add:
                    continue
                row_dict = row.asDict()
                all_esns = all_esn_lookup.get(pdf_name, esns_to_add)

                for esn in esns_to_add:
                    new_row = dict(row_dict)
                    new_row["chunk_id"] = f"{base_chunk_id}__{esn}"
                    new_row["generator_serial"] = esn
                    if new_row.get("metadata"):
                        try:
                            meta = json.loads(new_row["metadata"])
                            existing_labels = set(meta.get("esn_labels", []))
                            existing_labels.update(all_esns)
                            meta["esn_labels"] = sorted(existing_labels)
                            existing_chunk = set(meta.get("chunk_esns", []))
                            existing_chunk.update(all_esns)
                            meta["chunk_esns"] = sorted(existing_chunk)
                            meta["esn_assignment_scope"] = "llm_additive_patch"
                            new_row["metadata"] = json.dumps(meta, ensure_ascii=True, sort_keys=True)
                        except (json.JSONDecodeError, TypeError):
                            pass
                    new_rows.append(new_row)

            if new_rows:
                spark.createDataFrame(new_rows, schema=EMBEDDINGS_SCHEMA).write.format("delta").mode("append").option("mergeSchema", "true").saveAsTable(EMBEDDINGS_TABLE)
                inserted_rows = len(new_rows)

        print(f"  Delta additive rows: inserted={inserted_rows} (no deletes)")

        # Step 5: completion checkpoint (write mapping LAST for successfully processed docs)
        mapping_rows = []
        now = datetime.utcnow()
        successful_doc_ids = []

        for doc_id in batch_doc_ids:
            result = detection_results.get(doc_id, {})
            status = result.get("status")
            if status not in {"ok", "empty_text"}:
                continue

            successful_doc_ids.append(doc_id)
            counts = result.get("counts", {})
            total = sum(counts.values())

            if not counts:
                continue

            for esn, count in counts.items():
                esn_upper = str(esn).strip().upper()
                if not esn_upper:
                    continue
                mapping_rows.append({
                    "esn": esn_upper,
                    "equipment_sys_id": None,
                    "equipment_type": None,
                    "equipment_code": None,
                    "event_type": None,
                    "ev_project_id": None,
                    "ev_equipment_event_id": None,
                    "ofs_event_id": None,
                    "fsp_project_id": None,
                    "xxx_project_id": None,
                    "fsr_number": None,
                    "report_issued_date": None,
                    "outage_start_date": None,
                    "outage_end_date": None,
                    "pdf_name": f"{doc_id}.pdf",
                })

        mapping_write_target = ESN_MAPPING_TABLE
        mapping_write_ok = False

        if mapping_rows:
            try:
                if _table_exists(ESN_MAPPING_TABLE) and successful_doc_ids:
                    success_ids_sql = _sql_in_list([f"{d}.pdf".lower() for d in successful_doc_ids])
                    spark.sql(f"DELETE FROM {ESN_MAPPING_TABLE} WHERE lower(pdf_name) IN ({success_ids_sql})")

                spark.createDataFrame(mapping_rows, schema=MAPPING_SCHEMA).write.format("delta").mode("append").saveAsTable(ESN_MAPPING_TABLE)
                mapping_write_ok = True
            except Exception as exc:
                # vgpd catalog is read-only in this workspace; fallback keeps run durable.
                print(f"  [WARN] Primary mapping write failed ({ESN_MAPPING_TABLE}): {exc}")

                fallback_rows = []
                for doc_id in successful_doc_ids:
                    result = detection_results.get(doc_id, {})
                    counts = result.get("counts", {})
                    total = sum(counts.values())
                    if not counts:
                        fallback_rows.append({
                            "pdf_name": doc_id,
                            "esn": "__NO_ESN__",
                            "mention_count": "0",
                            "total_mentions": "0",
                            "mention_fraction": "0.0",
                            "detection_method": "llm_document_patch",
                            "detected_at": now,
                        })
                        continue
                    for esn, count in counts.items():
                        esn_upper = str(esn).strip().upper()
                        if not esn_upper:
                            continue
                        fallback_rows.append({
                            "pdf_name": doc_id,
                            "esn": esn_upper,
                            "mention_count": str(int(count)),
                            "total_mentions": str(int(total)),
                            "mention_fraction": str(float(count / total) if total > 0 else 0.0),
                            "detection_method": "llm_document_patch",
                            "detected_at": now,
                        })

                if _table_exists(ESN_MAPPING_FALLBACK_TABLE) and successful_doc_ids:
                    success_ids_sql = _sql_in_list(successful_doc_ids)
                    spark.sql(f"DELETE FROM {ESN_MAPPING_FALLBACK_TABLE} WHERE pdf_name IN ({success_ids_sql})")

                spark.createDataFrame(fallback_rows, schema=FALLBACK_MAPPING_SCHEMA).write.format("delta").mode("append").option("mergeSchema", "true").saveAsTable(ESN_MAPPING_FALLBACK_TABLE)
                mapping_write_ok = True
                mapping_write_target = ESN_MAPPING_FALLBACK_TABLE

        if mapping_rows and not mapping_write_ok:
            raise RuntimeError("Mapping write failed for both primary and fallback targets")

        # Completion checkpoint LAST: only write after Delta rewrite and mapping write succeed.
        checkpoint_rows = [
            {"pdf_name": doc_id, "processed_at": now, "status": "completed"}
            for doc_id in successful_doc_ids
        ]
        if checkpoint_rows:
            success_ids_sql = _sql_in_list(successful_doc_ids)
            spark.sql(f"DELETE FROM {ESN_CHECKPOINT_TABLE} WHERE pdf_name IN ({success_ids_sql})")
            spark.createDataFrame(checkpoint_rows, schema=CHECKPOINT_SCHEMA).write.format("delta").mode("append").saveAsTable(ESN_CHECKPOINT_TABLE)

        print(f"  Mapping rows       : {len(mapping_rows)} rows -> {mapping_write_target}")
        print(f"  Checkpoint rows    : {len(checkpoint_rows)} PDFs")

        total_done += len(batch_doc_ids)
        total_failed += failed
        total_changes += len(changes)
        total_newly_tagged += newly_tagged
        total_mapping_rows += len(mapping_rows)

# COMMAND ----------

# ── Summary ──────────────────────────────────────────────────────────────────
print("\n" + "=" * 80)
print("PATCH COMPLETE")
print("=" * 80)
print(f"  PDFs scanned             : {total_done}")
print(f"  ESN detection failures   : {total_failed}")
print(f"  ESN labels changed       : {total_changes}")
print(f"  Newly tagged (was empty) : {total_newly_tagged}")
print(f"  Mapping rows written     : {total_mapping_rows}")
print(f"  Mapping table            : {ESN_MAPPING_TABLE}")
print(f"  Mapping fallback table   : {ESN_MAPPING_FALLBACK_TABLE}")
print(f"  Checkpoint table         : {ESN_CHECKPOINT_TABLE}")
print(f"  Embeddings table         : {EMBEDDINGS_TABLE}")
