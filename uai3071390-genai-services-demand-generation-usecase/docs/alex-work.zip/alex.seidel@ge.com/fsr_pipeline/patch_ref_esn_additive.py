# Databricks notebook source
# ─────────────────────────────────────────────────────────────────────────────
# Additive ESN Patch – Restore ref-view ESN mappings without removing existing ones
#
# For each target ESN, looks up the PDF→ESN mapping from fsr_pdf_ref, then
# checks whether those mappings are already present in the Delta table.
# Missing mappings are added by duplicating existing chunk rows with the
# correct generator_serial — existing rows are never deleted or overwritten.
# ─────────────────────────────────────────────────────────────────────────────

# COMMAND ----------

# MAGIC %pip install --quiet \
# MAGIC   typing_extensions>=4.12.0 \
# MAGIC   langchain-core>=0.1.24 \
# MAGIC   pandas \
# MAGIC   python-dotenv

# COMMAND ----------

dbutils.library.restartPython()

# COMMAND ----------

import json
import os
import sys
import time
from datetime import datetime
from pathlib import Path

# ── Resolve src/ directory ──────────────────────────────────────────────────
try:
    _ctx     = dbutils.notebook.entry_point.getDbutils().notebook().getContext()
    _nb_path = _ctx.notebookPath().get()
    _ws_dir  = "/Workspace" + str(Path(_nb_path).parent)
    _src_dir = _ws_dir + "/src"
except Exception:
    _src_dir = str(Path(__file__).parent / "src") if "__file__" in dir() else "./src"

if _src_dir not in sys.path:
    sys.path.insert(0, _src_dir)

print(f"[OK] src path: {_src_dir}")

# COMMAND ----------

from pyspark.sql import SparkSession

spark = SparkSession.builder.getOrCreate()

# ── Parameters ──────────────────────────────────────────────────────────────

# Allow job-parameter overrides
try:
    _emb_table = dbutils.widgets.get("EMBEDDINGS_TABLE_OVERRIDE")
    if _emb_table.strip():
        os.environ["EMBEDDINGS_TABLE"] = _emb_table.strip()
        print(f"EMBEDDINGS_TABLE overridden → {_emb_table.strip()}")
except Exception:
    pass

from config import EMBEDDINGS_TABLE

FSR_REF_VIEW = "vgpd.fsr_std_views.fsr_pdf_ref"

print(f"EMBEDDINGS_TABLE = {EMBEDDINGS_TABLE}")
print(f"FSR_REF_VIEW     = {FSR_REF_VIEW}")
print(f"Mode             = ALL ESNs (full reconciliation)")

# COMMAND ----------

# ── STEP 1: Load ref-view mappings for target ESNs ─────────────────────────

print("=" * 80)
print("STEP 1: Load PDF → ESN mappings from fsr_pdf_ref (all ESNs)")
print("=" * 80)

ref_rows = spark.sql(f"""
    SELECT
        regexp_replace(lower(s3_filename), '\\.pdf$', '') AS pdf_name_norm,
        esn,
        report_issued_date
    FROM {FSR_REF_VIEW}
    WHERE s3_filename IS NOT NULL
      AND esn IS NOT NULL
""").collect()

# Build mapping: pdf_name_norm → set of ESNs from ref view
from collections import defaultdict

ref_pdf_to_esns = defaultdict(set)
ref_pdf_to_date = {}

for row in ref_rows:
    pdf_norm = row["pdf_name_norm"]
    esn = str(row["esn"]).strip().upper()
    ref_pdf_to_esns[pdf_norm].add(esn)
    if row["report_issued_date"] is not None:
        ref_pdf_to_date[pdf_norm] = row["report_issued_date"]

print(f"Ref-view PDFs (all ESNs): {len(ref_pdf_to_esns)}")
total_mappings = sum(len(esns) for esns in ref_pdf_to_esns.values())
print(f"Total (PDF, ESN) pairs from ref view: {total_mappings}")

# COMMAND ----------

# ── STEP 2: Check which PDFs exist in Delta and what ESNs they already have ─

print("=" * 80)
print("STEP 2: Check existing ESN coverage in Delta table")
print("=" * 80)

ref_pdf_names = sorted(ref_pdf_to_esns.keys())

# Query in batches to avoid SQL size limits
BATCH_SIZE = 200
delta_pdf_to_esns = defaultdict(set)


def _sql_in_list(values):
    return ", ".join("'" + v.replace("'", "''") + "'" for v in values)


for start in range(0, len(ref_pdf_names), BATCH_SIZE):
    batch = ref_pdf_names[start:start + BATCH_SIZE]
    ids_sql = _sql_in_list(batch)

    rows = spark.sql(f"""
        SELECT pdf_name, generator_serial
        FROM {EMBEDDINGS_TABLE}
        WHERE pdf_name IN ({ids_sql})
          AND generator_serial IS NOT NULL
          AND generator_serial != ''
    """).collect()

    for row in rows:
        delta_pdf_to_esns[row["pdf_name"]].add(
            str(row["generator_serial"]).strip().upper()
        )

print(f"PDFs from ref view found in Delta: {len(delta_pdf_to_esns)}")

# Also find PDFs that exist in Delta but only with NULL serial
pdfs_in_delta = set()
for start in range(0, len(ref_pdf_names), BATCH_SIZE):
    batch = ref_pdf_names[start:start + BATCH_SIZE]
    ids_sql = _sql_in_list(batch)
    rows = spark.sql(f"""
        SELECT DISTINCT pdf_name
        FROM {EMBEDDINGS_TABLE}
        WHERE pdf_name IN ({ids_sql})
    """).collect()
    for row in rows:
        if row["pdf_name"]:
            pdfs_in_delta.add(row["pdf_name"])

pdfs_null_serial_only = pdfs_in_delta - set(delta_pdf_to_esns.keys())
print(f"PDFs in Delta with only NULL serial: {len(pdfs_null_serial_only)}")

# COMMAND ----------

# ── STEP 3: Compute missing (PDF, ESN) pairs ───────────────────────────────

print("=" * 80)
print("STEP 3: Identify missing (PDF, ESN) pairs to add")
print("=" * 80)

missing_pairs = []  # (pdf_name, esn)

for pdf_norm, ref_esns in ref_pdf_to_esns.items():
    if pdf_norm not in pdfs_in_delta:
        # PDF not ingested at all — nothing to patch (no chunk rows to duplicate)
        continue

    existing_esns = delta_pdf_to_esns.get(pdf_norm, set())
    for esn in ref_esns:
        if esn not in existing_esns:
            missing_pairs.append((pdf_norm, esn))

print(f"Total missing (PDF, ESN) pairs to restore: {len(missing_pairs)}")

if missing_pairs:
    # Group by PDF for display
    missing_by_pdf = defaultdict(list)
    for pdf, esn in missing_pairs:
        missing_by_pdf[pdf].append(esn)

    print(f"Affected PDFs: {len(missing_by_pdf)}")
    for pdf, esns in sorted(missing_by_pdf.items())[:20]:
        current = sorted(delta_pdf_to_esns.get(pdf, set()))
        print(f"  {pdf}: adding {esns}  (currently has: {current or ['NULL']})")
    if len(missing_by_pdf) > 20:
        print(f"  ... and {len(missing_by_pdf) - 20} more PDFs")

# COMMAND ----------

# ── STEP 4: Additively insert new rows for missing ESN mappings ─────────────

print("=" * 80)
print("STEP 4: Insert new rows for missing ESN mappings (additive)")
print("=" * 80)

if not missing_pairs:
    print("Nothing to do — all ref-view ESN mappings are already present.")
else:
    # Group missing pairs by PDF so we can batch-read existing rows
    missing_by_pdf = defaultdict(list)
    for pdf, esn in missing_pairs:
        missing_by_pdf[pdf].append(esn)

    affected_pdfs = sorted(missing_by_pdf.keys())
    total_inserted = 0
    now = datetime.utcnow()

    EMBEDDINGS_SCHEMA = spark.table(EMBEDDINGS_TABLE).schema

    for batch_start in range(0, len(affected_pdfs), BATCH_SIZE):
        batch_pdfs = affected_pdfs[batch_start:batch_start + BATCH_SIZE]
        ids_sql = _sql_in_list(batch_pdfs)

        # Read existing rows for these PDFs — we need canonical chunk data
        existing_rows = spark.sql(f"""
            SELECT * FROM {EMBEDDINGS_TABLE}
            WHERE pdf_name IN ({ids_sql})
        """).collect()

        # Build canonical row per (pdf_name, base_chunk_id) — dedupe multi-ESN copies
        canonical = {}
        for row in existing_rows:
            pdf_name = row["pdf_name"]
            chunk_id = row["chunk_id"]
            # Strip any existing __ESN suffix to get the base chunk id
            base_id = chunk_id.split("__")[0] if "__" in chunk_id else chunk_id
            key = (pdf_name, base_id)
            if key not in canonical:
                canonical[key] = row

        # Build new rows for each missing (pdf, esn) pair
        new_rows = []
        for pdf_name in batch_pdfs:
            esns_to_add = missing_by_pdf[pdf_name]
            report_date = ref_pdf_to_date.get(pdf_name)

            # Get all canonical chunks for this PDF
            pdf_chunks = [
                (base_id, row)
                for (p, base_id), row in canonical.items()
                if p == pdf_name
            ]

            if not pdf_chunks:
                print(f"  [WARN] No canonical chunks found for {pdf_name} — skipping")
                continue

            for base_chunk_id, row in pdf_chunks:
                row_dict = row.asDict()

                for esn in esns_to_add:
                    new_row = dict(row_dict)
                    new_row["chunk_id"] = f"{base_chunk_id}__{esn}"
                    new_row["generator_serial"] = esn
                    new_row["uploaded_at"] = now

                    # Update report_date from ref view if it was NULL
                    if new_row.get("report_date") is None and report_date is not None:
                        new_row["report_date"] = report_date

                    # Update metadata to reflect the addition
                    if new_row.get("metadata"):
                        try:
                            meta = json.loads(new_row["metadata"])
                            # Merge this ESN into existing labels
                            existing_labels = set(meta.get("esn_labels", []))
                            existing_labels.add(esn)
                            meta["esn_labels"] = sorted(existing_labels)
                            existing_chunk_esns = set(meta.get("chunk_esns", []))
                            existing_chunk_esns.add(esn)
                            meta["chunk_esns"] = sorted(existing_chunk_esns)
                            meta["esn_assignment_scope"] = "ref_view_additive_patch"
                            new_row["metadata"] = json.dumps(
                                meta, ensure_ascii=True, sort_keys=True
                            )
                        except (json.JSONDecodeError, TypeError):
                            pass

                    new_rows.append(new_row)

        if new_rows:
            df = spark.createDataFrame(new_rows, schema=EMBEDDINGS_SCHEMA)
            df.write.format("delta").mode("append").option(
                "mergeSchema", "true"
            ).saveAsTable(EMBEDDINGS_TABLE)
            total_inserted += len(new_rows)
            print(
                f"  Batch {batch_start // BATCH_SIZE + 1}: "
                f"inserted {len(new_rows)} rows for {len(batch_pdfs)} PDFs"
            )

    print(f"\nTotal rows inserted: {total_inserted}")

# COMMAND ----------

# ── STEP 5: Verification ───────────────────────────────────────────────────

print("=" * 80)
print("STEP 5: Verification — post-patch summary")
print("=" * 80)

# Count ESNs and NULL serial stats
stats = spark.sql(f"""
    SELECT
        COUNT(*) AS total_rows,
        SUM(CASE WHEN generator_serial IS NULL OR generator_serial = '' THEN 1 ELSE 0 END) AS null_rows,
        COUNT(DISTINCT generator_serial) AS distinct_esns,
        COUNT(DISTINCT pdf_name) AS distinct_pdfs
    FROM {EMBEDDINGS_TABLE}
""").collect()[0]

print(f"  Total rows           : {stats['total_rows']}")
print(f"  NULL serial rows     : {stats['null_rows']}")
print(f"  Distinct ESNs        : {stats['distinct_esns']}")
print(f"  Distinct PDFs        : {stats['distinct_pdfs']}")

# Show top 20 ESNs by chunk count for a quick sanity check
top_esns = spark.sql(f"""
    SELECT generator_serial AS esn,
           COUNT(DISTINCT pdf_name) AS pdf_count,
           COUNT(*) AS chunk_count
    FROM {EMBEDDINGS_TABLE}
    WHERE generator_serial IS NOT NULL AND generator_serial != ''
    GROUP BY generator_serial
    ORDER BY chunk_count DESC
    LIMIT 20
""").collect()

print(f"\n  Top 20 ESNs by chunk count:")
for row in top_esns:
    print(f"    {row['esn']}: {row['pdf_count']} PDFs, {row['chunk_count']} chunks")

# COMMAND ----------

# ── Summary ──────────────────────────────────────────────────────────────────

print("\n" + "=" * 80)
print("ADDITIVE REF-VIEW ESN PATCH COMPLETE")
print("=" * 80)
print(f"  Ref-view PDFs found      : {len(ref_pdf_to_esns)}")
print(f"  PDFs in Delta            : {len(pdfs_in_delta)}")
if 'total_inserted' in dir():
    print(f"  Rows inserted (additive) : {total_inserted}")
else:
    print(f"  Rows inserted (additive) : 0 (nothing to do)")
print(f"  Embeddings table         : {EMBEDDINGS_TABLE}")
print(f"  Ref view                 : {FSR_REF_VIEW}")
