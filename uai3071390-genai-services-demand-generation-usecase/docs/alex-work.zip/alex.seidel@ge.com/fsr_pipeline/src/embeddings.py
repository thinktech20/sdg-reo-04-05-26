"""
Embeddings – Databricks
Batch-encodes documents via LiteLLM/OpenAI proxy.
Stores vectors in EMBEDDINGS_TABLE (Delta) instead of local .pkl files.
FAISS kept as a fallback only; Databricks Vector Search is the primary index.
"""
import json
import json
import time
from pathlib import Path
from typing import List, Set, Tuple
from urllib.parse import urlparse

import numpy as np
from langchain_core.documents import Document
from langchain_openai import OpenAIEmbeddings
import httpx

from config import (
    LITELLM_BASE_URL, LITELLM_API_KEY, EMBEDDING_MODEL,
    embedding_config, EMBEDDINGS_TABLE, CERT_PATH, CORP_PROXY,
    FSR_REF_VIEW,
)
from utils import setup_logger, ProgressTracker, count_tokens

logger = setup_logger("embeddings")


# ============================================================================
# MODEL INITIALISATION
# ============================================================================

def initialize_embeddings() -> OpenAIEmbeddings:
    logger.info(f"Initializing embeddings model: {EMBEDDING_MODEL}")
    logger.info(f"  Base URL: {LITELLM_BASE_URL}")

    verify      = str(CERT_PATH) if CERT_PATH and Path(CERT_PATH).exists() else True
    base_host   = (urlparse(LITELLM_BASE_URL).hostname or "").lower()
    bypass_proxy = base_host.endswith("research.gevernova.net")

    client_kwargs = {"verify": verify, "timeout": 60.0, "trust_env": False}

    if CORP_PROXY and not bypass_proxy:
        try:
            http_client = httpx.Client(proxy=CORP_PROXY, **client_kwargs)
        except TypeError:                           # older httpx API
            http_client = httpx.Client(proxies=CORP_PROXY, **client_kwargs)
    else:
        http_client = httpx.Client(**client_kwargs)

    emb = OpenAIEmbeddings(
        model=EMBEDDING_MODEL,
        openai_api_key=LITELLM_API_KEY,
        openai_api_base=LITELLM_BASE_URL,
        http_client=http_client,
        skip_empty=True,
        check_embedding_ctx_length=False,  # disables token-length check entirely; no tiktoken/transformers needed
    )
    logger.info("[OK] Embeddings model ready")
    return emb


# ============================================================================
# BATCH ENCODING
# ============================================================================

def batch_encode_documents(
    documents: List[Document],
    embeddings_model: OpenAIEmbeddings,
    batch_size: int = 32,
    save_per_batch: bool = True,
) -> np.ndarray:
    """
    Encode documents in token-capped batches.
    When save_per_batch=True (default), writes each batch to Delta immediately
    so progress is preserved if the run fails mid-way.
    Returns float32 array of shape (n_docs, embedding_dim).
    """
    logger.info(f"Encoding {len(documents)} documents (batch_size={batch_size}, save_per_batch={save_per_batch})")
    all_embeddings: List[List[float]] = []
    progress = ProgressTracker(len(documents), "Encoding")

    dynamic_batch = batch_size
    idx = 0

    while idx < len(documents):
        batch_docs:    List[Document] = []
        approx_tokens: int            = 0
        start = idx

        while idx < len(documents) and len(batch_docs) < dynamic_batch:
            doc = documents[idx]
            t   = count_tokens(doc.page_content)
            if batch_docs and approx_tokens + t > embedding_config.max_batch_tokens:
                break
            batch_docs.append(doc)
            approx_tokens += t
            idx += 1

        texts     = [d.page_content for d in batch_docs]
        batch_emb = None

        for attempt in range(1, embedding_config.max_retries + 1):
            try:
                batch_emb = embeddings_model.embed_documents(texts)
                break
            except Exception as e:
                if attempt >= embedding_config.max_retries:
                    raise
                wait = embedding_config.retry_delay * (2 ** (attempt - 1))
                logger.warning(f"  Attempt {attempt} failed: {e}. Retrying in {wait:.1f}s")
                time.sleep(wait)

        if batch_emb is None:
            raise RuntimeError(f"Embedding failed for docs {start}–{idx-1}")

        batch_arr = np.array(batch_emb, dtype=np.float32)
        all_embeddings.extend(batch_emb)

        # ── Save this batch to Delta immediately so it's not lost on failure ──
        if save_per_batch:
            save_embeddings_to_delta(batch_docs, batch_arr)

        progress.update(len(batch_docs))

    progress.close()
    arr = np.array(all_embeddings, dtype=np.float32)
    logger.info(f"Encoding complete – shape: {arr.shape}")
    return arr


# ============================================================================
# DELTA TABLE I/O
# ============================================================================

def embeddings_table_doc_ids() -> Set[str]:
    """Return pdf_name values already present in EMBEDDINGS_TABLE."""
    try:
        from pyspark.sql import SparkSession
        spark = SparkSession.builder.getOrCreate()
        spark.sql(f"DESCRIBE TABLE {EMBEDDINGS_TABLE}")      # raises if table missing
        rows = spark.sql(
            f"SELECT DISTINCT pdf_name FROM {EMBEDDINGS_TABLE}"
        ).collect()
        return {r["pdf_name"] for r in rows}
    except Exception:
        return set()


def load_ref_view_lookup() -> dict:
    """Load the FSR reference view into a Python dict for in-process lookups.

    Returns:
        {norm_pdf_name: {"esn": str, "report_date": datetime.date | None}}

    norm_pdf_name is the s3_filename with .pdf stripped and lowercased,
    matching how we store pdf_name in the Delta table.
    Thread-safe to call once and share — the dict is read-only after return.
    """
    from pyspark.sql import SparkSession
    from datetime import date as _date
    spark = SparkSession.builder.getOrCreate()

    lookup: dict = {}
    try:
        rows = spark.sql(
            f"""
            SELECT regexp_replace(lower(s3_filename), '\\.pdf$', '') AS norm_key,
                   FIRST(esn)                AS esn,
                   FIRST(report_issued_date) AS report_issued_date
            FROM {FSR_REF_VIEW}
            WHERE s3_filename IS NOT NULL
              AND esn IS NOT NULL
            GROUP BY regexp_replace(lower(s3_filename), '\\.pdf$', '')
            """
        ).collect()
        for r in rows:
            raw_date = r["report_issued_date"]
            if raw_date is None:
                parsed_date = None
            elif isinstance(raw_date, _date):
                parsed_date = raw_date
            else:
                try:
                    parsed_date = _date.fromisoformat(str(raw_date).strip())
                except (ValueError, TypeError):
                    parsed_date = None
            lookup[r["norm_key"]] = {"esn": r["esn"], "report_date": parsed_date}
        logger.info(f"[OK] Loaded {len(lookup)} entries from {FSR_REF_VIEW}")
    except Exception as e:
        logger.warning(f"[WARN] Could not load ref view {FSR_REF_VIEW}: {e} — ref enrichment disabled")
    return lookup


def save_chunks_to_delta(documents: List[Document], ref_lookup: dict | None = None):
    """
    Build fully-resolved rows (ESN expansion + ref-view override) entirely in
    Python, then write a single clean append to EMBEDDINGS_TABLE.

    No post-write MERGE or UPDATE — the Delta table is written once, correctly.

    ESN expansion: a chunk tagged with N ESNs becomes N rows (one per ESN) so
    that VS equality filters on generator_serial surface the chunk for every unit.

    ref_lookup (optional): dict returned by load_ref_view_lookup().
    When provided, the ref-view ESN and date overwrite the LLM-derived values;
    ref_view is authoritative.  Pass None to skip enrichment (e.g. if the view
    is unavailable in the current environment).
    """
    from pyspark.sql import SparkSession
    from pyspark.sql.types import (
        StructType, StructField, StringType, IntegerType, DateType, TimestampType,
    )
    from datetime import datetime, date as _date

    spark = SparkSession.builder.getOrCreate()

    _schema = StructType([
        StructField("chunk_id",          StringType(),    nullable=False),
        StructField("pdf_name",          StringType(),    nullable=False),
        StructField("page_number",       IntegerType(),   nullable=True),
        StructField("generator_serial",  StringType(),    nullable=True),
        StructField("report_date",       DateType(),      nullable=True),
        StructField("chunk_text",        StringType(),    nullable=False),
        StructField("created_at",        TimestampType(), nullable=True),
        StructField("uploaded_at",       TimestampType(), nullable=True),
    ])

    def _parse_date(val):
        if val is None:
            return None
        if isinstance(val, _date):
            return val
        if isinstance(val, str) and val.strip():
            try:
                return _date.fromisoformat(val.strip())
            except (ValueError, TypeError):
                return None
        return None

    now = datetime.utcnow()
    rows = []

    for doc in documents:
        meta        = doc.metadata
        doc_id      = meta.get("document_id", "")
        chunk_index = int(meta.get("chunk_index", 0))
        esn_labels  = list(meta.get("esn_labels", []) or [])
        report_date = _parse_date(meta.get("report_date", None))

        # ── ref-view override (authoritative) ─────────────────────────────
        ref_esn = None
        ref_date = None
        if ref_lookup:
            ref_entry = ref_lookup.get(doc_id.lower())
            if ref_entry:
                ref_esn  = ref_entry["esn"]
                ref_date = ref_entry["report_date"]

        # If ref_view has an ESN, use it as the authoritative generator_serial
        # and ensure it appears in esn_labels.
        if ref_esn:
            if ref_esn not in esn_labels:
                esn_labels = [ref_esn] + esn_labels
            # Collapse to ref ESN only for generator_serial purposes but
            # keep all ESN labels for expansion so multi-unit reports still
            # produce multiple rows.
            primary_esn = ref_esn
        else:
            primary_esn = esn_labels[0] if esn_labels else meta.get("generator_serial", None)

        final_date = ref_date if ref_date is not None else report_date

        common = {
            "pdf_name":    doc_id,
            "page_number": meta["start_page"],
            "report_date": final_date,
            "chunk_text":  doc.page_content,
            "created_at":  now,
            "uploaded_at": now,
        }

        if len(esn_labels) > 1:
            # One row per ESN label so VS equality filter works for every unit
            for esn in esn_labels:
                rows.append({
                    **common,
                    "chunk_id":        f"{doc_id}_{chunk_index}__{esn}",
                    "generator_serial": esn,
                })
        else:
            rows.append({
                **common,
                "chunk_id":        f"{doc_id}_{chunk_index}",
                "generator_serial": primary_esn,
            })

    df = spark.createDataFrame(rows, schema=_schema)
    df.write.format("delta").mode("append").saveAsTable(EMBEDDINGS_TABLE)
    enrich_note = f" (ref_view: {ref_lookup is not None})" if ref_lookup is not None else ""
    logger.info(f"[OK] Saved {len(rows)} chunks to {EMBEDDINGS_TABLE}{enrich_note}")


def save_embeddings_to_delta(documents: List[Document], embeddings: np.ndarray):
    """DEPRECATED — VS auto-embeds from chunk_text. Use save_chunks_to_delta() instead."""
    logger.warning("save_embeddings_to_delta() is deprecated — delegating to save_chunks_to_delta()")
    save_chunks_to_delta(documents, ref_lookup=None)


def load_embeddings_from_delta(documents: List[Document]) -> Tuple[np.ndarray, int]:
    """
    Load embeddings from EMBEDDINGS_TABLE aligned to the documents list order.
    Matches on (pdf_name, page_number) which correspond to (document_id, chunk_index).
    Returns (embeddings_array, n_missing).
    """
    from pyspark.sql import SparkSession
    spark = SparkSession.builder.getOrCreate()

    logger.info(f"Loading embeddings from {EMBEDDINGS_TABLE} …")

    lookup = {
        (r["pdf_name"], r["page_number"]): r["embedding"]
        for r in spark.table(EMBEDDINGS_TABLE)
                      .select("pdf_name", "page_number", "embedding")
                      .collect()
    }

    dim = embedding_config.embedding_dim
    arr = np.zeros((len(documents), dim), dtype=np.float32)
    missing = 0

    for i, doc in enumerate(documents):
        key = (doc.metadata.get("document_id", ""), int(doc.metadata.get("chunk_index", 0)))
        if key in lookup:
            arr[i] = np.array(lookup[key], dtype=np.float32)
        else:
            missing += 1

    if missing:
        logger.warning(f"  {missing} embeddings missing from Delta table")

    logger.info(f"  Loaded {len(documents) - missing}/{len(documents)}  shape: {arr.shape}")
    return arr, missing
