"""
Retrieval Experiments – Databricks
Runs experiments across weight configurations, saves results to RESULTS_TABLE (Delta).
"""
import time
from datetime import datetime
from typing import Any, Dict, List, Optional

import numpy as np
import pandas as pd
from langchain_core.documents import Document

from config import EVAL_QUERIES, experiment_config
from retrieval import (
    BM25RetrieverWrapper,
    VectorSearchRetriever,
    WeightedEnsembleRetriever,
    rerank_by_keywords,
)
from utils import setup_logger

logger = setup_logger("experiments")


class RetrievalExperiment:

    def __init__(
        self,
        documents: List[Document],
        embeddings_array: np.ndarray,
        queries: List[Dict] = None,
        weight_configs: List[tuple] = None,
        enable_rerank: bool = True,
        enable_timing: bool = True,
    ):
        self.documents        = documents
        self.embeddings_array = embeddings_array
        self.queries          = queries or EVAL_QUERIES
        self.weight_configs   = weight_configs or experiment_config.weight_configs
        self.enable_rerank    = enable_rerank
        self.enable_timing    = enable_timing
        self.results: List[Dict] = []

        logger.info("Initializing retrievers…")
        self.bm25     = BM25RetrieverWrapper(documents, k=10)
        self.semantic = VectorSearchRetriever(documents, embeddings_array, k=10)
        logger.info("[OK] Retrievers ready")

    # ── Run ──────────────────────────────────────────────────────────────────

    def run(self):
        logger.info("=" * 80)
        logger.info(
            f"RUNNING EXPERIMENTS  |  "
            f"{len(self.queries)} queries × {len(self.weight_configs)} configs"
        )
        logger.info("=" * 80)
        for sem_w, kw_w, label in self.weight_configs:
            self._run_config(sem_w, kw_w, label)

    def _run_config(self, sem_w: float, kw_w: float, label: str):
        logger.info(f"\n[CONFIG] {label}  (semantic={sem_w:.0%}  keyword={kw_w:.0%})")

        if sem_w == 0.0:
            retriever, rtype = self.bm25,     "BM25"
        elif sem_w == 1.0:
            retriever, rtype = self.semantic, "VectorSearch"
        else:
            retriever = WeightedEnsembleRetriever(self.bm25, self.semantic, sem_w, k=10)
            rtype = "Ensemble"

        for qobj in self.queries:
            q = qobj["q"]
            try:
                t0   = time.time()
                docs = retriever.invoke(q)
                lat  = (time.time() - t0) * 1000 if self.enable_timing else 0.0

                if self.enable_rerank and docs:
                    reranked = rerank_by_keywords(q, docs, k=5)
                    final    = [d for d, _ in reranked]
                    top_s    = reranked[0][1] if reranked else 0.0
                else:
                    final, top_s = docs[:5], 0.0

                kw_match = bool(final) and any(
                    kw.lower() in final[0].page_content.lower()
                    for kw in qobj.get("kw", [])
                )
                self.results.append({
                    "query":           q,
                    "category":        qobj.get("cat", ""),
                    "semantic_weight": sem_w,
                    "keyword_weight":  kw_w,
                    "config_label":    label,
                    "retriever_type":  rtype,
                    "num_results":     len(final),
                    "has_results":     1 if final    else 0,
                    "keyword_match":   1 if kw_match else 0,
                    "top_score":       round(float(top_s), 4),
                    "latency_ms":      round(float(lat),   2),
                })
            except Exception as e:
                logger.error(f"  [ERROR] '{q[:40]}': {e}")
                self.results.append({
                    "query": q, "category": qobj.get("cat", ""),
                    "semantic_weight": sem_w, "keyword_weight": kw_w,
                    "config_label": label, "retriever_type": rtype,
                    "num_results": 0, "has_results": 0, "keyword_match": 0,
                    "top_score": 0.0, "latency_ms": 0.0, "error": str(e),
                })

        # Per-config summary
        cfg_rows = [r for r in self.results if r["config_label"] == label]
        if cfg_rows:
            df = pd.DataFrame(cfg_rows)
            logger.info(
                f"  Match Rate: {df['keyword_match'].mean():.1%}  "
                f"Avg Latency: {df['latency_ms'].mean():.1f}ms"
            )

    # ── Persistence ──────────────────────────────────────────────────────────

    def get_results_dataframe(self) -> pd.DataFrame:
        return pd.DataFrame(self.results)

    def save_results(self):
        if not self.results:
            logger.warning("No results to save")
            return
        self._print_summary(self.get_results_dataframe())

    def _print_summary(self, df: pd.DataFrame):
        logger.info("\n" + "=" * 80)
        logger.info("RESULTS SUMMARY")
        logger.info("=" * 80)
        summary = (
            df.groupby("config_label")
            .agg(match_rate=("keyword_match", "mean"), avg_latency=("latency_ms", "mean"))
            .sort_values("match_rate", ascending=False)
        )
        for cfg, row in summary.iterrows():
            logger.info(
                f"  {cfg:<42} Match: {row['match_rate']:.1%}  "
                f"Latency: {row['avg_latency']:.1f}ms"
            )
        best = summary["match_rate"].idxmax()
        logger.info(f"\n  ✅ Best config: {best}")


# ============================================================================
# STANDALONE ANALYSIS HELPERS  (called from pipeline.py)
# ============================================================================

def analyze_results(df: pd.DataFrame) -> Dict[str, Any]:
    return {
        "total_experiments": len(df),
        "by_config": {
            cfg: {
                "match_rate":  float(sub["keyword_match"].mean()),
                "avg_latency": float(sub["latency_ms"].mean()),
            }
            for cfg, sub in df.groupby("config_label")
        },
        "by_category": {
            cat: {"match_rate": float(sub["keyword_match"].mean())}
            for cat, sub in df.groupby("category")
        },
    }


def print_analysis(analysis: Dict[str, Any]):
    logger.info("\n" + "=" * 80 + "\nANALYSIS BY CONFIGURATION\n" + "=" * 80)
    for cfg, s in analysis["by_config"].items():
        logger.info(
            f"  {cfg:<42} Match: {s['match_rate']:.1%}  Latency: {s['avg_latency']:.1f}ms"
        )
