"""
Hybrid Retrieval – Databricks Vector Search (native hybrid)

Uses query_type="hybrid" which combines internally:
  - Dense retrieval  (databricks-gte-large-en auto-embeddings)
  - Learned keyword search  (BM25-style, trained on YOUR data)
Results are fused via Rank Reciprocal Fusion (RRF), scores normalised 0–1.

No custom BM25, FAISS, or ensemble code needed — Databricks handles it all.
"""
import requests
from typing import Dict, List, Optional, Tuple

from config import VS_INDEX_NAME
from utils import setup_logger

logger = setup_logger("retrieval")

# Columns returned from VS index queries
_RETURN_COLUMNS = ["chunk_id", "pdf_name", "page_number", "chunk_text"]


def _get_auth() -> Tuple[str, str]:
    """Return (workspace_url, bearer_token)."""
    import os
    ws = os.getenv("DATABRICKS_HOST", "https://gevernova-ai-dev-dbr.cloud.databricks.com")
    token = None
    try:
        from pyspark.sql import SparkSession
        from pyspark.dbutils import DBUtils
        spark   = SparkSession.builder.getOrCreate()
        dbutils = DBUtils(spark)
        token   = dbutils.notebook.entry_point.getDbutils().notebook().getContext().apiToken().get()
    except Exception:
        token = os.getenv("DATABRICKS_TOKEN", "")
    return ws.rstrip("/"), (token or "")


# ============================================================================
# CORE QUERY FUNCTION
# ============================================================================

def hybrid_search(
    query: str,
    num_results: int = 10,
    filters: Optional[Dict] = None,
    columns: Optional[List[str]] = None,
    score_threshold: Optional[float] = None,
) -> List[Dict]:
    """
    Run a hybrid (vector + keyword) search against the VS index.

    Returns a list of dicts, each with keys:
        chunk_id, pdf_name, page_number, chunk_text, score

    Score interpretation (RRF-normalised):
        ~1.0  → both vector & keyword retrievers agree on high relevance
        ~0.5  → one retriever found it relevant
        <0.5  → low relevance from both
    """
    ws_url, token = _get_auth()
    url = f"{ws_url}/api/2.0/vector-search/indexes/{VS_INDEX_NAME}/query"
    headers = {"Authorization": f"Bearer {token}", "Content-Type": "application/json"}

    body = {
        "query_text": query,
        "columns": columns or _RETURN_COLUMNS,
        "num_results": num_results,
        "query_type": "hybrid",           # ← native hybrid search
    }
    if filters:
        body["filters_json"] = filters
    if score_threshold is not None:
        body["score_threshold"] = score_threshold

    resp = requests.post(url, headers=headers, json=body, timeout=30)
    if not resp.ok:
        logger.error(f"VS query failed HTTP {resp.status_code}: {resp.text[:300]}")
        return []

    data      = resp.json()
    col_names = [c["name"] for c in data.get("manifest", {}).get("columns", [])]
    rows      = data.get("result", {}).get("data_array", [])

    results = []
    for row in rows:
        rec = {col: row[i] for i, col in enumerate(col_names)}
        if score_threshold is not None and rec.get("score", 0) < score_threshold:
            continue
        results.append(rec)
    return results


# ============================================================================
# CONVENIENCE WRAPPERS
# ============================================================================

def search_by_document(
    query: str,
    pdf_name: str,
    num_results: int = 10,
) -> List[Dict]:
    """Hybrid search scoped to a single PDF."""
    return hybrid_search(
        query,
        num_results=num_results,
        filters={"pdf_name": pdf_name},
    )


def search_with_context(
    query: str,
    num_results: int = 5,
) -> str:
    """Return a plain-text context block suitable for LLM prompting."""
    hits = hybrid_search(query, num_results=num_results)
    if not hits:
        return "(no results found)"
    parts = []
    for i, h in enumerate(hits, 1):
        parts.append(
            f"[{i}] (score={h.get('score',0):.3f}, pdf={h.get('pdf_name','?')}, "
            f"page={h.get('page_number','?')})\n{h.get('chunk_text','')}"
        )
    return "\n\n".join(parts)
