# Databricks notebook source
# -------------------------------------------------------------------------
# ESN Diagnostic – test min_count=1, window=1500 chars (4500 total)
#
# Replicates the exact production ingestion path:
#   collect_pdfs_from_volumes  →  load_document_text_for_esn
#   →  prepare_document_text_for_esn  →  analyze_prepared_document_text_for_esn_counts
#
# But overrides DOC_TRUNCATE_WINDOW_CHARS=1500 and MIN_ESN_COUNT=1
# before running, so we can see what ESNs would be identified.
# -------------------------------------------------------------------------

# COMMAND ----------

# MAGIC %pip install --quiet \
# MAGIC   typing_extensions>=4.12.0 \
# MAGIC   langchain-core>=0.1.24 \
# MAGIC   PyMuPDF>=1.23.0 \
# MAGIC   httpx \
# MAGIC   python-dotenv

# COMMAND ----------

dbutils.library.restartPython()

# COMMAND ----------

import sys, os, json, time
from pathlib import Path

# Resolve src/ from the deployed pipeline workspace path
try:
    _ctx     = dbutils.notebook.entry_point.getDbutils().notebook().getContext()
    _nb_path = _ctx.notebookPath().get()
    _ws_dir  = "/Workspace" + str(Path(_nb_path).parent)
    _src_dir = _ws_dir + "/src"
except Exception:
    _src_dir = "./src"

if _src_dir not in sys.path:
    sys.path.insert(0, _src_dir)

print(f"[OK] src path: {_src_dir}")
print(f"[OK] Files:    {sorted(os.listdir(_src_dir))}")

# COMMAND ----------

SECRET_SCOPE_OVERRIDE = "fsr-pipeline"
try:
    _p = dbutils.widgets.get("SECRET_SCOPE_OVERRIDE")
    if _p.strip():
        SECRET_SCOPE_OVERRIDE = _p.strip()
except Exception:
    pass
os.environ["DBR_SECRET_SCOPE"] = SECRET_SCOPE_OVERRIDE

# Import config first — this sets SSL_CERT_FILE / REQUESTS_CA_BUNDLE env vars
# so that requests calls inside utils.py work against the GE Enterprise CA.
import config
import esn_identifier
from utils import collect_pdfs_from_volumes
from esn_identifier import (
    load_document_text_for_esn,
    prepare_document_text_for_esn,
    analyze_prepared_document_text_for_esn_counts,
)

print(f"LITELLM_BASE_URL        = {config.LITELLM_BASE_URL}")
print(f"LITELLM_API_KEY         = {'SET (' + config.LITELLM_API_KEY[:8] + '...)' if config.LITELLM_API_KEY else 'MISSING'}")
print(f"MIN_ESN_COUNT (current) = {esn_identifier.MIN_ESN_COUNT}")
print(f"DOC_TRUNCATE_WINDOW     = {esn_identifier.DOC_TRUNCATE_WINDOW_CHARS}")

# Override constants for this diagnostic run
DIAG_MIN_COUNT           = 1
DIAG_MIN_FRACTION        = 0.10
DIAG_TRUNCATE_WINDOW     = 1500   # → 4500 chars total (start + middle + end)

esn_identifier.MIN_ESN_COUNT           = DIAG_MIN_COUNT
esn_identifier.DOC_TRUNCATE_WINDOW_CHARS = DIAG_TRUNCATE_WINDOW
esn_identifier.DOC_MAX_LLM_CHARS       = DIAG_TRUNCATE_WINDOW * 3

print(f"\nOverrides applied:")
print(f"  MIN_ESN_COUNT           = {esn_identifier.MIN_ESN_COUNT}")
print(f"  DOC_TRUNCATE_WINDOW     = {esn_identifier.DOC_TRUNCATE_WINDOW_CHARS}")
print(f"  DOC_MAX_LLM_CHARS       = {esn_identifier.DOC_MAX_LLM_CHARS}")

def _qualify(counts: dict) -> list:
    total = sum(counts.values())
    if total <= 0:
        return []
    return [
        esn for esn, cnt in sorted(counts.items(), key=lambda x: (-x[1], x[0]))
        if cnt >= DIAG_MIN_COUNT and (cnt / total) >= DIAG_MIN_FRACTION
    ]

# COMMAND ----------

# Target PDFs: (stem, gt_esn)
TARGET_PDFS = [
    # null ESN in base
    ("090dbba1800ef3cb", "290T503"),
    ("090dbba180068b39", "290T532"),
    ("090dbba180076e59", "290T532"),
    ("090dbba180085001", "290T532"),
    ("090dbba1800fc8fb", "290T762"),
    ("090dbba1800fdff4", "290T762"),
    ("090dbba1800f0a21", "337X045"),
    ("090dbba1800f37d6", "337X045"),
    ("090dbba1800f6faa", "337X045"),
    ("090dbba1800f4f5b", "337X305"),
    ("090dbba18003a23c", "337X330"),
    ("090dbba180100488", "337X330"),
    ("090dbba18008c4b1", "337X336"),
    ("090dbba18008eb7c", "337X336"),
    ("090dbba1800ffe6f", "337X336"),
    ("090dbba1801238ab", "337X369"),
    ("090dbba1800bad72", "337X708"),
    ("090dbba1800f7e67", "337X708"),
    ("090dbba1800f4d97", "337X709"),
    ("090dbba18008c1f4", "338X408"),
    ("090dbba1800f09da", "338X408"),
    ("090dbba1801021b6", "338X408"),
    ("090dbba1800ff693", "338X425"),
    ("090dbba1800b5e28", "338X713"),
    ("090dbba180086b3e", "338X722"),
    ("090dbba180086f05", "338X722"),
    ("090dbba180086f0b", "338X722"),
    ("090dbba18008a24f", "338X722"),
    # wrong ESN in base (ref view override)
    ("08ef2ef4-fc25-4bc8-af2e-f4fc253bc86d",  "290T503"),
    ("7523f0ed-4f65-4738-a3f0-ed4f65273858",  "290T762"),
    ("Field_Service_Report_ProjectID_A-1813284_EV-147582_EVP-534570", "290T658"),
    ("Field_Service_Report_ProjectID_A-1561864_EV-118524_C-10357248", "337X233"),
    ("337X305 2022-11-18 Robotic",             "337X305"),
    ("bc4ffb5d-7d8d-4993-8ffb-5d7d8df99367",  "337X709"),
    ("a2e95baf-9f0d-4ab0-a95b-af9f0dcab0be",  "338X424"),
    ("a9843356-c0fb-4574-8433-56c0fb3574b3",  "338X426"),
    ("050114d8-0354-4161-8114-d8035421611b",  "290T530"),
    ("52229_03_30_2022_16_11_58_BJWECBD9FV17J394", "761X004"),
    ("53321_03_30_2022_15_52_25_CCI0K97ZL2VIYWXJ", "761X004"),
    ("Field_Service_Report_ProjectID_A-1632720_EV-118196_C-10357780", "761X004"),
]

target_stems = {stem for stem, _ in TARGET_PDFS}

# COMMAND ----------

# Scan volumes exactly as the pipeline does to find the actual PDF paths.
# collect_pdfs_from_volumes uses the Files API (cert env vars set by config import above).
PDF_VOLUME_PATHS = config.PDF_VOLUME_PATHS
print(f"Scanning {len(PDF_VOLUME_PATHS)} volumes for {len(target_stems)} target PDFs...")

all_pdfs, active_volumes, duplicate_ids = collect_pdfs_from_volumes(PDF_VOLUME_PATHS)
print(f"  Total PDFs found in volumes: {len(all_pdfs)} across {len(active_volumes)} volumes")

stem_to_path = {p.stem: p for p in all_pdfs}
found_stems  = {s for s in target_stems if s in stem_to_path}
missing_stems = target_stems - found_stems

print(f"  Target PDFs found  : {len(found_stems)}")
print(f"  Target PDFs missing: {len(missing_stems)}")
if missing_stems:
    for s in sorted(missing_stems):
        print(f"    NOT FOUND: {s}")

# COMMAND ----------

# For each target PDF found on volumes: run the exact production path
#   load_document_text_for_esn → prepare_document_text_for_esn
#   → analyze_prepared_document_text_for_esn_counts
# with the overridden window/min_count constants applied above.
results = []
gt_match_count = 0

for i, (pdf_stem, gt_esn) in enumerate(TARGET_PDFS, 1):
    pdf_path = stem_to_path.get(pdf_stem)

    if pdf_path is None:
        result = {
            "pdf_name": pdf_stem,
            "gt_esn": gt_esn,
            "pdf_path": None,
            "llm_raw_counts": {},
            "qualified_esns": [],
            "gt_esn_in_qualified": False,
            "gt_esn_raw_count": 0,
            "status": "NOT_FOUND_IN_VOLUMES",
        }
        results.append(result)
        print(f"  [{i:2d}/{len(TARGET_PDFS)}] [?] {pdf_stem[:40]:40s}  gt={gt_esn:8s}  => NOT_FOUND_IN_VOLUMES")
        continue

    try:
        # Exact production path
        doc_text      = load_document_text_for_esn(str(pdf_path))
        prepared_text = prepare_document_text_for_esn(doc_text)
        raw_counts    = analyze_prepared_document_text_for_esn_counts(prepared_text)
        qualified     = _qualify(raw_counts)
        gt_raw_cnt    = raw_counts.get(gt_esn, 0)
        gt_matched    = gt_esn in qualified

        if gt_matched:
            gt_match_count += 1
            status = "GT_ESN_IDENTIFIED"
        elif gt_raw_cnt > 0:
            total = sum(raw_counts.values())
            frac  = gt_raw_cnt / total if total else 0
            status = f"LLM_FOUND_BUT_NOT_QUALIFIED (cnt={gt_raw_cnt}, frac={frac:.2f})"
        else:
            status = "GT_ESN_NOT_IN_LLM_COUNTS"

        result = {
            "pdf_name": pdf_stem,
            "gt_esn": gt_esn,
            "pdf_path": str(pdf_path),
            "prepared_text_len": len(prepared_text),
            "llm_raw_counts": raw_counts,
            "qualified_esns": qualified,
            "gt_esn_in_qualified": gt_matched,
            "gt_esn_raw_count": gt_raw_cnt,
            "status": status,
        }
        results.append(result)
        indicator = "✓" if gt_matched else "✗"
        print(f"  [{i:2d}/{len(TARGET_PDFS)}] [{indicator}] {pdf_stem[:40]:40s}  "
              f"gt={gt_esn:8s}  qualified={qualified}  raw={dict(sorted(raw_counts.items(), key=lambda x:-x[1])[:5])}"
              f"  => {status}")

    except Exception as exc:
        result = {
            "pdf_name": pdf_stem,
            "gt_esn": gt_esn,
            "pdf_path": str(pdf_path),
            "llm_raw_counts": {},
            "qualified_esns": [],
            "gt_esn_in_qualified": False,
            "gt_esn_raw_count": 0,
            "status": f"ERROR: {exc}",
        }
        results.append(result)
        print(f"  [{i:2d}/{len(TARGET_PDFS)}] [!] {pdf_stem[:40]:40s}  ERROR: {exc}")

# COMMAND ----------

from collections import Counter
print(f"\n=== SUMMARY  min_count={DIAG_MIN_COUNT}  min_fraction={DIAG_MIN_FRACTION}  window={DIAG_TRUNCATE_WINDOW} chars ({DIAG_TRUNCATE_WINDOW*3} total) ===")
print(f"  GT ESN correctly identified : {gt_match_count}/{len(TARGET_PDFS)}")
print(f"  Not found in volumes        : {sum(1 for r in results if r['status'] == 'NOT_FOUND_IN_VOLUMES')}")

status_counts = Counter(
    r["status"] if r["status"] in ("GT_ESN_IDENTIFIED", "NOT_FOUND_IN_VOLUMES")
    else r["status"].split(" (")[0]
    for r in results
)
for st, n in sorted(status_counts.items(), key=lambda x: -x[1]):
    print(f"  {n:3d}  {st}")

# PDFs where LLM found the ESN but it still didn't qualify
near_miss = [r for r in results if r["gt_esn_raw_count"] > 0 and not r["gt_esn_in_qualified"]]
if near_miss:
    print(f"\n--- Near misses (LLM found ESN but didn't qualify) ---")
    for r in near_miss:
        total = sum(r["llm_raw_counts"].values())
        frac  = r["gt_esn_raw_count"] / total if total else 0
        print(f"  {r['pdf_name'][:40]:40s}  gt={r['gt_esn']:8s}  "
              f"cnt={r['gt_esn_raw_count']}  frac={frac:.2f}  all_counts={r['llm_raw_counts']}")

dbutils.notebook.exit(json.dumps(results))
