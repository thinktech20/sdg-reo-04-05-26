# Databricks notebook source
import json
from pyspark.sql import functions as F

SERIALS = ["290T434", "290T484", "290T503", "290T530", "290T532", "290T543", "290T577", "290T658", "290T762", "337X045", "337X233", "337X305", "337X330", "337X336", "337X369", "337X393", "337X708", "337X709", "337X758", "338X408", "338X424", "338X425", "338X426", "338X427", "338X713", "338X714", "338X722", "338X724", "338X765", "761X004"]
TABLE = "main.gp_services_sdg_poc.field_service_report"

df = spark.table(TABLE).where(F.col("generator_serial").isin(SERIALS))
agg = (
    df.groupBy("generator_serial")
      .agg(
          F.count("*").alias("delta_row_count"),
          F.countDistinct("pdf_name").alias("delta_pdf_count"),
      )
      .orderBy("generator_serial")
)
rows = [r.asDict() for r in agg.collect()]
present = sorted(r["generator_serial"] for r in rows)
present_set = set(present)
missing = [s for s in SERIALS if s not in present_set]
dbutils.notebook.exit(json.dumps({
    "delta_present_count": len(present),
    "delta_missing_count": len(missing),
    "delta_present_serials": present,
    "delta_missing_serials": missing,
    "delta_details": rows,
}))
