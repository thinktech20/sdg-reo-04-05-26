# Databricks notebook source
# -----------------------------------------------------------------------
# Find GT serial PDFs in the ref_view and check which volumes they live in
# -----------------------------------------------------------------------

# COMMAND ----------

GT_SERIALS = ['290T658', '337X233', '337X244', '337X305', '337X380', '337X704', '761X004']
REF_VIEW   = "vgpd.fsr_std_views.fsr_pdf_ref_view"

from pyspark.sql import SparkSession
spark = SparkSession.builder.getOrCreate()

# COMMAND ----------
# 1. Show all columns available in the ref_view
print("=== ref_view schema ===")
spark.sql(f"DESCRIBE {REF_VIEW}").show(50, truncate=False)

# COMMAND ----------
# 2. Find all PDFs for GT serials
print(f"\n=== ref_view entries for GT serials ===")
serials_sql = ", ".join(f"'{s}'" for s in GT_SERIALS)
df = spark.sql(f"""
    SELECT *
    FROM {REF_VIEW}
    WHERE esn IN ({serials_sql})
    ORDER BY esn, s3_filename
""")
df.show(200, truncate=False)
print(f"Total rows: {df.count()}")

# COMMAND ----------
# 3. Summary: how many PDFs per GT serial
print(f"\n=== PDF count per GT serial ===")
spark.sql(f"""
    SELECT esn, COUNT(*) AS pdf_count
    FROM {REF_VIEW}
    WHERE esn IN ({serials_sql})
    GROUP BY esn
    ORDER BY esn
""").show(20, truncate=False)

# COMMAND ----------
# 4. What volume paths do GT serial PDFs map to?
#    Check which of the 3 configured volume paths contain them.
VOLUME_PATHS = [
    "/Volumes/viud/ing_ud_fieldvision/fv_field_service_report",
    "/Volumes/viud/ing_ud_fsr_manual/manual_field_service_report",
    "/Volumes/vgpd/fsr_std_views/fsr_std_vol/FSR_After_2016/FSR_Databricks",
]

import os
for vpath in VOLUME_PATHS:
    try:
        files = [f.name for f in dbutils.fs.ls(vpath) if f.name.endswith(".pdf")]
        print(f"\n{vpath}: {len(files)} PDFs")
        # Check if any GT serial s3_filenames match files here
        gt_pdfs = df.select("s3_filename").rdd.flatMap(lambda x: x).collect()
        matches = [f for f in files if any(f.startswith(p) or p in f for p in gt_pdfs)]
        print(f"  GT serial PDF matches in this volume: {len(matches)}")
        if matches:
            for m in matches[:10]:
                print(f"    {m}")
    except Exception as e:
        print(f"\n{vpath}: ERROR - {e}")

# COMMAND ----------
# 5. Check if GT serial UUIDs are already in the Delta table
print("\n=== GT serial UUIDs already in main.gp_services_sdg_poc.field_service_report ===")
spark.sql(f"""
    SELECT generator_serial, COUNT(*) as chunk_count
    FROM main.gp_services_sdg_poc.field_service_report
    WHERE generator_serial IN ({serials_sql})
    GROUP BY generator_serial
    ORDER BY generator_serial
""").show(20, truncate=False)

# COMMAND ----------
# 6. Cross-reference: are the s3_filenames from ref_view present in our Delta table?
print("\n=== ref_view s3_filenames vs Delta table pdf_name ===")
spark.sql(f"""
    SELECT r.esn, r.s3_filename, 
           CASE WHEN d.pdf_name IS NOT NULL THEN 'IN DELTA' ELSE 'MISSING' END AS status
    FROM {REF_VIEW} r
    LEFT JOIN main.gp_services_sdg_poc.field_service_report d
           ON r.s3_filename = d.pdf_name
    WHERE r.esn IN ({serials_sql})
    ORDER BY r.esn, status DESC
""").show(200, truncate=False)
