from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Any, Iterator

import pandas as pd
from rank_bm25 import BM25Okapi

from .config import RunConfig
from .databricks_io import query_vector_search, run_sql_query, sql_escape


_WHITESPACE_RE = re.compile(r"\s+")
_TOKEN_RE = re.compile(r"[A-Za-z0-9]+")
_HEATMAP_SEVERITY_FIELDS = {
    "severity_criteria_0_no_data": "No Data",
    "severity_criteria_1_light": "Light",
    "severity_criteria_2_medium": "Medium",
    "severity_criteria_3_heavy": "Heavy",
    "severity_criteria_4_immediate": "Immediate",
}
_FSR_RETURN_COLUMNS = [
    "chunk_id",
    "pdf_name",
    "chunk_text",
    "generator_serial",
]
_IBAT_COLUMNS = [
    "equip_serial_number",
    "equipment_name",
    "equipment_model",
    "equipment_code",
    "cooling_system",
    "excitation_system",
    "equipment_status",
    "original_apparent_pwr_mva",
    "present_voltage_v",
    "speed_rpm",
    "equipment_comm_date",
    "contract_type",
    "csa_contract_number",
    "er_support_level",
    "rotor_rewind",
    "stator_rewind",
]


def clean_scalar(value: Any) -> str:
    if value is None:
        return ""

    try:
        if pd.isna(value):
            return ""
    except Exception:
        pass

    if isinstance(value, str):
        return value.strip()
    return str(value).strip()


def normalize_issue_name(value: Any) -> str:
    text = clean_scalar(value).replace("\r", " ").replace("\n", " ")
    return _WHITESPACE_RE.sub(" ", text).strip().lower()


def normalize_component_name(value: Any) -> str:
    return normalize_issue_name(value)


def load_text(path) -> str:
    return path.read_text(encoding="utf-8")


@dataclass(slots=True)
class IssueContext:
    serial_number: str
    issue_name: str
    normalized_issue_name: str
    component: str
    issue_grouping: str
    issue_prompt: str
    heatmap_row: dict[str, str]
    heatmap_matched: bool
    ibat_row: dict[str, str]
    er_query: dict[str, Any]
    fsr_chunks: list[dict[str, Any]]
    er_chunks: list[dict[str, Any]]
    fsr_source_key: str


class ERChunkRetriever:
    def __init__(self, chunks: list[dict[str, Any]]):
        self._chunks = [chunk for chunk in chunks if clean_scalar(chunk.get("chunk_text", ""))]
        self._tokens = [_tokenize(chunk.get("chunk_text", "")) for chunk in self._chunks]
        self._bm25 = BM25Okapi(self._tokens) if self._tokens else None

    def query(self, query_text: str, k: int) -> list[dict[str, Any]]:
        if not self._bm25 or not self._chunks:
            return []

        query_tokens = _tokenize(query_text)
        if not query_tokens:
            return self._chunks[:k]

        scores = self._bm25.get_scores(query_tokens)
        ranked_indexes = sorted(
            range(len(scores)),
            key=lambda index: float(scores[index]),
            reverse=True,
        )[: max(k * 4, k)]

        scored_rows: list[dict[str, Any]] = []
        for rank, index in enumerate(ranked_indexes, start=1):
            row = dict(self._chunks[index])
            overlap = _jaccard(query_tokens, self._tokens[index])
            score = float(scores[index]) + overlap + (1.0 / rank)
            if clean_scalar(row.get("status", "")).lower() == "complete":
                score *= 1.2
            row["score"] = round(score, 4)
            scored_rows.append(row)

        deduped: list[dict[str, Any]] = []
        seen_keys: set[tuple[str, str]] = set()
        for row in scored_rows:
            dedupe_key = (
                clean_scalar(row.get("er_number", "")),
                clean_scalar(row.get("chunk_index", "")),
            )
            if dedupe_key in seen_keys:
                continue
            seen_keys.add(dedupe_key)
            deduped.append(row)
            if len(deduped) >= k:
                break
        return deduped


def _clean_dict(record: dict[str, Any]) -> dict[str, str]:
    return {str(key): clean_scalar(value) for key, value in record.items()}


def _tokenize(text: Any) -> list[str]:
    return [match.group(0).lower() for match in _TOKEN_RE.finditer(clean_scalar(text))]


def _jaccard(left: list[str], right: list[str]) -> float:
    left_set = set(left)
    right_set = set(right)
    if not left_set or not right_set:
        return 0.0
    union = left_set | right_set
    if not union:
        return 0.0
    return len(left_set & right_set) / len(union)


def _build_heatmap_query(heatmap_row: dict[str, str]) -> str:
    issue_prompt = clean_scalar(heatmap_row.get("issue_prompt", ""))
    severity_parts = []
    for field_name, label in _HEATMAP_SEVERITY_FIELDS.items():
        value = clean_scalar(heatmap_row.get(field_name, ""))
        if value:
            severity_parts.append(f"{label}: {value}")
    severity_text = " | ".join(severity_parts)
    return f"{issue_prompt} {severity_text}".strip()


def _build_er_query_payload(heatmap_row: dict[str, str]) -> dict[str, Any]:
    return {
        "component": clean_scalar(heatmap_row.get("component", "")),
        "issue_name": clean_scalar(heatmap_row.get("issue_name", "")),
        "issue_prompt": clean_scalar(heatmap_row.get("issue_prompt", "")),
        "severity_criteria": {
            label: clean_scalar(heatmap_row.get(field_name, ""))
            for field_name, label in _HEATMAP_SEVERITY_FIELDS.items()
            if clean_scalar(heatmap_row.get(field_name, ""))
        },
    }


def load_ibat_table(config: RunConfig, serials: list[str]) -> pd.DataFrame:
    ibat_path = config.ibat_path
    if ibat_path.exists():
        df = pd.read_csv(ibat_path).fillna("")
        df.columns = df.columns.str.strip()
        if "equip_serial_number" not in df.columns:
            raise ValueError(f"IBAT CSV missing equip_serial_number column: {ibat_path}")

        df["equip_serial_number"] = df["equip_serial_number"].astype(str).str.strip()
        wanted_serials = {serial.strip() for serial in serials if serial.strip()}
        if wanted_serials:
            df = df.loc[df["equip_serial_number"].isin(wanted_serials)].copy()

        print(f"[OK] Loaded IBAT rows from CSV: {ibat_path} ({len(df)} rows)")
        return df.reset_index(drop=True)

    serial_list = ", ".join(f"'{sql_escape(serial)}'" for serial in serials)
    column_list = ", ".join(_IBAT_COLUMNS)
    query = f"""
        SELECT DISTINCT {column_list}
        FROM {config.ibat_equipment_view}
        WHERE equip_serial_number IN ({serial_list})
        ORDER BY equip_serial_number
    """
    df = run_sql_query(query, config)
    if df.empty:
        return df

    df.columns = df.columns.str.strip()
    df["equip_serial_number"] = df["equip_serial_number"].astype(str).str.strip()
    return df


def load_heatmap_table(config: RunConfig) -> pd.DataFrame:
    df = pd.read_excel(config.heatmap_path, sheet_name="Sheet1")
    df.columns = df.columns.str.strip()
    df["component"] = df["component"].astype(str).str.strip()
    df["component"] = df["component"].replace({"Nan": pd.NA, "nan": pd.NA}).ffill()
    df["issue_name"] = df["issue_name"].astype(str).str.strip()
    return df


def load_sot_issue_table(config: RunConfig) -> pd.DataFrame:
    df = pd.read_excel(config.sot_ground_truth_path, sheet_name="Sheet1")
    df.columns = [clean_scalar(column) for column in df.columns]
    df = df.loc[:, ~df.columns.str.startswith("Unnamed")].copy()
    df["component"] = df["component"].replace("", pd.NA).ffill().fillna("")
    df["issue_name"] = df["issue_name"].astype(str).str.strip()
    df = df.loc[df["issue_name"].ne("")].copy()
    return df[["component", "issue_name"]].drop_duplicates().reset_index(drop=True)


def build_heatmap_lookup(
    heatmap_df: pd.DataFrame,
) -> tuple[dict[tuple[str, str], dict[str, str]], dict[str, list[dict[str, str]]]]:
    by_component: dict[tuple[str, str], dict[str, str]] = {}
    by_issue: dict[str, list[dict[str, str]]] = {}

    for _, row in heatmap_df.iterrows():
        record = _clean_dict(row.to_dict())
        key = (
            normalize_component_name(record.get("component", "")),
            normalize_issue_name(record.get("issue_name", "")),
        )
        by_component[key] = record
        by_issue.setdefault(key[1], []).append(record)

    return by_component, by_issue


def discover_serials(config: RunConfig, ibat_df: pd.DataFrame) -> list[str]:
    serials = list(config.serials or config.default_serials)
    if config.max_serials is not None:
        serials = serials[: config.max_serials]

    if config.skip_missing_fsr_serials and config.missing_fsr_serials:
        missing_serials = {serial.strip() for serial in config.missing_fsr_serials if serial.strip()}
        skipped = [serial for serial in serials if serial in missing_serials]
        if skipped:
            print(
                "[WARN] Skipping serials with no ingested FSR files: "
                + ", ".join(skipped)
            )
        serials = [serial for serial in serials if serial not in missing_serials]

    if ibat_df.empty:
        return serials

    available = set(ibat_df["equip_serial_number"].astype(str).str.strip())
    return [serial for serial in serials if serial in available]


def _load_er_chunks_for_serial(config: RunConfig, serial_number: str) -> list[dict[str, Any]]:
    query = f"""
        SELECT
            chunk_id,
            er_number,
            chunk_index,
            total_chunks,
            chunk_text,
            token_count,
            serial_number,
            opened_at,
            status,
            u_component,
            u_field_action_taken,
            equipment,
            equipment_id
        FROM {config.er_chunks_table}
        WHERE serial_number = '{sql_escape(serial_number)}'
        ORDER BY opened_at DESC, er_number, chunk_index
    """
    df = run_sql_query(query, config)
    if df.empty:
        return []

    records = df.fillna("").to_dict(orient="records")
    rows: list[dict[str, Any]] = []
    for record in records:
        row = _clean_dict(record)
        row["original_tokens"] = int(clean_scalar(record.get("token_count", 0)) or 0)
        row["score"] = 0.0
        rows.append(row)
    return rows


def _load_fsr_chunks_for_query(
    config: RunConfig,
    serial_number: str,
    query_text: str,
) -> list[dict[str, Any]]:
    raw_rows = query_vector_search(
        query_text,
        serial_number,
        config,
        num_results=max(config.max_fsr_chunks, 20),
        columns=_FSR_RETURN_COLUMNS,
        query_type="HYBRID",
    )

    rows: list[dict[str, Any]] = []
    for raw_row in raw_rows:
        rows.append(
            {
                "chunk_id": clean_scalar(raw_row.get("chunk_id", "")),
                "pdf_name": clean_scalar(raw_row.get("pdf_name", "")),
                "page_number": clean_scalar(raw_row.get("page_number", "")),
                "chunk_text": clean_scalar(raw_row.get("chunk_text", "")),
                "generator_serial": clean_scalar(raw_row.get("generator_serial", serial_number)),
                "score": float(raw_row.get("score", 0.0) or 0.0),
            }
        )
    return rows


def iter_issue_contexts(config: RunConfig) -> Iterator[IssueContext]:
    heatmap_df = load_heatmap_table(config)
    heatmap_by_component, heatmap_by_issue = build_heatmap_lookup(heatmap_df)
    sot_issue_df = load_sot_issue_table(config)

    ibat_serials = list(config.serials or config.default_serials)
    ibat_df = load_ibat_table(config, ibat_serials)
    serials = discover_serials(config, ibat_df)
    issue_filter = {normalize_issue_name(issue) for issue in config.issues or []}

    ibat_rows_by_serial = {
        clean_scalar(row.get("equip_serial_number", "")): _clean_dict(row)
        for row in ibat_df.fillna("").to_dict(orient="records")
    }

    for serial_number in serials:
        ibat_row = ibat_rows_by_serial.get(serial_number)
        if ibat_row is None:
            continue

        er_retriever = ERChunkRetriever(_load_er_chunks_for_serial(config, serial_number))
        yielded_for_serial = 0

        for _, issue_row in sot_issue_df.iterrows():
            component = clean_scalar(issue_row.get("component", ""))
            issue_name = clean_scalar(issue_row.get("issue_name", ""))
            normalized_issue = normalize_issue_name(issue_name)
            if issue_filter and normalized_issue not in issue_filter:
                continue

            heatmap_row = heatmap_by_component.get(
                (normalize_component_name(component), normalized_issue)
            )
            heatmap_matched = heatmap_row is not None
            if heatmap_row is None:
                issue_matches = heatmap_by_issue.get(normalized_issue, [])
                heatmap_row = issue_matches[0] if len(issue_matches) == 1 else {
                    "component": component,
                    "issue_name": issue_name,
                    "issue_grouping": "",
                    "issue_prompt": issue_name,
                }

            query_text = _build_heatmap_query(heatmap_row)
            er_query = _build_er_query_payload(heatmap_row)
            er_chunks = er_retriever.query(query_text, max(config.max_er_chunks, 20))
            fsr_chunks = _load_fsr_chunks_for_query(config, serial_number, query_text)

            yield IssueContext(
                serial_number=serial_number,
                issue_name=issue_name,
                normalized_issue_name=normalized_issue,
                component=component or clean_scalar(heatmap_row.get("component", "")),
                issue_grouping=clean_scalar(heatmap_row.get("issue_grouping", "")),
                issue_prompt=clean_scalar(heatmap_row.get("issue_prompt", issue_name)),
                heatmap_row=heatmap_row,
                heatmap_matched=heatmap_matched,
                ibat_row=ibat_row,
                er_query=er_query,
                fsr_chunks=fsr_chunks,
                er_chunks=er_chunks,
                fsr_source_key=issue_name,
            )
            yielded_for_serial += 1

            if config.max_issues is not None and yielded_for_serial >= config.max_issues:
                break