from __future__ import annotations

import json
import os
import time
from pathlib import Path
from typing import Any

import pandas as pd
import requests

from .config import RunConfig, WORKSPACE_DIR, get_dbutils, is_databricks


DEFAULT_HOST = os.getenv(
    "DATABRICKS_HOST",
    "https://gevernova-ai-dev-dbr.cloud.databricks.com",
).rstrip("/")

_RETRYABLE_STATUS_CODES = {408, 409, 425, 429, 500, 502, 503, 504}


def sql_escape(value: str) -> str:
    return str(value).replace("'", "''")


def get_workspace_host() -> str:
    dbutils = get_dbutils()
    if dbutils is not None:
        try:
            ctx = dbutils.notebook.entry_point.getDbutils().notebook().getContext()
            return str(ctx.apiUrl().get()).rstrip("/")
        except Exception:
            pass
    return DEFAULT_HOST


def get_workspace_token() -> str:
    dbutils = get_dbutils()
    if dbutils is not None:
        try:
            ctx = dbutils.notebook.entry_point.getDbutils().notebook().getContext()
            token = str(ctx.apiToken().get()).strip().strip("'\"")
            if token:
                return token
        except Exception:
            pass

    env_token = os.getenv("DATABRICKS_TOKEN", "").strip().strip("'\"")
    if env_token:
        return env_token

    token_file = WORKSPACE_DIR / "dbr_token.txt"
    if token_file.exists():
        return token_file.read_text(encoding="utf-8").strip().strip("'\"")

    return ""


def _headers(token: str, *, json_content: bool = False) -> dict[str, str]:
    headers = {"Authorization": f"Bearer {token}"}
    if json_content:
        headers["Content-Type"] = "application/json"
    return headers


def _build_session(*, verify_value: str | bool, corp_proxy: str = "") -> requests.Session:
    session = requests.Session()
    session.trust_env = False
    session.verify = verify_value
    if corp_proxy:
        session.proxies.update({"http": corp_proxy, "https": corp_proxy})
    return session


def _build_request_url(base_url: str, request_path: str) -> str:
    base = base_url.rstrip("/")
    path = request_path if request_path.startswith("/") else f"/{request_path}"
    if base.endswith("/v1") and path.startswith("/v1/"):
        path = path[3:]
    return base + path


def _candidate_embedding_urls(base_url: str, request_path: str) -> list[str]:
    urls = [_build_request_url(base_url, request_path)]
    for fallback_path in ("/v1/embeddings", "/embeddings"):
        candidate = _build_request_url(base_url, fallback_path)
        if candidate not in urls:
            urls.append(candidate)
    return urls


def _embed_query_text(query_text: str, config: RunConfig) -> list[float]:
    api_key = config.resolve_api_key().strip()
    if not api_key:
        raise RuntimeError(
            "Missing LITELLM_API_KEY. Set it in the environment or Databricks secret scope."
        )

    urls = _candidate_embedding_urls(config.litellm_base_url, config.embedding_request_path)
    payload = {
        "model": config.fsr_vs_query_embedding_model,
        "input": [query_text],
    }

    session = _build_session(
        verify_value=config.verify_ssl,
        corp_proxy=config.corp_proxy,
    )
    session.headers.update(
        {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
        }
    )

    failures: list[str] = []
    for url_index, url in enumerate(urls):
        for attempt in range(1, config.retry_attempts + 1):
            try:
                response = session.post(
                    url,
                    json=payload,
                    timeout=config.fsr_vs_query_embedding_timeout_sec,
                )
                if response.status_code == 404 and url_index < len(urls) - 1:
                    failures.append(f"{url} -> HTTP 404")
                    break
                if response.status_code >= 400:
                    message = f"HTTP {response.status_code}: {response.text[:500]}"
                    if response.status_code in _RETRYABLE_STATUS_CODES:
                        raise RuntimeError(message)
                    raise RuntimeError(
                        "LiteLLM query embedding request failed: " + message
                    )

                body = response.json()
                data = body.get("data") or []
                if len(data) != 1:
                    raise RuntimeError(
                        f"Expected 1 query embedding, received {len(data)}"
                    )
                vector = [float(value) for value in data[0].get("embedding", [])]
                if not vector:
                    raise RuntimeError("LiteLLM returned an empty query embedding.")
                return vector
            except Exception as exc:
                if attempt >= config.retry_attempts:
                    failures.append(f"{url} -> {exc}")
                else:
                    time.sleep(min(2 * attempt, 10))

    raise RuntimeError(
        "LiteLLM query embedding request failed for all candidate endpoints: "
        + " | ".join(failures)
    )


def _api_json(
    method: str,
    path: str,
    token: str,
    *,
    verify_value: str | bool = True,
    corp_proxy: str = "",
    **kwargs: Any,
) -> dict[str, Any]:
    host = get_workspace_host()
    session = _build_session(verify_value=verify_value, corp_proxy=corp_proxy)
    response = session.request(
        method,
        f"{host}/api/2.0/{path}",
        headers=_headers(token, json_content="json" in kwargs),
        timeout=kwargs.pop("timeout", 60),
        **kwargs,
    )
    if response.status_code not in (200, 201):
        raise RuntimeError(
            f"API {method.upper()} /{path} -> HTTP {response.status_code}\n{response.text[:1000]}"
        )
    return response.json() if response.text.strip() else {}


def run_sql_query(query: str, config: RunConfig) -> pd.DataFrame:
    spark_error: Exception | None = None

    if is_databricks():
        try:
            from pyspark.sql import SparkSession

            spark = SparkSession.builder.getOrCreate()
            return spark.sql(query).toPandas()
        except Exception as exc:
            spark_error = exc
            print(f"[WARN] Spark SQL query failed; retrying via SQL warehouse API: {exc}")

    token = get_workspace_token()
    if not token:
        message = "Databricks token not found for SQL query execution."
        if spark_error is not None:
            raise RuntimeError(message) from spark_error
        raise RuntimeError(message)

    body = _api_json(
        "POST",
        "sql/statements",
        token,
        verify_value=config.databricks_verify_ssl,
        corp_proxy=config.corp_proxy,
        json={
            "statement": query,
            "warehouse_id": config.sql_warehouse_id,
            "wait_timeout": "50s",
        },
        timeout=120,
    )
    state = body.get("status", {}).get("state", "")
    statement_id = body.get("statement_id", "")

    poll_count = 0
    while state in {"PENDING", "RUNNING"} and statement_id and poll_count < 30:
        time.sleep(5)
        poll_count += 1
        body = _api_json(
            "GET",
            f"sql/statements/{statement_id}",
            token,
            verify_value=config.databricks_verify_ssl,
            corp_proxy=config.corp_proxy,
        )
        state = body.get("status", {}).get("state", "")

    if state == "FAILED":
        error = body.get("status", {}).get("error", {}).get("message", "Unknown SQL failure")
        raise RuntimeError(f"SQL failed: {error}\nStatement: {query[:400]}")

    manifest = body.get("manifest", {}) or {}
    schema = (manifest.get("schema", {}) or {}).get("columns", [])
    columns = [column.get("name") for column in schema]
    rows = ((body.get("result", {}) or {}).get("data_array") or [])
    if not columns:
        return pd.DataFrame()
    return pd.DataFrame(rows, columns=columns)


def query_vector_search(
    query_text: str,
    serial_number: str,
    config: RunConfig,
    *,
    num_results: int,
    columns: list[str],
    query_type: str = "HYBRID",
) -> list[dict[str, Any]]:
    token = get_workspace_token()
    if not token:
        raise RuntimeError("Databricks token not found for Vector Search query execution.")

    query_vector = _embed_query_text(query_text, config)

    url = f"{get_workspace_host()}/api/2.0/vector-search/indexes/{config.fsr_vs_index_name}/query"
    session = _build_session(
        verify_value=config.databricks_verify_ssl,
        corp_proxy=config.corp_proxy,
    )
    response = session.post(
        url,
        headers=_headers(token, json_content=True),
        json={
            "query": query_text,
            "query_text": query_text,
            "query_vector": query_vector,
            "columns": columns,
            "num_results": num_results,
            "query_type": (query_type or config.fsr_vs_query_type).upper(),
            "filters_json": json.dumps({"generator_serial": serial_number}),
        },
        timeout=60,
    )
    if not response.ok:
        raise RuntimeError(
            f"Vector Search query failed HTTP {response.status_code}: {response.text[:500]}"
        )

    data = response.json()
    manifest_columns = [column["name"] for column in data.get("manifest", {}).get("columns", [])]
    rows = data.get("result", {}).get("data_array", [])

    results: list[dict[str, Any]] = []
    for row in rows:
        row_dict = {column: row[index] for index, column in enumerate(manifest_columns)}
        results.append(row_dict)
    return results