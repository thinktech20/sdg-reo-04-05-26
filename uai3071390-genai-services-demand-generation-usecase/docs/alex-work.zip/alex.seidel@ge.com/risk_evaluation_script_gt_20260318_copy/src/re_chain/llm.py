from __future__ import annotations

import json
import time
from typing import Any

import requests

from .config import RunConfig


RETRYABLE_STATUS_CODES = {408, 409, 425, 429, 500, 502, 503, 504}


class RetryableLiteLLMError(RuntimeError):
    pass


class ContentFilteredLiteLLMError(RuntimeError):
    pass


def _build_request_url(base_url: str, request_path: str) -> str:
    base = base_url.rstrip("/")
    path = request_path if request_path.startswith("/") else f"/{request_path}"
    if base.endswith("/v1") and path.startswith("/v1/"):
        path = path[3:]
    return base + path


def _join_content_parts(content: Any) -> str:
    if isinstance(content, str):
        return content.strip()

    if not isinstance(content, list):
        return ""

    parts: list[str] = []
    for item in content:
        if isinstance(item, str):
            text = item.strip()
        elif isinstance(item, dict):
            text = str(item.get("text") or item.get("content") or "").strip()
        else:
            text = ""
        if text:
            parts.append(text)
    return "\n".join(parts).strip()


def _extract_response_content(data: dict[str, Any]) -> str:
    choices = data.get("choices")
    if not isinstance(choices, list) or not choices:
        raise RuntimeError("Response JSON missing choices")

    choice = choices[0] or {}
    message = choice.get("message") or {}
    content = _join_content_parts(message.get("content"))
    if content:
        return content

    finish_reason = str(choice.get("finish_reason") or "").strip() or "unknown"
    refusal = str(message.get("refusal") or "").strip()
    if refusal:
        raise RuntimeError(f"Model refused response: {refusal}")
    if finish_reason == "content_filter":
        raise ContentFilteredLiteLLMError("Model returned content_filter with no content")

    raise RuntimeError(
        f"Response JSON missing choices[0].message.content (finish_reason={finish_reason})"
    )


def _is_retryable_error(exc: Exception) -> bool:
    if isinstance(exc, RetryableLiteLLMError):
        return True
    if isinstance(exc, requests.exceptions.Timeout):
        return True
    if isinstance(exc, requests.exceptions.ConnectionError):
        return True
    return False


def _retry_delay_sec(attempt: int, config: RunConfig) -> float:
    delay = config.retry_backoff_base_sec * (2 ** max(attempt - 1, 0))
    return min(delay, config.retry_backoff_cap_sec)


class LiteLLMClient:
    def __init__(self, config: RunConfig):
        self.config = config
        self.api_key = config.resolve_api_key().strip()
        self.url = _build_request_url(config.litellm_base_url, config.request_path)
        self.session = requests.Session()
        self.session.trust_env = False
        self.session.headers.update(
            {
                "Authorization": f"Bearer {self.api_key}",
                "Content-Type": "application/json",
            }
        )
        self.session.verify = config.verify_ssl
        if config.corp_proxy:
            self.session.proxies.update(
                {"http": config.corp_proxy, "https": config.corp_proxy}
            )

    def chat(self, system_prompt: str, user_prompt: str) -> dict[str, Any]:
        if not self.api_key:
            raise RuntimeError(
                "Missing LITELLM_API_KEY. Set it in the environment or Databricks secret scope."
            )

        payload = {
            "model": self.config.model_name,
            "messages": [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt},
            ],
            "temperature": self.config.temperature,
        }

        last_error: Exception | None = None
        for attempt in range(1, self.config.retry_attempts + 1):
            started_at = time.perf_counter()
            try:
                response = self.session.post(
                    self.url,
                    json=payload,
                    timeout=self.config.request_timeout_sec,
                )
                if response.status_code >= 400:
                    body = response.text.strip().replace("\n", " ")
                    error_message = (
                        f"HTTP {response.status_code} for {self.url}: {body[:800]}"
                    )
                    if response.status_code in RETRYABLE_STATUS_CODES:
                        raise RetryableLiteLLMError(error_message)
                    raise RuntimeError(error_message)
                data = response.json()
                content = _extract_response_content(data)
                return {
                    "raw_response": content,
                    "response_json": data,
                    "latency_sec": round(time.perf_counter() - started_at, 3),
                }
            except ContentFilteredLiteLLMError:
                raise
            except Exception as exc:
                last_error = exc
                if attempt == self.config.retry_attempts or not _is_retryable_error(exc):
                    break
                time.sleep(_retry_delay_sec(attempt, self.config))

        raise RuntimeError(
            f"LiteLLM request failed after {self.config.retry_attempts} attempts: {last_error}"
        )


def _strip_code_fences(raw_response: str) -> str:
    cleaned = raw_response.strip()
    if not cleaned.startswith("```"):
        return cleaned

    lines = cleaned.splitlines()
    if lines and lines[0].startswith("```"):
        lines = lines[1:]
    if lines and lines[-1].strip() == "```":
        lines = lines[:-1]
    return "\n".join(lines).strip()


def _extract_balanced_json(raw_text: str) -> str:
    pairs = {"{": "}", "[": "]"}

    for start_index, start_char in enumerate(raw_text):
        if start_char not in pairs:
            continue

        stack: list[str] = []
        in_string = False
        escape_next = False

        for index in range(start_index, len(raw_text)):
            char = raw_text[index]
            if escape_next:
                escape_next = False
                continue

            if in_string:
                if char == "\\":
                    escape_next = True
                elif char == '"':
                    in_string = False
                continue

            if char == '"':
                in_string = True
            elif char in pairs:
                stack.append(pairs[char])
            elif char in "]}":
                if not stack or char != stack[-1]:
                    break
                stack.pop()
                if not stack:
                    return raw_text[start_index : index + 1]

    return ""


def parse_llm_response(raw_response: str) -> dict[str, Any]:
    if not raw_response or not raw_response.strip():
        raise ValueError("LLM response was empty")

    cleaned = _strip_code_fences(raw_response)
    candidates = [cleaned]
    extracted = _extract_balanced_json(cleaned)
    if extracted and extracted not in candidates:
        candidates.append(extracted)

    last_error: Exception | None = None
    for candidate in candidates:
        try:
            parsed = json.loads(candidate)
            if isinstance(parsed, list):
                return {"findings": parsed, "summary": ""}
            if not isinstance(parsed, dict):
                raise ValueError("Parsed response was not a JSON object")
            parsed.setdefault("findings", [])
            parsed.setdefault("summary", "")
            return parsed
        except Exception as exc:
            last_error = exc

    raise ValueError(f"Could not parse LLM response as JSON: {last_error}")