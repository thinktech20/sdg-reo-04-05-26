from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

try:
    from dotenv import load_dotenv
except Exception:  # pragma: no cover - optional dependency in some runtimes
    load_dotenv = None


PROJECT_DIR = Path(__file__).resolve().parents[2]
WORKSPACE_DIR = PROJECT_DIR.parent
INPUT_DATA_DIR = PROJECT_DIR / "input data"
OUTPUT_DIR = PROJECT_DIR / "outputs"
CERT_PATH_CANDIDATES = (
    PROJECT_DIR / "GE_Enterprise_Root_CA_2_1.crt",
    WORKSPACE_DIR / "GE_Enterprise_Root_CA_2_1.crt",
)

ALL_GT_SERIALS = [
    "290T434",
    "290T484",
    "290T503",
    "290T530",
    "290T532",
    "290T543",
    "290T577",
    "290T658",
    "290T762",
    "337X045",
    "337X233",
    "337X305",
    "337X330",
    "337X336",
    "337X369",
    "337X393",
    "337X708",
    "337X709",
    "337X758",
    "338X408",
    "338X424",
    "338X425",
    "338X426",
    "338X427",
    "338X713",
    "338X714",
    "338X722",
    "338X724",
    "338X765",
    "761X004",
]

MISSING_GT_FSR_SERIALS = [
    "290T577",
    "337X393",
    "337X758",
    "338X714",
]

DEFAULT_GT_SERIALS = [
    serial
    for serial in ALL_GT_SERIALS
    if serial not in set(MISSING_GT_FSR_SERIALS)
]


def _load_env_files() -> None:
    if load_dotenv is None:
        return

    for env_path in (WORKSPACE_DIR / ".env", PROJECT_DIR / ".env"):
        if env_path.exists():
            load_dotenv(env_path, override=False)


_load_env_files()


def env_bool(name: str, default: bool = False) -> bool:
    raw = os.getenv(name)
    if raw is None:
        return default
    return raw.strip().lower() in {"1", "true", "t", "yes", "y", "on"}


def env_int(name: str, default: int) -> int:
    raw = os.getenv(name)
    if raw is None or raw.strip() == "":
        return default
    return int(raw)


def is_databricks() -> bool:
    return (
        "DATABRICKS_RUNTIME_VERSION" in os.environ
        or "DB_HOME" in os.environ
        or Path("/databricks/python").exists()
    )


def get_dbutils():
    if not is_databricks():
        return None

    try:
        from pyspark.dbutils import DBUtils
        from pyspark.sql import SparkSession

        spark = SparkSession.builder.getOrCreate()
        return DBUtils(spark)
    except Exception:
        return None


def get_secret(scope: str, key: str, env_fallback: str = "") -> str:
    dbutils = get_dbutils()
    if dbutils is not None:
        try:
            value = dbutils.secrets.get(scope=scope, key=key)
            if value:
                return value
        except Exception:
            pass

    return os.getenv(key, env_fallback)


def split_csv_arg(raw: Optional[str]) -> Optional[list[str]]:
    if raw is None:
        return None

    parts = [piece.strip() for piece in raw.replace("\n", ",").split(",")]
    items = [piece for piece in parts if piece]
    return items or None


def _parse_verify_value(raw_value: str) -> str | bool:
    normalized = raw_value.strip().lower()
    if normalized in {"1", "true", "t", "yes", "y", "on"}:
        return True
    if normalized in {"0", "false", "f", "no", "n", "off"}:
        return False
    return raw_value


def resolve_ssl_verify() -> str | bool:
    raw_override = os.getenv("RE_CHAIN_LITELLM_VERIFY_SSL", "").strip()
    if not raw_override:
        raw_override = os.getenv("RE_CHAIN_VERIFY_SSL", "").strip()
    if raw_override:
        return _parse_verify_value(raw_override)

    for candidate in CERT_PATH_CANDIDATES:
        if candidate.exists():
            return str(candidate)

    return True


def resolve_databricks_verify_ssl() -> str | bool:
    raw_override = os.getenv("RE_CHAIN_DATABRICKS_VERIFY_SSL", "").strip()
    if raw_override:
        return _parse_verify_value(raw_override)
    return True


@dataclass(slots=True)
class RunConfig:
    input_data_dir: Path = INPUT_DATA_DIR
    output_csv: Path = OUTPUT_DIR / "re_chain_results.csv"
    model_name: str = os.getenv("RE_CHAIN_MODEL", "azure-gpt-4o")
    litellm_base_url: str = os.getenv(
        "LITELLM_BASE_URL", "https://dev-gateway.apps.gevernova.net"
    )
    secret_scope: str = os.getenv("DBR_SECRET_SCOPE", "fsr-pipeline")
    request_timeout_sec: int = env_int("RE_CHAIN_TIMEOUT_SEC", 30)
    max_fsr_chunks: int = env_int("RE_CHAIN_MAX_FSR_CHUNKS", 20)
    max_er_chunks: int = env_int("RE_CHAIN_MAX_ER_CHUNKS", 20)
    max_chunk_chars: int = env_int("RE_CHAIN_MAX_CHUNK_CHARS", 10000)
    max_workers: int = env_int("RE_CHAIN_MAX_WORKERS", 10)
    retry_attempts: int = env_int("RE_CHAIN_RETRY_ATTEMPTS", 6)
    retry_backoff_base_sec: float = float(os.getenv("RE_CHAIN_RETRY_BASE_SEC", "30"))
    retry_backoff_cap_sec: float = float(os.getenv("RE_CHAIN_RETRY_CAP_SEC", "300"))
    temperature: float = float(os.getenv("RE_CHAIN_TEMPERATURE", "0.1"))
    force_rerun: bool = env_bool("RE_CHAIN_FORCE_RERUN", False)
    serials: Optional[list[str]] = None
    issues: Optional[list[str]] = None
    max_serials: Optional[int] = None
    max_issues: Optional[int] = None
    dry_run: bool = env_bool("RE_CHAIN_DRY_RUN", False)
    verify_ssl: str | bool = field(default_factory=resolve_ssl_verify)
    databricks_verify_ssl: str | bool = field(default_factory=resolve_databricks_verify_ssl)
    corp_proxy: str = os.getenv("CORP_PROXY", "").strip()
    request_path: str = os.getenv("RE_CHAIN_REQUEST_PATH", "/v1/chat/completions")
    embedding_request_path: str = os.getenv(
        "RE_CHAIN_EMBEDDING_REQUEST_PATH",
        os.getenv("GT_EMBEDDING_REQUEST_PATH", "/v1/embeddings"),
    )
    sql_warehouse_id: str = os.getenv("RE_CHAIN_SQL_WAREHOUSE", "c383216f6af5c7c0")
    fsr_vs_index_name: str = os.getenv(
        "RE_CHAIN_FSR_GT_VS_INDEX",
        "main.gp_services_sdg_poc.vs_field_service_report_gt_litellm",
    )
    fsr_vs_query_embedding_model: str = os.getenv(
        "RE_CHAIN_FSR_QUERY_EMBEDDING_MODEL",
        os.getenv("GT_VS_EMBEDDING_MODEL", "azure-text-embedding-3-large-1"),
    )
    fsr_vs_query_embedding_timeout_sec: int = env_int(
        "RE_CHAIN_FSR_QUERY_EMBEDDING_TIMEOUT_SEC",
        120,
    )
    fsr_vs_query_type: str = os.getenv("RE_CHAIN_FSR_VS_QUERY_TYPE", "HYBRID").strip().upper() or "HYBRID"
    er_chunks_table: str = os.getenv(
        "RE_CHAIN_ER_CHUNKS_TABLE",
        "vaid.ai_sot_field_service_report.er_chunks",
    )
    ibat_equipment_view: str = os.getenv(
        "RE_CHAIN_IBAT_EQUIPMENT_VIEW",
        "vgpd.prm_std_views.IBAT_EQUIPMENT_MST",
    )
    default_serials: list[str] = field(default_factory=lambda: list(DEFAULT_GT_SERIALS))
    missing_fsr_serials: list[str] = field(default_factory=lambda: list(MISSING_GT_FSR_SERIALS))
    skip_missing_fsr_serials: bool = env_bool("RE_CHAIN_SKIP_MISSING_FSR_SERIALS", True)
    persist_output_csv_uri: Optional[str] = None
    persist_run_dir_uri: Optional[str] = None
    log_results: bool = env_bool("RE_CHAIN_LOG_RESULTS", is_databricks())

    @property
    def ibat_path(self) -> Path:
        env_override = os.getenv("RE_CHAIN_IBAT_CSV", "").strip()
        if env_override:
            return Path(env_override)

        for file_name in ("30_serial_IBAT.csv", "7_serial_IBAT.csv"):
            candidate = self.input_data_dir / file_name
            if candidate.exists():
                return candidate

        return self.input_data_dir / "30_serial_IBAT.csv"

    @property
    def heatmap_path(self) -> Path:
        return self.input_data_dir / "Heat Map - Unified Structure v0.1.xlsx"

    @property
    def system_prompt_path(self) -> Path:
        return self.input_data_dir / "system_prompt_RE_Output_Table_NoPrism.txt"

    @property
    def sot_ground_truth_path(self) -> Path:
        return PROJECT_DIR / "Rel GEN - SOT data set for testing.xlsx"

    @property
    def er_dir(self) -> Path:
        return self.input_data_dir / "ER" / "ERChunks-7Serial#s"

    @property
    def fsr_dir(self) -> Path:
        return self.input_data_dir / "FSR"

    def resolve_api_key(self) -> str:
        return get_secret(self.secret_scope, "LITELLM_API_KEY", "")

    def ensure_output_dir(self) -> None:
        self.output_csv.parent.mkdir(parents=True, exist_ok=True)